run(function()
	local Scaffold
	local Expand
	local Tower
	local Downwards
	local Diagonal
	local LimitItem
	local Mouse
	local FillColor
	local OutlineColor
	local adjacent, lastpos, label, visualBlock = {}, Vector3.zero
	local visualTween, visualPos
	local visualSpeed = 0.1

	local edgeAdjacent = {}
	for x = -3, 3, 3 do
		for y = -3, 3, 3 do
			for z = -3, 3, 3 do
				local vec = Vector3.new(x, y, z)
				if vec ~= Vector3.zero then
					table.insert(adjacent, vec)
					local flat = vec * Vector3.new(1, 0, 1)
					if vec.Y == 0 and flat.Magnitude == 3 or vec.Y ~= 0 and flat.Magnitude == 0 then
						table.insert(edgeAdjacent, vec)
					end
				end
			end
		end
	end

	local function nearCorner(poscheck, pos)
		local startpos = poscheck - Vector3.new(3, 3, 3)
		local endpos = poscheck + Vector3.new(3, 3, 3)
		local check = poscheck + (pos - poscheck).Unit * 100
		return Vector3.new(math.clamp(check.X, startpos.X, endpos.X), math.clamp(check.Y, startpos.Y, endpos.Y), math.clamp(check.Z, startpos.Z, endpos.Z))
	end
	getgenv().nearCorner = nearCorner

	local function nearFace(poscheck, pos)
		local delta = pos - poscheck
		local absx, absy, absz = math.abs(delta.X), math.abs(delta.Y), math.abs(delta.Z)
		if absx >= absy and absx >= absz then
			return poscheck + Vector3.new(delta.X > 0 and 3 or -3, 0, 0)
		elseif absy >= absz then
			return poscheck + Vector3.new(0, delta.Y > 0 and 3 or -3, 0)
		end
		return poscheck + Vector3.new(0, 0, delta.Z > 0 and 3 or -3)
	end

	local function blockProximity(pos, diagonal)
		local mag, returned = 60
		local tab = getBlocksInPoints(bedwars.BlockController:getBlockPosition(pos - Vector3.new(21, 21, 21)), bedwars.BlockController:getBlockPosition(pos + Vector3.new(21, 21, 21)))
		for _, v in tab do
			local blockpos = diagonal and nearCorner(v, pos) or nearFace(v, pos)
			local newmag = (pos - blockpos).Magnitude
			if newmag < mag then
				mag, returned = newmag, blockpos
			end
		end
		table.clear(tab)
		return returned
	end
	getgenv().blockProximity = blockProximity

	local function checkAdjacent(pos, diagonal)
		for _, v in (diagonal and adjacent or edgeAdjacent) do
			if getPlacedBlock(pos + v) then
				return true
			end
		end
		return false
	end
	getgenv().checkAdjacent = checkAdjacent

	local shownAmount
	local function clearVisual()
		if visualTween then
			visualTween:Cancel()
			visualTween = nil
		end
		if visualBlock then
			visualBlock.Parent = nil
			visualBlock:Destroy()
			visualBlock = nil
		end
		visualPos = nil
	end
	local function hideVisual()
		if visualTween then
			visualTween:Cancel()
			visualTween = nil
		end
		if visualBlock then
			visualBlock.Parent = nil
		end
		visualPos = nil
	end

	local function getScaffoldBlock()
		if store.hand.toolType == 'block' then
			return store.hand.tool.Name, store.hand.amount
		elseif (not LimitItem.Enabled) then
			local wool, amount = getWool()
			if wool then
				return wool, amount
			else
				for _, v in store.inventory.inventory.items do
					if bedwars.ItemMeta[v.itemType].block then
						return v.itemType, v.amount
					end
				end
			end
		end

		return nil, 0
	end

	Scaffold = vape.Categories.Utility:CreateModule({
		Name = 'Scaffold',
		ExtraText = function() return tostring(Expand.Value) end,
		Function = function(callback)
			if label then
				label.Visible = callback
			end

			if callback then
				repeat
					if entitylib.isAlive then
						local wool, amount = getScaffoldBlock()

						if Mouse.Enabled then
							if not inputService:IsMouseButtonPressed(0) then
								wool = nil
							end
						end

						if label then
							amount = amount or 0
							if shownAmount ~= amount then
								shownAmount = amount
								label.Text = amount..' <font color="rgb(170, 170, 170)">(Scaffold)</font>'
								label.TextColor3 = Color3.fromHSV((amount / 128) / 2.8, 0.86, 1)
							end
						end

						if wool then
							local root = entitylib.character.RootPart
							if Tower.Enabled and (inputService:IsKeyDown(Enum.KeyCode.Space) or inputService:IsKeyDown(Enum.KeyCode.ButtonA) or inputService.TouchEnabled and entitylib.character.Humanoid.Jump) and (not inputService:GetFocusedTextBox()) then
								root.AssemblyLinearVelocity = Vector3.new(root.AssemblyLinearVelocity.X, 38, root.AssemblyLinearVelocity.Z)
							end

							for i = Expand.Value, 1, -1 do
								local currentpos = roundPos(root.Position - Vector3.new(0, entitylib.character.HipHeight + (Downwards.Enabled and inputService:IsKeyDown(Enum.KeyCode.LeftShift) and 4.5 or 1.5), 0) + entitylib.character.Humanoid.MoveDirection * (i * 3))
								if Diagonal.Enabled then
									if math.abs(math.round(math.deg(math.atan2(-entitylib.character.Humanoid.MoveDirection.X, -entitylib.character.Humanoid.MoveDirection.Z)) / 45) * 45) % 90 == 45 then
										local dt = (lastpos - currentpos)
										if ((dt.X == 0 and dt.Z ~= 0) or (dt.X ~= 0 and dt.Z == 0)) and ((lastpos - root.Position) * Vector3.new(1, 0, 1)).Magnitude < 2.5 then
											currentpos = lastpos
										end
									end
								end

								if visualBlock and currentpos then
									local visual = bedwars.BlockController:getBlockPosition(currentpos) * 3
									if visualPos ~= visual then
										if visualTween then
											visualTween:Cancel()
											visualTween = nil
										end

										if visualBlock.Parent == gameCamera then
											visualTween = tweenService:Create(visualBlock, TweenInfo.new(visualSpeed, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {CFrame = CFrame.new(visual)})
											visualTween:Play()
										else
											visualBlock.CFrame = CFrame.new(visual)
											visualBlock.Parent = gameCamera
										end
										visualPos = visual
									end
								end

								local block, blockpos = getPlacedBlock(currentpos)
								if not block then
									blockpos = checkAdjacent(blockpos * 3, Diagonal.Enabled) and blockpos * 3 or blockProximity(currentpos, Diagonal.Enabled)
									if blockpos then
										task.delay(0, bedwars.placeBlock, blockpos, wool, false)
									end
								end
								lastpos = currentpos
							end
						end
					end
					task.wait(0.03)
				until not Scaffold.Enabled
				hideVisual()
				shownAmount = nil
			else
				hideVisual()
				shownAmount = nil
			end
		end,
		Tooltip = 'Places blocks under you as you walk'
	})

	Expand = Scaffold:CreateSlider({
		Name = 'Expand',
		Min = 1,
		Max = 6
	})
	Tower = Scaffold:CreateToggle({
		Name = 'Tower',
		Default = true
	})
	Downwards = Scaffold:CreateToggle({
		Name = 'Downwards',
		Default = true
	})
	Diagonal = Scaffold:CreateToggle({
		Name = 'Diagonal',
		Default = true
	})
	LimitItem = Scaffold:CreateToggle({Name = 'Limit to items'})
	Mouse = Scaffold:CreateToggle({Name = 'Require mouse down'})
	local VisualGroup = Scaffold:CreateGroup({
		Name = 'Visual',
		Function = function(callback)
			if callback then
				visualBlock = Instance.new('Part')
				visualBlock.Size = Vector3.new(3, 3, 3)
				visualBlock.Anchored = true
				visualBlock.CanCollide = false
				visualBlock.CanQuery = false
				visualBlock.CanTouch = false
				visualBlock.CastShadow = false
				visualBlock.Transparency = 1
				local selection = Instance.new('SelectionBox')
				selection.Adornee = visualBlock
				selection.LineThickness = 0.04
				selection.Color3 = Color3.fromHSV(OutlineColor.Hue, OutlineColor.Sat, OutlineColor.Value)
				selection.Transparency = 1 - OutlineColor.Opacity
				selection.SurfaceColor3 = Color3.fromHSV(FillColor.Hue, FillColor.Sat, FillColor.Value)
				selection.SurfaceTransparency = 1 - FillColor.Opacity
				selection.Parent = visualBlock
				bedwars.QueryUtil:setQueryIgnored(visualBlock, true)
			else
				clearVisual()
			end
		end,
		Tooltip = 'Shows where the next block will go'
	})
	FillColor = VisualGroup:CreateColorSlider({
		Name = 'Fill colour',
		DefaultSat = 0,
		DefaultOpacity = 0.4,
		Darker = true,
		Function = function(hue, sat, val, opacity)
			if visualBlock then
				visualBlock.SelectionBox.SurfaceColor3 = Color3.fromHSV(hue, sat, val)
				visualBlock.SelectionBox.SurfaceTransparency = 1 - opacity
			end
		end
	})
	OutlineColor = VisualGroup:CreateColorSlider({
		Name = 'Outline colour',
		DefaultValue = 0,
		Darker = true,
		Function = function(hue, sat, val, opacity)
			if visualBlock then
				visualBlock.SelectionBox.Color3 = Color3.fromHSV(hue, sat, val)
				visualBlock.SelectionBox.Transparency = 1 - opacity
			end
		end
	})
	Scaffold:CreateToggle({
		Name = 'Block Count',
		Function = function(callback)
			if callback then
				label = Instance.new('TextLabel')
				label.Size = UDim2.fromOffset(100, 20)
				label.Position = UDim2.new(0.5, 6, 0.5, 60)
				label.BackgroundTransparency = 1
				label.AnchorPoint = Vector2.new(0.5, 0)
				label.Text = '0'
				label.TextColor3 = Color3.new(0, 1, 0)
				label.TextSize = 18
				label.RichText = true
				label.Font = Enum.Font.Arial
				label.Visible = Scaffold.Enabled
				label.Parent = vape.gui
			else
				label:Destroy()
				label = nil
			end
		end
	})
end)
