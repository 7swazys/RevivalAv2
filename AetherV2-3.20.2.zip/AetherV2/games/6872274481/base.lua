local license = ... or {}
if type(license) ~= 'table' then license = {} end
license.Closet = license.Closet == true

if not game:IsLoaded() then
	game.Loaded:Wait()
end

local canDebug = not license.Closet
local run = function(func, timeout)
	local started = tick()
	local lastError
	repeat
		local success, result = xpcall(func, debug and debug.traceback or tostring)
		if success then
			local yieldBuild = shared.vape and shared.vape.YieldBuild
			if yieldBuild then yieldBuild() end
			return result
		end

		lastError = result
		if not timeout or timeout <= 0 then
			break
		end
		task.wait(0.2)
	until tick() - started >= timeout

	warn('[AetherV2] Skipped a BedWars module during startup: '..tostring(lastError))
end
local cloneref = cloneref or function(obj)
	return obj
end
local vapeEvents = setmetatable({
	EntityDamageEvent = Instance.new('BindableEvent')
}, {
	__index = function(self, index)
		self[index] = Instance.new('BindableEvent')
		return self[index]
	end
})
shared.bindable = Instance.new('BindableEvent')
getgenv().vapeEvents = vapeEvents

local playersService = cloneref(game:GetService('Players'))
local replicatedStorage = cloneref(game:GetService('ReplicatedStorage'))
local runService = shared.vape.Libraries.profiler and shared.vape.Libraries.profiler.RunService or cloneref(game:GetService('RunService'))
local task = shared.vape.Libraries.profiler and shared.vape.Libraries.profiler.Task or task
local inputService = cloneref(game:GetService('UserInputService'))
local lightingService = cloneref(game:GetService('Lighting'))
local textService = cloneref(game:GetService('TextService'))
local tweenService = cloneref(game:GetService('TweenService'))
local proximityPromptService = cloneref(game:GetService('ProximityPromptService'))
local httpService = cloneref(game:GetService('HttpService'))
local textChatService = cloneref(game:GetService('TextChatService'))
local collectionService = cloneref(game:GetService('CollectionService'))
local contextActionService = cloneref(game:GetService('ContextActionService'))
local guiService = cloneref(game:GetService('GuiService'))
local coreGui = cloneref(game:GetService('CoreGui'))
local starterGui = cloneref(game:GetService('StarterGui'))

local isnetworkowner = isnetworkowner or function()
	return true
end
local gameCamera = workspace.CurrentCamera
local lplr = playersService.LocalPlayer
local assetfunction = getcustomasset

local vape = shared.vape

local entitylib = vape.Libraries.entity
local targetinfo = vape.Libraries.targetinfo
local sessioninfo = vape.Libraries.sessioninfo
local uipallet = vape.Libraries.uipallet
local tween = vape.Libraries.tween
local color = vape.Libraries.color
local whitelist = vape.Libraries.whitelist
local prediction = vape.Libraries.prediction
local getfontsize = vape.Libraries.getfontsize
local getcustomasset = vape.Libraries.getcustomasset
if not vape.Libraries.swordtiming then
	local timing = {
		CooldownCorrection = (0.017999999225139618 / 10) + 0.013412,
		Modes = {
			Legit = {Hits = 33, Budget = true},
			High = {Hits = 34, Budget = true},
			['Extra High'] = {Hits = 35, Backup = {0.018}},
			Max = {Hits = 36, Sync = {16.85 / 60, 17.1 / 60}, Backup = {0.018, 0.036}}
		}
	}
	function timing.Spacing(hits, speed)
		return math.max(9.95 / math.max(hits - 1, 1), 0.2834) * ((speed or 0.3) / 0.3)
	end
	vape.Libraries.swordtiming = timing
end
if not vape.Libraries.auraanims then
	local function keyframe(x, y, z, time)
		return {CFrame = CFrame.Angles(math.rad(x), math.rad(y), math.rad(z)), Time = time}
	end

	vape.Libraries.auraanims = {
		Default = {
			keyframe(0, 0, -20, 0.05),
			keyframe(0, 0, -45, 0.07),
			keyframe(0, 0, 14, 0.06),
			keyframe(0, 0, 0, 0.05)
		},
		Slash = {
			keyframe(-12, 0, 30, 0.06),
			keyframe(6, 0, -55, 0.07),
			keyframe(-4, 0, 35, 0.06),
			keyframe(0, 0, 0, 0.05)
		},
		Horizontal = {
			keyframe(0, -35, 0, 0.06),
			keyframe(0, 45, 0, 0.08),
			keyframe(0, -10, 0, 0.06),
			keyframe(0, 0, 0, 0.05)
		},
		Spin = {
			keyframe(0, 0, 120, 0.09),
			keyframe(0, 0, 240, 0.09),
			keyframe(0, 0, 360, 0.09),
			keyframe(0, 0, 0, 0.05)
		},
		Random = {}
	}
end

local function downloadFile(path, func)
	if not isfile(path) then
		local suc, res = pcall(function()
			if type(shared.AetherV2FetchSource) == 'function' then
				return shared.AetherV2FetchSource(path)
			end
			return game:HttpGet('https://api.aetherv2.xyz/raw/'..readfile('aetherv2/profiles/commit.txt')..'/'..select(1, path:gsub('aetherv2/', '')), true)
		end)
		if not suc or res == '404: Not Found' then
			error(res)
		end
		if path:sub(-4) == '.lua' then
			res = '--This watermark is used to delete the file if its cached, remove it to make the file persist after vape updates.\n'..res
		end
		writefile(path, res)
	end
	return (func or readfile)(path)
end

run(function()
	vape.Libraries.combat = loadstring(downloadFile('aetherv2/libraries/combat.lua'), 'combat')()
	getgenv().AetherCombat = vape.Libraries.combat
	shared.AetherCombat = vape.Libraries.combat
end)
run(function()
	vape.Libraries.bedwarsutil = loadstring(downloadFile('aetherv2/libraries/bedwarsutil.lua'), 'bedwarsutil')()
	shared.AetherBedWarsUtil = vape.Libraries.bedwarsutil
end)

local bedwars = {}
local rankCache = {}
local store = {
	lastHit = 0,
	attackReach = 0,
	attackReachUpdate = tick(),
	damageBlockFail = tick(),
	hand = {},
	rank = setmetatable({}, {
		__index = function(self, index)
			return {
				async = function()
					if rankCache[index] then
						return rankCache[index]
					end

					if index then
						local rank = bedwars.Client:Get('FetchRanks'):CallServer({index.UserId})
						if typeof(rank) == 'table' and rank[1] and rank[1].rankDivision then
							rankCache[index] = rank[1].rankDivision
							return rankCache[index]
						end
					end

					return nil
				end,
			}
		end
	}),
	inventory = {
		inventory = {
			items = {},
			armor = {}
		},
		hotbar = {}
	},
	selfProjectiles = {},
	hitchance = {},
	inventories = {},
	kitReady = false,
	matchState = 0,
	queueType = 'bedwars_test',
	tools = {},
	ping = setmetatable({}, {
		__index = function(_, key)
			if key == 'total' or key == 'incoming' then
				local success, value = pcall(lplr.GetNetworkPing, lplr)
				return success and math.max(tonumber(value) or 0, 0) or 0
			end
		end
	})
}
getgenv().store = store

local function activeBedwarsKit()
	local values = {
		store.equippedKit,
		lplr:GetAttribute('PlayingAsKit'),
		lplr:GetAttribute('PlayingAsKits'),
		lplr:GetAttribute('SelectedKit'),
		lplr:GetAttribute('Kit')
	}
	local ready = store.kitReady == true
	if bedwars.Store and type(bedwars.Store.getState) == 'function' then
		local ok, state = pcall(bedwars.Store.getState, bedwars.Store)
		if ok and type(state) == 'table' then
			ready = ready or type(state.Bedwars) == 'table'
			local bedwarsState = type(state.Bedwars) == 'table' and state.Bedwars or {}
			local kitState = type(state.Kit) == 'table' and state.Kit or {}
			table.insert(values, 1, bedwarsState.kit or kitState.kit or kitState.equippedKit)
		end
	end
	for _, value in values do
		if value ~= nil and tostring(value) ~= '' and tostring(value):lower() ~= 'none' then
			return tostring(value), true
		end
	end
	return nil, ready
end
if type(vape.SetGameInfo) == 'function' then
	vape:SetGameInfo({Name = 'BedWars', GetKit = activeBedwarsKit})
end

local Reach = {}
local HitBoxes = {}
local TrapDisabler
local AntiFallPart
local remotes, sides, oldinvrender, oldSwing = {}, {}, nil, nil

local AetherMatchRuntime

local kits = vape.Categories.Kits

local function addBlur(parent)
	local blur = Instance.new('ImageLabel')
	blur.Name = 'Blur'
	blur.Size = UDim2.new(1, 89, 1, 52)
	blur.Position = UDim2.fromOffset(-48, -31)
	blur.BackgroundTransparency = 1
	blur.Image = getcustomasset('aetherv2/assets/new/blur.png')
	blur.ScaleType = Enum.ScaleType.Slice
	blur.SliceCenter = Rect.new(52, 31, 261, 502)
	blur.Parent = parent
	return blur
end

local function collection(tags, module, customadd, customremove)
	tags = typeof(tags) ~= 'table' and {tags} or tags
	local objs, connections = {}, {}

	for _, tag in tags do
		table.insert(connections, collectionService:GetInstanceAddedSignal(tag):Connect(function(v)
			if customadd then
				customadd(objs, v, tag)
				return
			end
			table.insert(objs, v)
		end))
		table.insert(connections, collectionService:GetInstanceRemovedSignal(tag):Connect(function(v)
			if customremove then
				customremove(objs, v, tag)
				return
			end
			v = table.find(objs, v)
			if v then
				table.remove(objs, v)
			end
		end))

		for _, v in collectionService:GetTagged(tag) do
			if customadd then
				customadd(objs, v, tag)
				continue
			end
			table.insert(objs, v)
		end
	end

	local cleanFunc = function(self)
		for _, v in connections do
			v:Disconnect()
		end
		table.clear(connections)
		table.clear(objs)
		table.clear(self)
	end
	if module then
		module:Clean(cleanFunc)
	end
	return objs, cleanFunc
end

local function getBestArmor(slot)
	local closest, mag = nil, 0
	local inventory = store.inventory and store.inventory.inventory

	for _, item in pairs(inventory and inventory.items or {}) do
		local meta = item and bedwars.ItemMeta[item.itemType] or {}

		if meta.armor and meta.armor.slot == slot then
			local newmag = (meta.armor.damageReductionMultiplier or 0)

			if newmag > mag then
				closest, mag = item, newmag
			end
		end
	end

	return closest
end

local function getBow()
	local bestBow, bestBowSlot, bestBowDamage = nil, nil, 0
	local inventory = store.inventory and store.inventory.inventory
	for slot, item in pairs(inventory and inventory.items or {}) do
		local itemMeta = item and bedwars.ItemMeta[item.itemType]
		local bowMeta = itemMeta and itemMeta.projectileSource
		if bowMeta and type(bowMeta.ammoItemTypes) == 'table' and type(bowMeta.projectileType) == 'function'
			and table.find(bowMeta.ammoItemTypes, 'arrow') then
			local ok, projectileType = pcall(bowMeta.projectileType, 'arrow')
			local projectileMeta = ok and bedwars.ProjectileMeta[projectileType]
			local bowDamage = projectileMeta and projectileMeta.combat and projectileMeta.combat.damage or 0
			if bowDamage > bestBowDamage then
				bestBow, bestBowSlot, bestBowDamage = item, slot, bowDamage
			end
		end
	end
	return bestBow, bestBowSlot
end

local function getItem(itemName, inv, find)
	local inventory = store.inventory and store.inventory.inventory
	for slot, item in pairs(type(inv) == 'table' and inv or inventory and inventory.items or {}) do
		local itemType = item and item.itemType
		if itemType and ((find and itemType:find(itemName, 1, true)) or itemType == itemName) then
			return item, slot
		end
	end
	return nil
end

local function projectileMatches(enabled, ...)
	for _, wanted in enabled or {} do
		local needle = tostring(wanted):lower()
		local gloop = needle == 'gloop' or needle == 'gloop_projectile'
		for index = 1, select('#', ...) do
			local value = select(index, ...)
			if value then
				local lowered = tostring(value):lower()
				if lowered == needle or gloop and lowered:sub(1, 5) == 'glue_' then return true end
			end
		end
	end
	return false
end

local function getProjectiles(enabled, useSophia, useWhim, useNazar, useUmeko, useFireball, useGloop)
	local projectiles, inventory = {}, store.inventory and store.inventory.inventory
	if type(inventory) ~= 'table' or type(inventory.items) ~= 'table' then return projectiles end
	for _, item in inventory.items do
		local itemMeta = item and bedwars.ItemMeta[item.itemType]
		local source = itemMeta and itemMeta.projectileSource
		local loweredType = item and tostring(item.itemType):lower() or ''
		local specialSource = useSophia and (loweredType:find('sophia', 1, true) or loweredType:find('frost_staff', 1, true))
			or useWhim and (loweredType:find('whim', 1, true) or loweredType:find('magic_book', 1, true))
			or useNazar and table.find({'life_bow', 'life_crossbow', 'life_headhunter'}, loweredType) ~= nil
			or useUmeko and (loweredType:find('chakram', 1, true) or loweredType:find('umeko', 1, true))
			or useFireball and loweredType == 'fireball'
			or useGloop and loweredType:sub(1, 15) == 'glue_projectile'
		if source and item.tool and type(source.projectileType) == 'function' then
			for _, ammoType in source.ammoItemTypes or {} do
				local ammoItem = getItem(ammoType, inventory.items)
				if ammoItem and (ammoItem.amount or 1) > 0 then
					local ok, projectile = pcall(source.projectileType, ammoType)
					local projectileMeta = ok and projectile and bedwars.ProjectileMeta[projectile]
					local ammoMeta = bedwars.ItemMeta[ammoType]
					if projectileMeta and (specialSource or projectileMatches(enabled, ammoType, projectile, item.itemType, itemMeta.displayName, ammoMeta and ammoMeta.displayName, projectileMeta.displayName)) then
						table.insert(projectiles, {item, ammoType, projectile, source, projectileMeta})
					end
				end
			end
		end
	end
	return projectiles
end

local hitMotion = setmetatable({}, {__mode = 'k'})
local function getHitChance(ent, flight)
	flight = tonumber(flight)
	local root = ent and ent.RootPart
	if not root or not root.Parent or not flight or flight <= 0 or flight ~= flight then return 0 end
	local now = tick()
	local velocity = root.AssemblyLinearVelocity
	local horizontal = (velocity * Vector3.new(1, 0, 1)).Magnitude
	local last = hitMotion[root]
	local acceleration = 0
	if last and now > last.Clock then
		acceleration = ((velocity - last.Velocity) / math.max(now - last.Clock, 1 / 240)).Magnitude
	end
	hitMotion[root] = {Velocity = velocity, Clock = now}
	local airborne = ent.Humanoid and ent.Humanoid.FloorMaterial == Enum.Material.Air
	local errorBudget = (horizontal * flight * 0.28) + (acceleration * flight * flight * 0.12)
	if airborne then errorBudget += math.abs(velocity.Y) * flight * 0.12 end
	return math.clamp((100 - errorBudget) / 100, 0, 1)
end
getgenv().getHitChance = getHitChance

local function projectileAcceleration(gravity)
	if typeof(gravity) == 'Vector3' then return gravity end
	gravity = math.abs(tonumber(gravity) or workspace.Gravity)
	return Vector3.new(0, -gravity, 0)
end

local function targetProjectileMotion(ent, targetPosition, stationary, raycastParams)
	if stationary then return Vector3.zero, Vector3.zero end
	local root, humanoid = ent and ent.RootPart, ent and ent.Humanoid
	if not root or not root.Parent then return end
	local velocity = root.AssemblyLinearVelocity
	local grounded = humanoid and humanoid.FloorMaterial ~= Enum.Material.Air
	if not grounded and typeof(targetPosition) == 'Vector3' then
		local distance = math.max((tonumber(ent.HipHeight) or 3) + 0.75, 1)
		local ok, floor = pcall(workspace.Raycast, workspace, root.Position, Vector3.new(0, -distance, 0), raycastParams)
		grounded = ok and floor ~= nil and floor.Normal.Y > 0.15 and velocity.Y <= 0.1
	end
	if grounded then
		return Vector3.new(velocity.X, 0, velocity.Z), Vector3.zero
	end

	local gravity = workspace.Gravity
	local character = ent.Character
	local balloons = character and character:GetAttribute('InflatedBalloons')
	if type(balloons) == 'number' and balloons > 0 then
		gravity = workspace.Gravity * (1 - (balloons >= 4 and 1.2 or balloons >= 3 and 1 or 0.975))
	end
	if root:FindFirstChild('rbxassetid://8200754399') then gravity = 6 end
	if ent.Player and ent.Player:GetAttribute('IsOwlTarget') then
		for _, owl in collectionService:GetTagged('Owl') do
			if owl:GetAttribute('Target') == ent.Player.UserId and owl:GetAttribute('Status') == 2 then
				gravity = 0
				break
			end
		end
	end
	return velocity, Vector3.new(0, -gravity, 0)
end

local function solveBedwarsProjectile(origin, speed, gravity, ent, targetPosition, options)
	options = type(options) == 'table' and options or {}
	if typeof(origin) ~= 'Vector3' or typeof(targetPosition) ~= 'Vector3' then return end
	speed = tonumber(speed)
	if not speed or speed <= 0 then return end
	local modelSpeed = speed * math.max(tonumber(options.PredictionScale) or 1, 0.05)
	local targetVelocity, targetAcceleration = targetProjectileMotion(
		ent,
		targetPosition,
		options.Stationary == true,
		options.RaycastParams
	)
	if not targetVelocity then return end
	local solution = prediction.SolveIntercept(
		origin,
		modelSpeed,
		projectileAcceleration(gravity),
		targetPosition,
		targetVelocity,
		targetAcceleration,
		0.001,
		math.max(tonumber(options.Lifetime) or 3, 0.001)
	)
	if not solution or solution.InitialVelocity.Magnitude <= 1e-3 then return end
	return {
		AimPosition = origin + solution.InitialVelocity,
		Velocity = solution.InitialVelocity.Unit * speed,
		FlightTime = solution.FlightTime,
		ImpactPosition = solution.ImpactPosition
	}
end

local function projectileLaunchOrigin(baseOrigin, aimVelocity)
	if typeof(baseOrigin) ~= 'Vector3' or typeof(aimVelocity) ~= 'Vector3' or aimVelocity.Magnitude <= 1e-3 then return baseOrigin end
	local constants = bedwars.BowConstantsTable
	if type(constants) ~= 'table' then return baseOrigin end
	local offset = Vector3.new(
		-(tonumber(constants.RelX) or 0),
		-(tonumber(constants.RelY) or 0),
		-(tonumber(constants.RelZ) or 0)
	)
	return (CFrame.lookAt(baseOrigin, baseOrigin + aimVelocity) * CFrame.new(offset)).Position
end

local function getRoactRender(func)
	local ok, result = pcall(function()
		return debug.getupvalue(debug.getupvalue(debug.getupvalue(func, 3).render, 2).render, 1)
	end)
	if ok then
		return result
	end
	return nil
end

local function getSword()
	local bestSword, bestSwordSlot, bestSwordDamage = nil, nil, 0
	local inventory = store.inventory and store.inventory.inventory
	for slot, item in pairs(inventory and inventory.items or {}) do
		local itemMeta = item and bedwars.ItemMeta[item.itemType]
		local swordMeta = itemMeta and itemMeta.sword
		if swordMeta then
			local swordDamage = swordMeta.damage or 0
			local bestMeta = bestSword and bedwars.ItemMeta[bestSword.itemType]
			if swordDamage > bestSwordDamage or (bestMeta and swordDamage == bestSwordDamage and (swordMeta.attackSpeed or 0.3) < (bestMeta.sword.attackSpeed or 0.3)) then
				bestSword, bestSwordSlot, bestSwordDamage = item, slot, swordDamage
			end
		end
	end
	return bestSword, bestSwordSlot
end

local function getTool(breakType)
	local bestTool, bestToolSlot, bestToolDamage = nil, nil, 0
	local inventory = store.inventory and store.inventory.inventory
	for slot, item in pairs(inventory and inventory.items or {}) do
		local itemMeta = item and bedwars.ItemMeta[item.itemType]
		local toolMeta = itemMeta and itemMeta.breakBlock
		if toolMeta then
			local toolDamage = toolMeta[breakType] or 0
			if toolDamage > bestToolDamage then
				bestTool, bestToolSlot, bestToolDamage = item, slot, toolDamage
			end
		end
	end
	return bestTool, bestToolSlot
end

local function getBreakTool(breakType)
	if not breakType then return end
	local cached = store.tools[breakType]
	if cached ~= nil then
		return cached or nil
	end
	local tool = getTool(breakType)
	store.tools[breakType] = tool or false
	return tool
end

local function getWool()
	local inventory = store.inventory and store.inventory.inventory
	for _, wool in pairs(inventory and inventory.items or {}) do
		if wool.itemType and wool.itemType:find('wool', 1, true) then
			return wool and wool.itemType, wool and wool.amount
		end
	end
end

local function getStrength(plr)
	if not plr.Player then
		return 0
	end

	local strength = 0
	for _, v in (store.inventories[plr.Player] or {items = {}}).items do
		local itemmeta = bedwars.ItemMeta[v.itemType]
		if itemmeta and itemmeta.sword and itemmeta.sword.damage > strength then
			strength = itemmeta.sword.damage
		end
	end

	return strength
end

local function getPlacedBlock(pos)
	if not pos then
		return
	end
	local roundedPosition = bedwars.BlockController:getBlockPosition(pos)
	return bedwars.BlockController:getStore():getBlockAt(roundedPosition), roundedPosition
end
getgenv().getPlacedBlock = getPlacedBlock
local function installWindStackHook()
	local controller = bedwars.WindWalkerController
	if not controller or type(controller.updateJump) ~= 'function' then return end
	if getgenv().__AetherWindHookedV2 ~= controller then
		local original = controller.updateJump
		controller.updateJump = function(self, count, ...)
			getgenv().__AetherWindStacks = tonumber(count) or 0
			getgenv().__AetherWindAt = tick()
			return original(self, count, ...)
		end
		getgenv().__AetherWindHookedV2 = controller
	end
	if getgenv().__AetherWindSpeedHooked ~= controller and type(controller.updateSpeed) == 'function' then
		local original = controller.updateSpeed
		controller.updateSpeed = function(self, multiplier, ...)
			getgenv().__AetherWindMultiplier = tonumber(multiplier) or 1
			return original(self, multiplier, ...)
		end
		getgenv().__AetherWindSpeedHooked = controller
		getgenv().__AetherWindSpeedOriginal = original
	end
end
store.hitboxView = {Owners = {}}
store.hitboxView.Add = function(module)
	local view = store.hitboxView
	local toggle = module:CreateToggle({
		Name = 'Show hitbox',
		Tooltip = 'Highlights where your real hitbox is',
		Function = function(callback)
			view.Owners[module] = callback or nil
			view.Refresh()
		end
	})
	return toggle
end
store.hitboxView.Refresh = function()
	local view = store.hitboxView
	local wanted = next(view.Owners) ~= nil
	if wanted and not view.Conn then
		local box = Instance.new('BoxHandleAdornment')
		box.AlwaysOnTop = true
		box.ZIndex = 10
		box.Color3 = Color3.fromRGB(255, 70, 70)
		box.Transparency = 0.45
		box.Parent = vape.gui
		local line = Instance.new('LineHandleAdornment')
		line.AlwaysOnTop = true
		line.ZIndex = 9
		line.Thickness = 2
		line.Color3 = Color3.fromRGB(255, 70, 70)
		line.Transparency = 0.3
		line.Parent = vape.gui
		view.Box, view.Line = box, line
		view.Conn = runService.RenderStepped:Connect(function()
			local active = false
			for module in view.Owners do
				if module.Enabled then
					active = true
					break
				end
			end
			local part = active and store.rootpart or nil
			if active and not part and entitylib.isAlive then
				part = entitylib.character.HumanoidRootPart
			end
			if not part and line.Visible then
				line.Visible = false
			end
			if box.Adornee ~= part then
				box.Adornee = part
				line.Adornee = part
			end
			if part then
				local size = part.Size + Vector3.new(0.2, 0.2, 0.2)
				if box.Size ~= size then
					box.Size = size
				end
				local body = lplr.Character and lplr.Character.PrimaryPart
				local gap = body and body ~= part and (body.Position - part.Position) or nil
				if gap and gap.Magnitude > 1 then
					line.Visible = true
					line.CFrame = CFrame.lookAt(Vector3.zero, part.CFrame:VectorToObjectSpace(gap))
					line.Length = gap.Magnitude
				elseif line.Visible then
					line.Visible = false
				end
			end
		end)
		vape:Clean(view.Conn)
	elseif not wanted and view.Conn then
		view.Conn:Disconnect()
		view.Conn = nil
		view.Box:Destroy()
		view.Line:Destroy()
		view.Box, view.Line = nil, nil
	end
end
store.windSpeedKey = function(key)
	installWindStackHook()
	local controller = bedwars.WindWalkerController
	local fn = getgenv().__AetherWindSpeedOriginal or (controller and getmetatable(controller) and getmetatable(controller).updateSpeed)
	if type(fn) ~= 'function' then return false end
	local changed = false
	pcall(function()
		for i, v in debug.getconstants(fn) do
			if v == 'constantSpeedMultiplier' or v == 'moveSpeedMultiplier' then
				if v ~= key then
					debug.setconstant(fn, i, key)
					changed = true
				end
				break
			end
		end
	end)
	if changed and controller and getgenv().__AetherWindMultiplier then
		pcall(controller.updateSpeed, controller, getgenv().__AetherWindMultiplier)
	end
	return true
end
installWindStackHook()
local function getWindStacks()
	installWindStackHook()
	return tonumber(getgenv().__AetherWindStacks) or 0
end
getgenv().getWindStacks = getWindStacks
getgenv().WIND_WALKER_MAX_STACKS = 5

local function getBlocksInPoints(s, e)
	local blocks, list = bedwars.BlockController:getStore(), {}
	for x = s.X, e.X do
		for y = s.Y, e.Y do
			for z = s.Z, e.Z do
				local vec = Vector3.new(x, y, z)
				if blocks:getBlockAt(vec) then
					table.insert(list, vec * 3)
				end
			end
		end
	end
	return list
end

local function getNearGround(range)
	range = Vector3.new(3, 3, 3) * (range or 10)
	local localPosition, mag, closest = entitylib.character.RootPart.Position, 60
	local blocks = getBlocksInPoints(bedwars.BlockController:getBlockPosition(localPosition - range), bedwars.BlockController:getBlockPosition(localPosition + range))

	for _, v in blocks do
		if not getPlacedBlock(v + Vector3.new(0, 3, 0)) then
			local newmag = (localPosition - v).Magnitude
			if newmag < mag then
				mag, closest = newmag, v + Vector3.new(0, 3, 0)
			end
		end
	end

	table.clear(blocks)
	return closest
end

local function getShieldAttribute(char)
	local returned = 0
	for name, val in char:GetAttributes() do
		if name:find('Shield') and type(val) == 'number' and val > 0 then
			returned += val
		end
	end
	return returned
end

local knockbackSpeed, knockbackBoost = 0, tick()
local function getSpeed()
	local multi, increase, modifiers = 0, true, bedwars.SprintController:getMovementStatusModifier():getModifiers()

	for v in modifiers do
		local val = v.constantSpeedMultiplier and v.constantSpeedMultiplier or 0
		if val and val > math.max(multi, 1) then
			increase = false
			multi = val - (0.06 * math.round(val))
		end
	end

	for v in modifiers do
		multi += math.max((v.moveSpeedMultiplier or 0) - 1, 0)
	end

	if multi > 0 and increase then
		multi += 0.16 + (0.02 * math.round(multi))
	end

	return (20 + (knockbackBoost > tick() and knockbackSpeed or 0)) * (multi + 1)
end
getgenv().getSpeed = getSpeed

store.engineSpeed = function(module)
	local speed = 0
	module:Clean(runService.PostSimulation:Connect(function()
		if not entitylib.isAlive then
			speed = 0
			return
		end
		local velocity = entitylib.character.RootPart.AssemblyLinearVelocity
		local sample = Vector3.new(velocity.X, 0, velocity.Z).Magnitude
		speed = sample >= speed and sample or speed + (sample - speed) * 0.25
	end))
	return function()
		return math.max(speed, getSpeed())
	end
end

local function getTableSize(tab)
	local ind = 0
	for _ in tab do
		ind += 1
	end
	return ind
end
store.lastInput = tick()
local function markPlayerInput(input)
	if input.UserInputType ~= Enum.UserInputType.MouseMovement or input.Delta.Magnitude > 0 then
		store.lastInput = tick()
	end
end
vape:Clean(inputService.InputBegan:Connect(markPlayerInput))
vape:Clean(inputService.InputChanged:Connect(markPlayerInput))

local function isAfk()
	return (tick() - (store.lastInput or 0)) >= 30
end
getgenv().isAfk = isAfk

local function getReach(tool)
	local itemmeta = tool and bedwars.ItemMeta[tool.Name]
	local swordReach = itemmeta and itemmeta.sword and itemmeta.sword.attackRange
	if swordReach then return swordReach end
	if store.swordDistance then return store.swordDistance end
	return bedwars.CombatConstant and bedwars.CombatConstant.RAYCAST_SWORD_CHARACTER_DISTANCE or 3
end
getgenv().getReach = getReach
local function isHeadshotLoadout(projectileType)
	local hand = store.hand
	local itemType = tostring((hand and (hand.itemType or (hand.tool and hand.tool.Name))) or ''):lower()
	if itemType:find('headhunter', 1, true) then return true end
	if tostring(projectileType or ''):lower():find('headhunter', 1, true) then return true end
	local kit = tostring(store.equippedKit or lplr:GetAttribute('PlayingAsKit') or lplr:GetAttribute('PlayingAsKits') or ''):lower()
	return kit:find('archer', 1, true) ~= nil
end
getgenv().isHeadshotDynamic = isHeadshotLoadout

local function isCasting()
	local casting = lplr:GetAttribute('IsCasting')
	return casting and casting ~= 0 and casting ~= ''
end

local function canSwing()
	if type(bedwars.SwordController.getSwordSwingDisabled) == 'function' and bedwars.SwordController:getSwordSwingDisabled() then return false end
	if isCasting() then return false end

	local itemmeta = store.hand and store.hand.tool and bedwars.ItemMeta[store.hand.tool.Name]
	return itemmeta ~= nil and itemmeta.sword ~= nil and itemmeta.sword.chargedAttack == nil
end
getgenv().canSwing = canSwing

local function getHotbar(tool)
	local inventory = store.inventory or {}
	for i, v in (inventory.hotbar or {}) do
		if v.item and v.item.tool == tool then
			return i - 1
		end
	end
	return nil
end
getgenv().getHotbar = getHotbar

local function hotbarSwitch(slot)
	local inventory = store.inventory or {}
	if slot ~= nil and inventory.hotbarSlot ~= slot then
		local changed = false
		local connection = vapeEvents.InventoryChanged.Event:Connect(function()
			changed = true
		end)
		bedwars.Store:dispatch({
			type = 'InventorySelectHotbarSlot',
			slot = slot
		})
		
		local deadline = tick() + 0.6
		repeat task.wait() until changed or (store.inventory and store.inventory.hotbarSlot == slot) or tick() >= deadline
		connection:Disconnect()
		return changed or (store.inventory and store.inventory.hotbarSlot == slot) or false
	end
	return inventory.hotbarSlot == slot
end
getgenv().hotbarSwitch = hotbarSwitch

local function getFunctionRange()
	
	return nil
end

local function getFacingEntity(options)
	options = type(options) == 'table' and table.clone(options) or {}
	if not entitylib.isAlive then return nil end
	local root = entitylib.character and entitylib.character.RootPart
	if not root then return nil end
	options.Origin = options.Origin or root.Position
	options.Part = options.Part or 'RootPart'
	local ok, targets = pcall(entitylib.AllPosition, options)
	if not ok or type(targets) ~= 'table' then return nil end
	local look = gameCamera.CFrame.LookVector
	local best, bestDot
	for _, target in ipairs(targets) do
		local part = target and target[options.Part]
		local delta = part and part.Position - options.Origin
		if delta and delta.Magnitude > 0.001 then
			local dot = look:Dot(delta.Unit)
			if dot > 0.35 and (not bestDot or dot > bestDot) then
				best, bestDot = target, dot
			end
		end
	end
	return best
end

local function fireProjectile(item, ammo, projectile, target)
	if not entitylib.isAlive or type(item) ~= 'table' or not item.tool or not item.tool.Parent then return false end
	local root = entitylib.character and entitylib.character.RootPart
	local targetPart = target and (target.RootPart or target.PrimaryPart)
	local projectileMeta = bedwars.ProjectileMeta and bedwars.ProjectileMeta[projectile]
	if not root or not targetPart or not projectileMeta then return false end
	local speed = tonumber(projectileMeta.launchVelocity) or 100
	if speed <= 0 then return false end
	local origin = root.Position
	local velocity = CFrame.lookAt(origin, targetPart.Position).LookVector * speed
	local id = httpService:GenerateGUID(true)
	local draw = {drawDurationSeconds = projectileMeta.drawDurationSeconds or 1, shotId = httpService:GenerateGUID(false)}
	local remoteOK, remote = pcall(function()
		return bedwars.Client:Get(remotes.FireProjectile).instance
	end)
	if not remoteOK or not remote or type(remote.InvokeServer) ~= 'function' then return false end
	pcall(bedwars.ProjectileController.createLocalProjectile, bedwars.ProjectileController,
		projectileMeta, ammo, projectile, origin, id, velocity, draw)
	local called, result = pcall(remote.InvokeServer, remote, item.tool, ammo, projectile,
		origin, origin, velocity, id, draw, workspace:GetServerTimeNow() - 0.045)
	if called and result ~= false then
		store.lastProjectileFire = workspace:GetServerTimeNow()
		targetinfo.Targets[target] = tick() + 1
		return true
	end
	return false
end

local function isFirstPerson()
	local camera = workspace.CurrentCamera or gameCamera
	return camera and (camera.CFrame.Position - camera.Focus.Position).Magnitude < 1 or false
end

local function isGUIOpen()
	local scaled = vape.gui and vape.gui:FindFirstChild('ScaledGui')
	local click = scaled and scaled:FindFirstChild('ClickGui')
	return click and click.Visible or false
end

local function isHoldingItem(names)
	local hand = store.hand
	local held = hand and (hand.itemType or (hand.tool and hand.tool.Name))
	if not held then return false end
	for _, name in ipairs(names or {}) do
		if held == name or tostring(held):find(tostring(name), 1, true) then return true end
	end
	return false
end

local function getWorldFolder()
	local map = workspace:FindFirstChild('Map')
	if not map then return nil end
	if map:FindFirstChild('Blocks') then return map end
	for _, object in ipairs(map:GetDescendants()) do
		if object.Name == 'Blocks' and (object:IsA('Folder') or object:IsA('Model')) then return object.Parent end
	end
	return nil
end

local function isFriend(plr, recolor)
	if vape.Categories.Friends.Options['Use friends'].Enabled then
		local friend = table.find(vape.Categories.Friends.ListEnabled, plr.Name) and true
		if recolor then
			friend = friend and vape.Categories.Friends.Options['Recolor visuals'].Enabled
		end
		return friend
	end
	return nil
end

local function isTarget(plr)
	return table.find(vape.Categories.Targets.ListEnabled, plr.Name) and true
end

local function notif(...) return vape:CreateNotification(...) end
local function scanDescendants(root, func, module)
	if not root or type(func) ~= 'function' then return end
	local ok, descendants = pcall(function()
		return root:GetDescendants()
	end)
	if not ok or type(descendants) ~= 'table' then return end
	for _, object in ipairs(descendants) do
		local called, err = pcall(func, object)
		if not called and shared.VapeDeveloper then
			warn('[AetherV2] scanDescendants callback failed on '..tostring(object)..': '..tostring(err))
		end
	end
end
local function cloneRaycast(extra)
	local params = RaycastParams.new()
	params.FilterType = Enum.RaycastFilterType.Exclude
	local ignore = {gameCamera}
	if entitylib.character and entitylib.character.Character then
		table.insert(ignore, entitylib.character.Character)
	end
	for _, ent in ipairs(entitylib.List) do
		if ent.Character then
			table.insert(ignore, ent.Character)
		end
	end
	if extra then
		table.insert(ignore, extra)
	end
	params.FilterDescendantsInstances = ignore
	return params
end
local function isFrozen(char, threshold)
	local character = char or (entitylib.character and entitylib.character.Character)
	if not character or not bedwars.StatusEffectUtil then return false end
	local ok, active = pcall(function()
		return bedwars.StatusEffectUtil:isActive(character, 'frozen')
	end)
	if not ok or not active then return false end
	if not threshold then return true end
	local stacks
	for name, value in character:GetAttributes() do
		if name:find('frozen', 1, true) and name:find('stack', 1, true) and type(value) == 'number' then
			stacks = value
			break
		end
	end
	if type(stacks) == 'number' then return stacks >= threshold end
	return true
end

local function resolveAnimation(names)
	local types = bedwars.AnimationType
	if type(types) ~= 'table' then return nil end
	for _, name in names do
		if types[name] ~= nil then
			return types[name]
		end
	end
	return nil
end

local animationMatches = {}
local function matchAnimation(key, groups, reject)
	local cached = animationMatches[key]
	if cached ~= nil then
		return cached or nil
	end
	local types = bedwars.AnimationType
	if type(types) ~= 'table' then return nil end

	local found
	for _, words in groups do
		for name, value in types do
			
			if type(name) ~= 'string' then continue end
			local lowered = name:lower()
			local hit = true
			for _, word in words do
				if not lowered:find(word, 1, true) then
					hit = false
					break
				end
			end
			if hit and reject then
				for _, word in reject do
					if lowered:find(word, 1, true) then
						hit = false
						break
					end
				end
			end
			if hit then
				found = value
				break
			end
		end
		if found ~= nil then break end
	end

	if found == nil then
		animationMatches[key] = false
	else
		animationMatches[key] = found
	end
	return found
end

local function removeTags(str)
	str = str:gsub('<br%s*/>', '\n')
	return (str:gsub('<[^<>]->', ''))
end

local function formatNumber(value)
	local text = tostring(math.floor(tonumber(value) or 0))
	local sign = ''
	if text:sub(1, 1) == '-' then
		sign, text = '-', text:sub(2)
	end
	local out = text:reverse():gsub('(%d%d%d)', '%1,'):reverse()
	return sign..(out:gsub('^,', ''))
end

local function roundPos(vec)
	return Vector3.new(math.round(vec.X / 3) * 3, math.round(vec.Y / 3) * 3, math.round(vec.Z / 3) * 3)
end

local function switchItem(tool, delayTime)
	delayTime = delayTime or 0.05
	local check = lplr.Character and lplr.Character:FindFirstChild('HandInvItem') or nil
	if check and check.Value ~= tool and tool.Parent ~= nil then
		task.spawn(function()
			bedwars.Client:Get(remotes.EquipItem):CallServerAsync({hand = tool})
		end)
		check.Value = tool
		if delayTime > 0 then
			task.wait(delayTime)
		end
		return true
	end
end
getgenv().switchItem = switchItem

local function waitForChildOfType(obj, name, timeout, prop)
	local check, returned = tick() + timeout, nil
	repeat
		returned = prop and obj[name] or obj:FindFirstChildOfClass(name)
		if returned and returned.Name ~= 'UpperTorso' or check < tick() then
			break
		end
		task.wait()
	until false
	return returned
end

local function waitForChildYield(obj, timeout, ...)
	local check, returned = tick(), obj
	for _, v in { ... } do
		if not returned then
			break
		end
		check = tick() + timeout
		repeat
			local new = returned:FindFirstChild(v)
			if new or tick() > check then
				returned = new
				break
			end
			task.wait()
		until false
	end
	return returned
end

local function rakNetCheck(module)
	if not (raknet and raknet.add_send_hook and pcall(raknet.add_send_hook, function() end)) then
		notif(module, 'This feature requires raknet! (risky feature, please do not use on mains.)', 10, 'warning')
		return false
	end

	return true
end

local frictionTable, oldfrict = {}, {}
local frictionConnection
local frictionState

local function modifyVelocity(v)
	if v:IsA('BasePart') and v.Name ~= 'HumanoidRootPart' and not oldfrict[v] then
		oldfrict[v] = v.CustomPhysicalProperties or 'none'
		v.CustomPhysicalProperties = PhysicalProperties.new(0.0001, 0.2, 0.5, 1, 1)
	end
end

local function updateVelocity(force)
	local newState = getTableSize(frictionTable) > 0
	if frictionState ~= newState or force then
		if frictionConnection then
			frictionConnection:Disconnect()
		end
		if newState then
			if entitylib.isAlive then
				for _, v in entitylib.character.Character:GetDescendants() do
					modifyVelocity(v)
				end
				frictionConnection = entitylib.character.Character.DescendantAdded:Connect(modifyVelocity)
			end
		else
			for i, v in oldfrict do
				i.CustomPhysicalProperties = v ~= 'none' and v or nil
			end
			table.clear(oldfrict)
		end
	end
	frictionState = newState
end

local kitorder = {
	hannah = 5,
	spirit_assassin = 4,
	dasher = 3,
	jade = 2,
	regent = 1
}

local getBlockHits
local sortmethods, breakmethods = {
	Damage = function(a, b)
		return a.Entity.Character:GetAttribute('LastDamageTakenTime') < b.Entity.Character:GetAttribute('LastDamageTakenTime')
	end,
	Threat = function(a, b)
		return getStrength(a.Entity) > getStrength(b.Entity)
	end,
	Kit = function(a, b)
		return (a.Entity.Player and kitorder[a.Entity.Player:GetAttribute('PlayingAsKit')] or 0) > (b.Entity.Player and kitorder[b.Entity.Player:GetAttribute('PlayingAsKit')] or 0)
	end,
	Health = function(a, b)
		return a.Entity.Health < b.Entity.Health
	end,
	Angle = function(a, b)
		local selfrootpos = entitylib.character.RootPart.Position
		local localfacing = entitylib.character.RootPart.CFrame.LookVector * Vector3.new(1, 0, 1)
		local angle = math.acos(localfacing:Dot(((a.Entity.RootPart.Position - selfrootpos) * Vector3.new(1, 0, 1)).Unit))
		local angle2 = math.acos(localfacing:Dot(((b.Entity.RootPart.Position - selfrootpos) * Vector3.new(1, 0, 1)).Unit))
		return angle < angle2
	end,
	Mouse = function(a, b)
		local mouse = lplr:GetMouse()
		local origin = Vector2.new(mouse.X, mouse.Y)

		local posa, visa = gameCamera:WorldToScreenPoint(a.Entity.RootPart.Position)
		local posb, visb = gameCamera:WorldToScreenPoint(b.Entity.RootPart.Position)
		local dista = visa and (Vector2.new(posa.X, posa.Y) - origin).Magnitude or math.huge
        local distb = visb and (Vector2.new(posb.X, posb.Y) - origin).Magnitude or math.huge
        return (dista == dista and dista or math.huge) < (distb == distb and distb or math.huge)
	end
}, {
	Health = function(...)
		return getBlockHits(...)
	end,
	Distance = function(a)
		local pos = (entitylib.isAlive and (entitylib.character.RootPart.Position - Vector3.new(0, 1, 0)) or Vector3.zero)
		return (pos - Vector3.new(a.Position.X, pos.Y, a.Position.Z)).Magnitude
	end
}

local function screenPriorityDistance(entry, origin)
	local ent = entry and entry.Entity
	local root = ent and ent.RootPart
	if not root then return math.huge end
	local point, visible = gameCamera:WorldToViewportPoint(root.Position)
	if not visible then return math.huge end
	return (Vector2.new(point.X, point.Y) - origin).Magnitude
end
sortmethods.None = function() return false end
sortmethods.Closest = function(a, b) return (a.Magnitude or math.huge) < (b.Magnitude or math.huge) end
sortmethods.Farthest = function(a, b) return (a.Magnitude or 0) > (b.Magnitude or 0) end
sortmethods['Lowest health'] = function(a, b) return (a.Entity.Health or math.huge) < (b.Entity.Health or math.huge) end
sortmethods['Highest health'] = function(a, b) return (a.Entity.Health or 0) > (b.Entity.Health or 0) end
sortmethods.Mouse = function(a, b)
	local origin = inputService:GetMouseLocation()
	return screenPriorityDistance(a, origin) < screenPriorityDistance(b, origin)
end
sortmethods.Crosshair = function(a, b)
	local origin = gameCamera.ViewportSize / 2
	return screenPriorityDistance(a, origin) < screenPriorityDistance(b, origin)
end
sortmethods.Distance = function(a, b)
	local selfpos = entitylib.isAlive and entitylib.character.RootPart.Position
	if not selfpos then return false end
	return (selfpos - a.Entity.RootPart.Position).Magnitude < (selfpos - b.Entity.RootPart.Position).Magnitude
end
sortmethods.Health = function(a, b)
	return (a.Entity.Health or math.huge) < (b.Entity.Health or math.huge)
end
sortmethods.Damage = function(a, b)
	local held = store.hand and store.hand.tool
	local meta = held and bedwars.ItemMeta and bedwars.ItemMeta[held.Name]
	local damage = (meta and meta.sword and tonumber(meta.sword.damage)) or 20
	if damage <= 0 then damage = 20 end
	return ((a.Entity.Health or math.huge) / damage) < ((b.Entity.Health or math.huge) / damage)
end
sortmethods.Angle = function(a, b)
	if not entitylib.isAlive or not entitylib.character or not entitylib.character.RootPart then return false end
	local look = gameCamera.CFrame.LookVector
	local selfpos = entitylib.character.RootPart.Position
	local function facing(entity)
		local root = entity.Entity.RootPart
		if not root then return -2 end
		local delta = root.Position - selfpos
		if delta.Magnitude <= 0.01 then return 1 end
		return look:Dot(delta.Unit)
	end
	return facing(a) > facing(b)
end
local threatCache, threatAt = {}, 0
local function threatScore(plr)
	if not plr then return -1 end
	local analyser = getgenv().EntityAnalyser
	if not analyser or analyser.Enabled ~= true then return -1 end
	local now = tick()
	if now - threatAt > 0.5 then
		threatAt = now
		table.clear(threatCache)
	end
	local cached = threatCache[plr]
	if cached then return cached end
	local ok, analysis = pcall(analyser.Analyse, analyser, plr)
	local score = ok and analysis and tonumber(analysis.OverallSkill)
	if not score then score = -1 end
	threatCache[plr] = score
	return score
end
sortmethods.Threat = function(a, b)
	return threatScore(a.Entity.Player) > threatScore(b.Entity.Player)
end
local TARGET_MODE_TOOLTIP = 'Who to prefer when several targets are in range\nCursor - nearest your cursor\nDistance - closest to you\nDamage - fewest hits to kill\nAngle - smallest turn to face\nLowest Health / Highest Health\nThreat - rated best by EntityAnalyser\nHit chance - easiest to hit'

shared.AetherScreenSorts = {[sortmethods.Mouse] = 'Mouse', [sortmethods.Crosshair] = 'Crosshair'}
sortmethods.Cursor = sortmethods.Mouse
sortmethods['Lowest Health'] = sortmethods['Lowest health']
sortmethods['Highest Health'] = sortmethods['Highest health']
do
	local flat = Vector3.new(1, 0, 1)
	local function missBudget(entry)
		local ent = entry and entry.Entity
		local root = ent and ent.RootPart
		if not root then return math.huge end
		local origin = entitylib.isAlive and entitylib.character.RootPart.Position or root.Position
		local flight = (root.Position - origin).Magnitude / 120
		local velocity = root.AssemblyLinearVelocity
		local budget = (velocity * flat).Magnitude * flight * 0.28 + flight * 4
		if ent.Humanoid and ent.Humanoid.FloorMaterial == Enum.Material.Air then
			budget += math.abs(velocity.Y) * flight * 0.12 + 2
		end
		return budget
	end
	sortmethods['Hit chance'] = function(a, b)
		return missBudget(a) < missBudget(b)
	end
end
local TARGET_MODES = {'Cursor', 'Distance', 'Damage', 'Angle', 'Lowest Health', 'Highest Health', 'Threat', 'Hit chance'}
local sortlist = {}
for _, name in ipairs(TARGET_MODES) do
	if sortmethods[name] then table.insert(sortlist, name) end
end
getgenv().sortlist = sortlist
local function getSortList()
	return table.clone(sortlist)
end

run(function()
	local oldstart = entitylib.start
	local function customEntity(ent)
		if ent:HasTag('inventory-entity') and not ent:HasTag('Monster') and not ent:HasTag('trainingRoomDummy') then
			return
		end

		entitylib.addEntity(ent, nil, ent:HasTag('Drone') and function(self)
			local droneplr = playersService:GetPlayerByUserId(self.Character:GetAttribute('PlayerUserId'))
			return not droneplr or lplr:GetAttribute('Team') ~= droneplr:GetAttribute('Team')
		end or function(self)
			return lplr:GetAttribute('Team') ~= self.Character:GetAttribute('Team')
		end)
	end

	entitylib.start = function()
		oldstart()
		if entitylib.Running then
			for _, ent in collectionService:GetTagged('entity') do
				customEntity(ent)
			end
			table.insert(entitylib.Connections, collectionService:GetInstanceAddedSignal('entity'):Connect(customEntity))
			table.insert(entitylib.Connections, collectionService:GetInstanceRemovedSignal('entity'):Connect(function(ent)
				entitylib.removeEntity(ent)
			end))
		end
	end

	entitylib.addPlayer = function(plr)
		if plr.Character then
			entitylib.refreshEntity(plr.Character, plr)
		end
		entitylib.PlayerConnections[plr] = {
			plr.CharacterAdded:Connect(function(char)
				entitylib.refreshEntity(char, plr)
			end),
			plr.CharacterRemoving:Connect(function(char)
				entitylib.removeEntity(char, plr == lplr)
			end),
			plr:GetAttributeChangedSignal('Team'):Connect(function()
				for _, v in entitylib.List do
					if v.Targetable ~= entitylib.targetCheck(v) then
						entitylib.refreshEntity(v.Character, v.Player)
					end
				end

				if plr == lplr then
					entitylib.start()
				else
					entitylib.refreshEntity(plr.Character, plr)
				end
			end)
		}
	end

	entitylib.addEntity = function(char, plr, teamfunc)
		if not char then return end
		entitylib.EntityThreads[char] = task.spawn(function()
			local hum, humrootpart, head
			if plr then
				hum = waitForChildOfType(char, 'Humanoid', 10)
				humrootpart = hum and waitForChildOfType(hum, 'RootPart', workspace.StreamingEnabled and 9e9 or 10, true)
				head = char:WaitForChild('Head', 10) or humrootpart
			else
				hum = {HipHeight = 0.5}
				humrootpart = waitForChildOfType(char, 'PrimaryPart', 10, true)
				head = humrootpart
			end
			local updateobjects = plr and plr ~= lplr and {
				char:WaitForChild('ArmorInvItem_0', 5),
				char:WaitForChild('ArmorInvItem_1', 5),
				char:WaitForChild('ArmorInvItem_2', 5),
				char:WaitForChild('HandInvItem', 5)
			} or {}

			if hum and humrootpart then
				local entity = {
					Connections = {},
					Character = char,
					Health = (char:GetAttribute('Health') or 100) + getShieldAttribute(char),
					Head = head,
					Humanoid = hum,
					HumanoidRootPart = humrootpart,
					HipHeight = hum.HipHeight + (humrootpart.Size.Y / 2) + (hum.RigType == Enum.HumanoidRigType.R6 and 2 or 0),
					Jumps = 0,
					JumpTick = tick(),
					Jumping = false,
					LandTick = tick(),
					MaxHealth = char:GetAttribute('MaxHealth') or 100,
					NPC = plr == nil,
					Player = plr,
					RootPart = humrootpart,
					TeamCheck = teamfunc
				}

				if plr == lplr then
					entity.AirTime = tick()
					entitylib.character = entity
					entitylib.isAlive = true
					entitylib.Events.LocalAdded:Fire(entity)
					table.insert(entitylib.Connections, char.AttributeChanged:Connect(function(attr)
						vapeEvents.AttributeChanged:Fire(attr)
					end))
				else
					entity.Targetable = entitylib.targetCheck(entity)
					if plr ~= nil then
						table.insert(entity.Connections, hum.AnimationPlayed:Connect(function(track)
							entitylib.Events.AnimationPlayed:Fire(plr, track)
						end))
					end

					for _, v in entitylib.getUpdateConnections(entity) do
						table.insert(entity.Connections, v:Connect(function()
							entity.Health = (char:GetAttribute('Health') or 100) + getShieldAttribute(char)
							entity.MaxHealth = char:GetAttribute('MaxHealth') or 100
							entitylib.Events.EntityUpdated:Fire(entity)
						end))
					end

					for _, v in updateobjects do
						table.insert(entity.Connections, v:GetPropertyChangedSignal('Value'):Connect(function()
							task.delay(0.1, function()
								if bedwars.getInventory then
									store.inventories[plr] = bedwars.getInventory(plr)
									entitylib.Events.EntityUpdated:Fire(entity)
								end
							end)
						end))
					end

					if plr then
						local anim = char:FindFirstChild('Animate')
						if anim then
							pcall(function()
								anim = anim.jump:FindFirstChildWhichIsA('Animation').AnimationId
								table.insert(entity.Connections, hum.Animator.AnimationPlayed:Connect(function(playedanim)
									if playedanim.Animation.AnimationId == anim then
										entity.JumpTick = tick()
										entity.Jumps += 1
										entity.LandTick = tick() + 1
										entity.Jumping = entity.Jumps > 1
									end
								end))
							end)
						end

						task.delay(0.1, function()
							if bedwars.getInventory then
								store.inventories[plr] = bedwars.getInventory(plr)
							end
						end)
					end
					table.insert(entitylib.List, entity)
					entitylib.Events.EntityAdded:Fire(entity)
				end

				table.insert(entity.Connections, char.ChildRemoved:Connect(function(part)
					if part == humrootpart or part == hum or part == head then
						if part == humrootpart and hum.RootPart then
							humrootpart = hum.RootPart
							entity.RootPart = hum.RootPart
							entity.HumanoidRootPart = hum.RootPart
							return
						end
						entitylib.removeEntity(char, plr == lplr)
					end
				end))
			end
			entitylib.EntityThreads[char] = nil
		end)
	end

	entitylib.getUpdateConnections = function(ent)
		local char = ent.Character
		local tab = {
			char:GetAttributeChangedSignal('Health'),
			char:GetAttributeChangedSignal('MaxHealth'),
			{
				Connect = function()
					ent.Friend = ent.Player and isFriend(ent.Player) or nil
					ent.Target = ent.Player and isTarget(ent.Player) or nil
					return {Disconnect = function() end}
				end
			}
		}

		if ent.Player then
			table.insert(tab, ent.Player:GetAttributeChangedSignal('PlayingAsKit'))
		end

		for name, val in char:GetAttributes() do
			if name:find('Shield') and type(val) == 'number' then
				table.insert(tab, char:GetAttributeChangedSignal(name))
			end
		end

		return tab
	end

	entitylib.targetCheck = function(ent)
		if ent.TeamCheck then
			return ent:TeamCheck()
		end
		if ent.NPC then return true end
		if isFriend(ent.Player) then return false end
		if not select(2, whitelist:get(ent.Player)) then return false end
		return lplr:GetAttribute('Team') ~= ent.Player:GetAttribute('Team')
	end
	vape:Clean(entitylib.Events.LocalAdded:Connect(updateVelocity))
end)
entitylib.start()

local require, debug = require, debug
local function upvalueAvailable(func, index)
	if type(func) ~= 'function' or type(debug) ~= 'table' or type(debug.getupvalue) ~= 'function' then
		return false
	end
	return pcall(debug.getupvalue, func, index)
end
local function safeUpvalue(func, index, key)
	if type(func) ~= 'function' or type(debug) ~= 'table' or type(debug.getupvalue) ~= 'function' then
		return nil
	end
	local function read(at)
		local res = table.pack(pcall(debug.getupvalue, func, at))
		if not res[1] then return nil end
		if res.n >= 3 then return res[3] end
		return res[2]
	end
	local value = read(index)
	if key == nil then return value end
	if type(value) == 'table' and rawget(value, key) ~= nil then return value end
	for at = 1, 24 do
		value = read(at)
		if type(value) == 'table' and rawget(value, key) ~= nil then return value end
	end
	return nil
end
shared.gg = {}
run(function()
	canDebug = not table.find({'Solara', 'Xeno'}, (identifyexecutor and ({identifyexecutor()})[1]) or '') and true or false
	if not canDebug then
		local cheatenginelib = loadstring(downloadFile('aetherv2/libraries/cheatenginelib.lua'), 'cheatenginelib')(vape, vapeEvents, entitylib)
		require = function(v)
			return cheatenginelib[({v:GetFullName():gsub(lplr.Name, 'PlayerTemplate')})[1]]:await()
		end
		debug = setmetatable({getproto = function() return function() end end}, {
			__index = function(self, index)
				self[index] = function() end
				return self[index]
			end
		})
	end
end)

local CheatersFlagged = {}
run(function()
	
	local KnitInit, Knit
	local knitDeadline = tick() + 45
	repeat
		KnitInit, Knit = pcall(function()
			return require(replicatedStorage.rbxts_include.node_modules["@easy-games"].knit.src).KnitClient
		end)
		if KnitInit and Knit then break end
		task.wait()
	until tick() > knitDeadline
	if not (KnitInit and Knit) then
		error('BedWars Knit never became available - the game has not finished loading')
	end

	if canDebug and not upvalueAvailable(Knit.Start, 1) then
		local upvalueDeadline = tick() + 15
		repeat task.wait() until upvalueAvailable(Knit.Start, 1) or tick() > upvalueDeadline
		if not upvalueAvailable(Knit.Start, 1) then
			
			warn('[AetherV2] debug.getupvalue is unavailable here - modules that need it are disabled')
			canDebug = false
		end
	end

	local Flamework = require(replicatedStorage['rbxts_include']['node_modules']['@flamework'].core.out).Flamework
	local igniteDeadline = tick() + 45
	repeat
		local ok, ignited = pcall(debug.getupvalue, Flamework.ignite, 1)
		if not ok or type(ignited) ~= 'boolean' or ignited then break end
		task.wait(0.1)
	until tick() > igniteDeadline
	local controllers = {Built = {}, Ids = {
		'@easy-games/game-core:client/controllers/ability/ability-controller@AbilityController',
		'client/controllers/game/kill-feed/kill-feed-controller@KillFeedController',
		'@easy-games/game-core:client/controllers/notification-controller@NotificationController',
		'@easy-games/lobby:client/controllers/party-controller@PartyController'
	}}
	local function findController(id, again)
		if again or not controllers.Scanned then
			controllers.Scanned = true
			local delta = false
			if identifyexecutor then
				local named, executor = pcall(identifyexecutor)
				delta = named and tostring(executor):lower():find('delta', 1, true) ~= nil
			end
			local ok, core = pcall(function()
				return require(replicatedStorage['rbxts_include']['node_modules']['@flamework'].core.out)
			end)
			local known = ok and type(core) == 'table' and type(core.Reflect) == 'table' and core.Reflect.idToObj or nil
			local singletons
			if delta and ok and type(core) == 'table' and type(core.Modding) == 'table' and type(core.Modding.getSingletons) == 'function' then
				local got, map = pcall(core.Modding.getSingletons)
				singletons = got and type(map) == 'table' and map or nil
			end
			local classes, left = {}, 0
			if type(known) == 'table' and (delta or getgc) then
				for _, wanted in again or controllers.Ids do
					local class = known[wanted]
					if type(class) == 'table' and not classes[class] then
						local built = singletons and rawget(singletons, class)
						if type(built) == 'table' and getmetatable(built) == class then
							controllers.Built[wanted] = built
						else
							classes[class] = wanted
							left += 1
						end
					end
				end
			end
			if left > 0 and not delta and getgc then
				for _, v in getgc(true) do
					if type(v) == 'table' then
						local meta = getmetatable(v)
						local wanted = meta ~= nil and classes[meta]
						if wanted then
							controllers.Built[wanted] = v
							classes[meta] = nil
							left -= 1
							if left == 0 then break end
						end
					end
				end
			end
		end
		return id and controllers.Built[id] or nil
	end
	local missingControllers = {}
	local function resolveController(id)
		local found = findController(id)
		if found then return found end
		local ok, result = pcall(Flamework.resolveDependency, id)
		if ok and result ~= nil then return result end
		local name = id:match('@(%w+)$') or id
		warn('[AetherV2] '..name..' is not built yet, looking for it again when it is used: '..tostring(result))
		local info = {Id = id, Tries = 0, Next = 0}
		local function real()
			if info.Real then return info.Real end
			if tick() >= info.Next and (info.Walks or 0) < 12 then
				info.Walks = (info.Walks or 0) + 1
				info.Next = tick() + 5
				controllers.Built[id] = nil
				info.Real = findController(nil, {id}) or findController(id)
			end
			return info.Real
		end
		local fallback = {}
		if name == 'AbilityController' then
			local net
			pcall(function()
				local class = require(replicatedStorage['rbxts_include']['node_modules']['@flamework'].core.out).Reflect.idToObj[id]
				for i = 1, 8 do
					local ok2, v = pcall(debug.getupvalue, class.useAbility, i)
					if ok2 and type(v) == 'table' and type(v.client) == 'table' and v.client.useAbility then
						net = v.client
						break
					end
				end
			end)
			local used = {}
			fallback.canUseAbility = function(_, ability)
				return net ~= nil and tick() - (used[ability] or 0) >= 1
			end
			fallback.useAbility = function(_, ability, ...)
				if not net or tick() - (used[ability] or 0) < 1 then return false end
				used[ability] = tick()
				return (pcall(function(...) net.useAbility:fire(ability, ...) end, ...))
			end
		end
		local stub = setmetatable({}, {
			__index = function(_, key)
				local found = real()
				if found then
					local value = found[key]
					if type(value) == 'function' then
						return function(_, ...) return value(found, ...) end
					end
					return value
				end
				return fallback[key] or function() end
			end
		})
		info.Stub = stub
		info.Lookup = real
		missingControllers[name] = info
		return stub
	end
	local InventoryUtil = require(replicatedStorage.TS.inventory['inventory-util']).InventoryUtil
	local Client = require(replicatedStorage.TS.remotes).default.Client
	local OldGet, OldBreak, OldHit = Client.Get, nil, nil

	bedwars = setmetatable({
		AbilityController = resolveController('@easy-games/game-core:client/controllers/ability/ability-controller@AbilityController'),
		AbilityIndicatorUtil = require(replicatedStorage.TS.games.bedwars.items['ability-indicator']['ability-indicator-util']).AbilityIndicatorUtil,
		AnimationType = require(replicatedStorage.TS.animation['animation-type']).AnimationType,
		AdetundeUpgradeMeta = require(replicatedStorage.TS.games.bedwars.items['frosty-hammer']['frosty-hammer-upgrades']).FrostyHammerUpgradeMeta,
		AdetundeUtil = require(replicatedStorage.TS.games.bedwars.items['frosty-hammer']['frosty-hammer-util']).FrostyHammerUtil,
		AnimationUtil = require(replicatedStorage['rbxts_include']['node_modules']['@easy-games']['game-core'].out['shared'].util['animation-util']).AnimationUtil,
		AppController = require(replicatedStorage['rbxts_include']['node_modules']['@easy-games']['game-core'].out.client.controllers['app-controller']).AppController,
		ArmorTrimColor = require(replicatedStorage.TS['armor-trim']['armor-trim-colors']).ArmorTrimColor,
		ArmorTrimColorMeta = require(replicatedStorage.TS['armor-trim']['armor-trim-color-meta']).ArmorTrimColorMeta,
		ArmorTrimEffectMeta = require(replicatedStorage.TS['armor-trim']['armor-trim-effect-meta']).ArmorTrimEffectMeta,
		ArmorTrimEffectRankMeta = require(replicatedStorage.TS['armor-trim']['armor-trim-rank']).ArmorTrimEffectRankMeta,
		ArmorTrimEffectType = require(replicatedStorage.TS['armor-trim']['armor-trim-effect-type']).ArmorTrimEffectType,
		ArmorTrimMeta = require(replicatedStorage.TS['armor-trim']['armor-trim-meta']).ArmorTrimMeta,
		ArmorTrimType = require(replicatedStorage.TS['armor-trim']['armor-trim-type']).ArmorTrimType,
		ArmorTrimUtil = require(replicatedStorage.TS['armor-trim']['armor-trim-util']).ArmorTrimUtil,
		AccessoryUtil = require(replicatedStorage.TS.util['accessory-util']).AccessoryUtil,
		BedBreakEffectMeta = require(replicatedStorage.TS.locker['bed-break-effect']['bed-break-effect-meta']).BedBreakEffectMeta,
		BedwarsKitMeta = require(replicatedStorage.TS.games.bedwars.kit['bedwars-kit-meta']).BedwarsKitMeta,
		BedwarsKitSkin = canDebug and safeUpvalue(require(replicatedStorage.TS.games.bedwars['kit-skin']['bedwars-kit-skin-meta']).getKitSkinMetadata, 1) or {},
		BlockBreaker = Knit.Controllers.BlockBreakController.blockBreaker,
		BlockController = require(replicatedStorage['rbxts_include']['node_modules']['@easy-games']['block-engine'].out).BlockEngine,
		BlockEngine = require(lplr.PlayerScripts.TS.lib['block-engine']['client-block-engine']).ClientBlockEngine,
		BlockPlacer = require(replicatedStorage['rbxts_include']['node_modules']['@easy-games']['block-engine'].out.client.placement['block-placer']).BlockPlacer,
		BlockSelector = require(replicatedStorage.rbxts_include.node_modules['@easy-games']['block-engine'].out.client.select['block-selector']).BlockSelector,
		BowConstantsTable = canDebug and safeUpvalue(Knit.Controllers.ProjectileController.enableBeam, 8, 'RelX') or {RelX = 0, RelY = 0, RelZ = 0},
		ClickHold = require(replicatedStorage['rbxts_include']['node_modules']['@easy-games']['game-core'].out.client.ui.lib.util['click-hold']).ClickHold,
		Client = Client,
		ClientConstructor = require(replicatedStorage['rbxts_include']['node_modules']['@rbxts'].net.out.client),
		ClientDamageBlock = require(replicatedStorage['rbxts_include']['node_modules']['@easy-games']['block-engine'].out.shared.remotes).BlockEngineRemotes.Client,
		CombatConstant = require(replicatedStorage.TS.combat['combat-constant']).CombatConstant,
		DamageIndicator = Knit.Controllers.DamageIndicatorController.spawnDamageIndicator,
		DefaultKillEffect = require(lplr.PlayerScripts.TS.controllers.global.locker['kill-effect'].effects['default-kill-effect']),
		EnchantMeta = require(replicatedStorage.TS.enchant['enchant-meta']).EnchantMeta,
		EmoteType = require(replicatedStorage.TS.locker.emote['emote-type']).EmoteType,
		GamePlayer = require(replicatedStorage.TS.player['game-player']),
		GameAnimationUtil = require(replicatedStorage.TS.animation['animation-util']).GameAnimationUtil,
		getIcon = function(item, showinv)
			local itemmeta = bedwars.ItemMeta[item.itemType]
			return itemmeta and showinv and itemmeta.image or ''
		end,
		getInventory = function(plr)
			local suc, res = pcall(function()
				return InventoryUtil.getInventory(plr)
			end)
			return suc and res or {
				items = {},
				armor = {}
			}
		end,
		
		Handler = (function()
			local cache = {}
			local api = {}
			local limits = {}

			local function rateLimit(remoteName)
				if limits[remoteName] then return limits[remoteName] end
				local found = false
				pcall(function()
					local remotes = require(replicatedStorage.TS.remotes).default
					local construct, defined = next(debug.getupvalue(getrawmetatable(remotes.Server).Get, 1))
					local global = debug.getupvalue(construct.globalMiddleware[2], 1)
					if type(global) == 'table' and type(global[remoteName]) == 'number' then
						found = global[remoteName]
						return
					end
					local middleware = defined[remoteName] and defined[remoteName].ServerMiddleware
					if type(middleware) ~= 'table' then return end
					for _, check in middleware do
						if type(check) == 'function' and #debug.getupvalues(check) >= 6
							and tostring(debug.getupvalue(check, 6)):find('Request limit') then
							local value = debug.getupvalue(check, 3)
							if type(value) == 'number' then found = value end
							break
						end
					end
				end)
				limits[remoteName] = found or 60 / 0.289
				return limits[remoteName]
			end

			function api:Get(remoteName)
				local entry = cache[remoteName]
				if entry then return entry end

				local ok, remote = pcall(function()
					return bedwars.Client:Get(remoteName)
				end)
				remote = ok and remote or nil

				entry = {
					Remote = remote,
					instance = remote and remote.instance or nil,
					Fire = function(_, method, ...)
						if not remote then
							error('remote "'..tostring(remoteName)..'" is unavailable', 0)
						end
						local call = method and remote[method]
						if not method then
							call = remote.CallServer or remote.CallServerAsync or remote.SendToServer
						end
						if not call then
							error('remote "'..tostring(remoteName)..'" has no '..tostring(method), 0)
						end
						return call(remote, ...)
					end,
					GetRateLimit = function()
						return rateLimit(remoteName)
					end
				}

				if remote then
					cache[remoteName] = entry
				end
				return entry
			end

			return api
		end)(),
		HudAliveCount = require(lplr.PlayerScripts.TS.controllers.global['top-bar'].ui.game['hud-alive-player-counts']).HudAlivePlayerCounts,
		ItemMeta = require(replicatedStorage.TS.item['item-meta']).items,
		KillEffectMeta = require(replicatedStorage.TS.locker['kill-effect']['kill-effect-meta']).KillEffectMeta,
		KillFeedController = resolveController('client/controllers/game/kill-feed/kill-feed-controller@KillFeedController'),
		Knit = Knit,
		KnockbackUtil = require(replicatedStorage.TS.damage['knockback-util']).KnockbackUtil,
		MageKitUtil = require(replicatedStorage.TS.games.bedwars.kit.kits.mage['mage-kit-util']).MageKitUtil,
		NotificationController = resolveController('@easy-games/game-core:client/controllers/notification-controller@NotificationController'),
		NametagController = Knit.Controllers.NametagController,
		PartyController = resolveController('@easy-games/lobby:client/controllers/party-controller@PartyController'),
		ProjectileMeta = require(replicatedStorage.TS.projectile['projectile-meta']).ProjectileMeta,
		QueryUtil = require(replicatedStorage['rbxts_include']['node_modules']['@easy-games']['game-core'].out).GameQueryUtil,
		QueueCard = require(lplr.PlayerScripts.TS.controllers.global.queue.ui['queue-card']).QueueCard,
		QueueMeta = require(replicatedStorage.TS.game['queue-meta']).QueueMeta,
		Roact = require(replicatedStorage['rbxts_include']['node_modules']['@rbxts']['roact'].src),
		RankMeta = require(replicatedStorage.TS.rank['rank-meta']).RankMeta,
		RuntimeLib = require(replicatedStorage['rbxts_include'].RuntimeLib),
		SummonerKitBalance = require(replicatedStorage.TS.games.bedwars.kit.kits.summoner['summoner-kit-balance']).SummonerKitBalance,
		SummonerUtil = require(replicatedStorage.TS.games.bedwars.kit.kits.summoner['summoner-kit-util']),
		StatusEffectUtil = require(replicatedStorage.TS['status-effect']['status-effect-util']).StatusEffectUtil,
		StatusEffectMeta = require(replicatedStorage.TS['status-effect']['status-effect-type']).StatusEffectType,
		SorcererBalance = require(replicatedStorage.TS.balance['sorcerer-balance']).SorcererBalance,
		SyncEvents = require(lplr.PlayerScripts.TS['client-sync-events']).ClientSyncEvents,
		SharedConstants = canDebug and require(replicatedStorage.TS['shared-constants']).CpsConstants or {},
		SoundList = require(replicatedStorage.TS.sound['game-sound']).GameSound,
		SoundManager = require(replicatedStorage['rbxts_include']['node_modules']['@easy-games']['game-core'].out).SoundManager,
		Store = require(lplr.PlayerScripts.TS.ui.store).ClientStore,
		TeamUpgradeMeta = canDebug and safeUpvalue(require(replicatedStorage.TS.games.bedwars['team-upgrade']['team-upgrade-meta']).getTeamUpgradeMetaForQueue, 7) or {},
		UILayers = require(replicatedStorage['rbxts_include']['node_modules']['@easy-games']['game-core'].out).UILayers,
		VisualizerUtils = require(lplr.PlayerScripts.TS.lib.visualizer['visualizer-utils']).VisualizerUtils,
		WeldTable = require(replicatedStorage.TS.util['weld-util']).WeldUtil,
		WinEffectMeta = require(replicatedStorage.TS.locker['win-effect']['win-effect-meta']).WinEffectMeta,
		ZapNetworking = require(lplr.PlayerScripts.TS.lib.network)
	}, {
		__index = function(self, ind)
			rawset(self, ind, Knit.Controllers[ind])
			return rawget(self, ind)
		end
	})
	getgenv().bedwars = bedwars
	store.isDisguised = function(ent)
		if not (ent and ent.Player) then return false end
		local ok, model = pcall(function()
			return bedwars.BlockDisguiseController:getPlayerBlockModel(ent.Player)
		end)
		return ok and model ~= nil
	end

	store.readyHold = getgenv().matchDodgeHold or store.readyHold or {Held = false, Claimed = false}
	if not store.readyHold.Release then
		store.readyHold.Release = function()
			store.readyHold.Held = false
			getgenv().dodged = false
		end
	end
	if store.readyHold.Held then
		task.spawn(function()
			repeat task.wait(1) until vape.Loaded or vape.Loaded == nil
			while store.readyHold.Held and vape.Loaded do
				local dodge, region = vape.Modules.AutoMatchDodge, vape.Modules.RegionLock
				if not (dodge and dodge.Enabled) and not (region and region.Enabled) then
					store.readyHold.Release()
					break
				end
				task.wait(2)
			end
		end)
	end
	vape:Clean(function()
		store.readyHold.Release()
	end)
	for name, get in {
		BlackMarketeerBalance = function() return require(replicatedStorage.TS.balance['black-marketeer-balance']).BlackMarketeerBalance end,
		IdUtil = function() return require(replicatedStorage.TS.util['id-util']).IdUtil end,
		GamePlayerUtil = function() return require(replicatedStorage.TS.player['player-util']).GamePlayerUtil end,
		EmoteDisplayMeta = function() return require(replicatedStorage.TS.locker.emote['emote-display-meta']).EmoteDisplayMeta end,
		EmoteMeta = function() return require(replicatedStorage.TS.locker.emote['emote-meta']).EmoteMeta end,
		ImageList = function() return require(replicatedStorage.TS.image['image-id']).BedwarsImageId end,
		TaliyahUtil = function() return require(replicatedStorage.TS.games.bedwars.kit.kits.taliyah['taliyah-util']).TaliyahUtil end,
		DamageType = function() return require(replicatedStorage.TS.damage['damage-type']).DamageType end,
		Images = function() return require(replicatedStorage.TS.asphalt.generated.images) end,
		WizardUtil = function() return require(replicatedStorage.TS.games.bedwars.kit.kits.wizard['wizard-util']).WizardUtil end,
		AudioManager = function() return require(replicatedStorage['rbxts_include']['node_modules']['@easy-games']['game-core'].out).AudioManager end
	} do
		if rawget(bedwars, name) == nil then
			local ok, value = pcall(get)
			if ok then rawset(bedwars, name, value) end
		end
	end
	if rawget(bedwars, 'SoundManager') == nil and type(rawget(bedwars, 'AudioManager')) == 'table' then
		rawset(bedwars, 'SoundManager', {
			playSound = function(_, sound, options)
				return bedwars.AudioManager:playAudio(sound, options)
			end
		})
	end
	if not rawget(bedwars, 'IdUtil') then
		rawset(bedwars, 'IdUtil', {generateId = function() return httpService:GenerateGUID(false) end})
	end

	bedwars.itemPickerSets = {
		shop = function()
			local set = {}
			pcall(function()
				for _, item in require(replicatedStorage.TS.games.bedwars.shop['bedwars-shop']).BedwarsShop.ShopItems do
					if type(item) == 'table' and item.itemType then
						set[item.itemType] = true
					end
				end
			end)
			return set
		end,
		resources = function()
			return {iron = true, diamond = true, emerald = true, gold = true, void_crystal = true}
		end,
		wool = function()
			local set = {}
			for id in bedwars.ItemMeta or {} do
				if type(id) == 'string' and id:find('^wool_') then
					set[id] = true
				end
			end
			return set
		end,
		fish = function()
			local set = {}
			pcall(function()
				local seen = {}
				local function walk(tab)
					if seen[tab] then return end
					seen[tab] = true
					if type(tab.itemType) == 'string' then
						set[tab.itemType] = true
					end
					for _, v in tab do
						if type(v) == 'table' then
							walk(v)
						end
					end
				end
				walk(require(replicatedStorage.TS.kit.fisherman['fisherman-drops']))
			end)
			return set
		end
	}
	bedwars.itemPickerList = function(filter, opts)
		opts = opts or {}
		local relevant
		if opts.Relevant then
			relevant = {}
			for _, kind in opts.Relevant do
				local make = bedwars.itemPickerSets[kind]
				for id in make and make() or {} do
					relevant[id] = true
				end
			end
		end
		local function variant(id)
			return id:find('^og_') or id:find('^lobby_') or id:find('^royale_') or id:find('_charging$') or id:find('_mesh_block$')
		end
		local best = {}
		for id, meta in bedwars.ItemMeta or {} do
			if type(id) == 'string' and type(meta) == 'table' and (not filter or filter(id, meta)) then
				local keep = opts.Keep and table.find(opts.Keep, id)
				local image = type(meta.image) == 'string' and meta.image ~= '' and meta.image or nil
				local label = tostring(meta.displayName or id)
				if keep or ((not relevant or relevant[id]) and image and not variant(id) and not label:find('%?$')) then
					local score = (keep and 8 or 0) + (relevant and relevant[id] and 4 or 0) + (image and 2 or 0) + (variant(id) and 0 or 1)
					local current = best[label]
					if not current or score > current.Score or (score == current.Score and #id < #current.Name) then
						best[label] = {Name = id, Image = image, Label = label, Score = score}
					end
				end
			end
		end
		local list = {}
		for _, entry in best do
			entry.Score = nil
			table.insert(list, entry)
		end
		table.sort(list, function(a, b)
			return a.Label < b.Label
		end)
		return list
	end

	bedwars.getShotData = function(itemType)
		local meta = bedwars.ItemMeta[itemType]
		local source = meta and meta.projectileSource
		return {
			shotId = bedwars.IdUtil.generateId(8),
			drawDurationSec = math.max(1, source and source.maxStrengthChargeSec or 0)
		}
	end

	do
		local tinker = {}
		bedwars.getTinkerMount = function()
			local controller = bedwars.TinkerKitController
			local mount = controller and controller.userMap and controller.userMap[lplr]
			if typeof(mount) == 'Instance' and mount.Parent then return mount end
			local character = lplr.Character
			if not character then return nil end
			if tinker.Character ~= character then
				if tinker.Added then
					tinker.Added:Disconnect()
					tinker.Removed:Disconnect()
				end
				local function changed()
					tinker.Dirty = true
				end
				tinker.Character, tinker.Dirty = character, true
				tinker.Added = character.ChildAdded:Connect(changed)
				tinker.Removed = character.ChildRemoved:Connect(changed)
			end
			if tinker.Dirty then
				tinker.Dirty, tinker.Mount = false, nil
				for _, v in character:GetChildren() do
					if v:IsA('Model') and v.Name:match('tinker$') then
						tinker.Mount = v
						break
					end
				end
			end
			return tinker.Mount
		end
		vape:Clean(function()
			if tinker.Added then
				tinker.Added:Disconnect()
				tinker.Removed:Disconnect()
			end
		end)
	end

	bedwars.swingSound = function(config)
		local now = tick()
		if now - (store.swingSoundAt or 0) >= 0.3 then
			store.swingSoundAt = now
			return config
		end
		config = config and table.clone(config) or {}
		config.playSound = false
		return config
	end
	bedwars.swingEffect = function(meta, config)
		return bedwars.SwordController:playSwordEffect(meta, false, bedwars.swingSound(config))
	end
	bedwars.swordSound = function(meta, itemSkin, gap)
		local now = tick()
		if now - (store.swingSoundAt or 0) < (gap or 0.2) then return end
		local sounds = meta and meta.sword and meta.sword.swingSounds
		if itemSkin and bedwars.getItemSkinMeta then
			local ok, skin = pcall(bedwars.getItemSkinMeta, itemSkin)
			if ok and skin and skin.sword and skin.sword.swingSounds then
				sounds = skin.sword.swingSounds
			end
		end
		if not sounds and bedwars.SoundList then
			sounds = {bedwars.SoundList.SWORD_SWING_1, bedwars.SoundList.SWORD_SWING_2}
		end
		if not sounds or #sounds == 0 then return end
		store.swingSoundAt = now
		pcall(bedwars.AudioManager.playAudio, bedwars.AudioManager, sounds[math.random(1, #sounds)])
	end
	store.swordSpeedCache = {}
	bedwars.swordSpeed = function(itemType, base)
		base = base or 0.3
		local sync = bedwars.SyncEvents and bedwars.SyncEvents.SwordSwing
		if not itemType or not sync or type(sync.constructEvent) ~= 'function' then return base end
		local cached = store.swordSpeedCache[itemType]
		local now = tick()
		if cached and now - cached.At < 0.1 then return cached.Speed, cached.Cancelled end
		local ok, event = pcall(sync.constructEvent, sync, {nil, itemType, base, nil, {}})
		if not ok or type(event) ~= 'table' then return base end
		for _, entry in sync:getPrioritySortedEntries() do
			if entry.priority >= 150 then break end
			pcall(entry.callbackInfo.callback, event)
		end
		local speed = tonumber(event.attackSpeed) or base
		local cancelled = type(event.isCancelled) == 'function' and event:isCancelled() or false
		store.swordSpeedCache[itemType] = {At = now, Speed = speed, Cancelled = cancelled}
		return speed, cancelled
	end
	bedwars.gatedSwing = function(fn, ...)
		local controller = bedwars.SwordController
		local current = controller.playSwordEffect
		local gate = function(self, meta, charged, config)
			return current(self, meta, charged, bedwars.swingSound(config))
		end
		controller.playSwordEffect = gate
		task.spawn(fn, ...)
		if controller.playSwordEffect == gate then
			controller.playSwordEffect = current
		end
	end

	if debug.getupvalues then
		task.spawn(function()
			local function noop() end
			local checked = setmetatable({}, {__mode = 'k'})
			repeat
				task.wait(2)
				local maid = bedwars.ViewmodelController and bedwars.ViewmodelController.heldItemMaid
				local tasks = type(maid) == 'table' and rawget(maid, '_tasks')
				if type(tasks) == 'table' then
					local count = #tasks
					local from = checked[tasks] or 1
					if from > count + 1 then from = 1 end
					local settled = true
					for i = from, count do
						local item = tasks[i]
						if type(item) == 'function' and item ~= noop then
							local ok, up = pcall(debug.getupvalues, item)
							local track = ok and type(up) == 'table' and up[2]
							if typeof(track) == 'Instance' and track:IsA('AnimationTrack') then
								if up[1] == true then
									tasks[i] = noop
								elseif up[1] == false then
									settled = false
								end
							end
						end
						if settled then from = i + 1 end
					end
					checked[tasks] = from
				end
			until vape.Loaded == nil
		end)
	end

	bedwars.watchProjectile = function(refId, origin, velocity, gravity, target, lifetime)
		local character = target and target.Character
		if not character or velocity.Magnitude <= 0 then return end
		local overlap = OverlapParams.new()
		overlap.FilterType = Enum.RaycastFilterType.Include
		overlap.FilterDescendantsInstances = {character}
		local box = Vector3.new(3, 1, 3)
		local drop = Vector3.new(0, -gravity, 0)
		local steps = math.clamp(math.ceil(velocity.Magnitude / 170), 1, 16)
		local started = os.clock()
		local last = origin
		local watcher
		watcher = runService.Heartbeat:Connect(function()
			local elapsed = os.clock() - started
			if elapsed > (lifetime or 2) or not character.Parent then
				watcher:Disconnect()
				return
			end
			local position = origin + velocity * elapsed + drop * (0.5 * elapsed * elapsed)
			for step = 1, steps do
				if #workspace:GetPartBoundsInBox(CFrame.new(last:Lerp(position, step / steps)), box, overlap) > 0 then
					watcher:Disconnect()
					pcall(function()
						bedwars.Handler:Get('ProjectileHit'):Fire('SendToServer', refId, character)
					end)
					return
				end
			end
			if store.airRay and workspace:Raycast(last, position - last, store.airRay) then
				watcher:Disconnect()
				return
			end
			last = position
		end)
	end
	if next(missingControllers) then
		task.spawn(function()
			repeat
				task.wait(10)
				local wanted = {}
				for _, info in missingControllers do
					controllers.Built[info.Id] = nil
					table.insert(wanted, info.Id)
				end
				findController(nil, wanted)
				for name, info in missingControllers do
					info.Tries += 1
					local found = findController(info.Id)
					if found then
						info.Real = found
						if rawget(bedwars, name) == info.Stub then
							rawset(bedwars, name, found)
						end
					end
					if found or info.Tries >= 18 then
						missingControllers[name] = nil
					end
				end
			until not next(missingControllers) or vape.Loaded == nil
		end)
	end
	pcall(function()
		bedwars.TeamUpgradeUtil = require(replicatedStorage.TS.games.bedwars['team-upgrade']['team-upgrade-meta'])
	end)
	pcall(function()
		local folder = replicatedStorage.TS.games.bedwars['item-skin']
		bedwars.ItemSkinType = require(folder['item-skin-types']).ItemSkinType
		bedwars.getItemSkinMeta = require(folder['item-skin-meta']).getItemSkinMeta
	end)
	
	if not bedwars.AudioManager then
		bedwars.AudioManager = {
			playAudio = function(_, sound, options)
				if bedwars.SoundManager then return bedwars.SoundManager:playSound(sound, options) end
			end
		}
	end
	store.enchants = setmetatable({}, {
		__index = function(self, plr)
			return {
				async = function()
					if plr and plr.Character and bedwars.StatusEffectMeta and bedwars.EnchantMeta then
						for i in plr.Character:GetAttributes() do
							if i:find('StatusEffect_') and not i:find('_stacks') then
								local name = bedwars.StatusEffectMeta[({i:gsub('StatusEffect_', '')})[1]]
								if bedwars.StatusEffectMeta[name] then
									name = bedwars.StatusEffectMeta[name]
									for num = 1, 3 do
										name = name:gsub(`_{num}`, '')
									end

									if bedwars.EnchantMeta[name] then
										return bedwars.EnchantMeta[name].image
									end
								end
							end
						end
					end
					return nil
				end,
			}
		end
	})

	local function createMethodHook(object, method)
		local original = object[method]
		local hooks, order = {}, 0
		local wrapper

		local function sync()
			if #hooks > 0 then
				object[method] = wrapper
			elseif object[method] == wrapper then
				object[method] = original
			end
		end

		wrapper = function(...)
			local index = 0
			local function nextHook(...)
				index += 1
				local hook = hooks[index]
				if hook then
					return hook.Callback(nextHook, ...)
				end
				return original(...)
			end
			return nextHook(...)
		end

		return {
			Add = function(_, id, priority, callback)
				for i = #hooks, 1, -1 do
					if hooks[i].Id == id then
						table.remove(hooks, i)
					end
				end

				order += 1
				local entry = {
					Id = id,
					Priority = priority or 100,
					Order = order,
					Callback = callback,
				}

				table.insert(hooks, entry)
				table.sort(hooks, function(a, b)
					return a.Priority == b.Priority and a.Order < b.Order or a.Priority < b.Priority
				end)
				sync()

				return function()
					for i = #hooks, 1, -1 do
						if hooks[i] == entry then
							table.remove(hooks, i)
						end
					end
					sync()
				end
			end,
			Destroy = function()
				table.clear(hooks)
				sync()
			end,
		}
	end

	bedwars.ProjectileLaunchHook = createMethodHook(bedwars.ProjectileController, 'calculateImportantLaunchValues')
	vape:Clean(function()
		bedwars.ProjectileLaunchHook:Destroy()
	end)

	local function getproto(...)
		local success, res = pcall(debug.getproto, ...)
		return success and res or function() end
	end
	local remoteNames = {
		AfkStatus = canDebug and getproto(Knit.Controllers.AfkController.KnitStart, 1) or function() end,
		AttackEntity = canDebug and Knit.Controllers.SwordController.sendServerRequest or function() end,
		BeePickup = canDebug and Knit.Controllers.BeeNetController.trigger or function() end,
		CannonAim = canDebug and getproto(Knit.Controllers.CannonController.startAiming, 5) or function() end,
		CannonLaunch = canDebug and Knit.Controllers.CannonHandController.launchSelf or function() end,
		ConsumeBattery = canDebug and getproto(Knit.Controllers.BatteryController.onKitLocalActivated, 1) or function() end,
		ConsumeItem = canDebug and getproto(Knit.Controllers.ConsumeController.onEnable, 1) or function() end,
		ConsumeSoul = canDebug and Knit.Controllers.GrimReaperController.consumeSoul or function() end,
		ConsumeTreeOrb = canDebug and getproto(Knit.Controllers.EldertreeController.createTreeOrbInteraction, 1) or function() end,
		DepositPinata = canDebug and getproto(getproto(Knit.Controllers.PiggyBankController.KnitStart, 2), 5) or function() end,
		DragonBreath = canDebug and getproto(Knit.Controllers.VoidDragonController.onKitLocalActivated, 5) or function() end,
		DragonEndFly = canDebug and getproto(Knit.Controllers.VoidDragonController.flapWings, 1) or function() end,
		DragonFly = canDebug and Knit.Controllers.VoidDragonController.flapWings or function() end,
		DropItem = canDebug and Knit.Controllers.ItemDropController.dropItemInHand or function() end,
		EquipItem = canDebug and getproto(require(replicatedStorage.TS.entity.entities['inventory-entity']).InventoryEntity.equipItem, 4) or function() end,
		FireProjectile = canDebug and safeUpvalue(Knit.Controllers.ProjectileController.launchProjectileWithValues, 2) or function() end,
		GroundHit = canDebug and Knit.Controllers.FallDamageController.KnitStart or function() end,
		GuitarHeal = canDebug and Knit.Controllers.GuitarController.performHeal or function() end,
		HannahKill = canDebug and getproto(Knit.Controllers.HannahController.registerExecuteInteractions, 1) or function() end,
		HarvestCrop = canDebug and getproto(getproto(Knit.Controllers.CropController.KnitStart, 4), 1) or function() end,
		KaliyahPunch = canDebug and getproto(Knit.Controllers.DragonSlayerController.onKitLocalActivated, 1) or function() end,
		MageSelect = canDebug and getproto(Knit.Controllers.MageController.registerTomeInteraction, 1) or function() end,
		MinerDig = canDebug and getproto(Knit.Controllers.MinerController.setupMinerPrompts, 1) or function() end,
		PickupItem = canDebug and Knit.Controllers.ItemDropController.checkForPickup or function() end,
		PickupMetal = canDebug and getproto(Knit.Controllers.HiddenMetalController.onKitLocalActivated, 4) or function() end,
		ReportPlayer = canDebug and require(lplr.PlayerScripts.TS.controllers.global.report['report-controller']).default.reportPlayer or function() end,
		ResetCharacter = canDebug and getproto(Knit.Controllers.ResetController.createBindable, 1) or function() end,
		SpawnRaven = canDebug and getproto(Knit.Controllers.RavenController.KnitStart, 1) or function() end,
		SummonerClawAttack = canDebug and Knit.Controllers.SummonerClawHandController.attack or function() end,
		WarlockTarget = canDebug and getproto(Knit.Controllers.WarlockStaffController.KnitStart, 2) or function() end
	}

	local packages
	local function getPackages()
		if not packages then
			packages = httpService:JSONDecode(downloadFile('aetherv2/profiles/packages.json'))
		end
		return packages
	end
	local function dumpRemote(tab)
		if not tab then return '' end
		local ind
		for i, v in tab do
			if v == 'Client' then
				ind = i
				break
			end
		end
		return ind and tab[ind + 1] or ''
	end

	for i, v in remoteNames do
		local remote = dumpRemote(debug.getconstants(v))
		if remote == '' then
			local ok, fallback = pcall(function()
				return getPackages().remotes[i]
			end)
			if ok and type(fallback) == 'string' then
				remote = fallback
			end
		end
		if remote == '' then
			notif('AetherV2', 'Failed to grab remote ('..i..')', 10, 'alert')
		end
		remotes[i] = remote
	end
    getgenv().remotes = remotes

	OldBreak = bedwars.BlockController.isBlockBreakable
	OldHit = bedwars.BlockBreaker.hitBlock

	bedwars.BlockBreaker.hitBlock = function(...)
        store.lastHit = tick()
        return OldHit(...)
    end
	if canDebug then
		Client.Get = function(self, remoteName)
			local call = OldGet(self, remoteName)

			if remoteName == remotes.AttackEntity then
				return {
					instance = call.instance,
					SendToServer = function(_, attackTable, ...)
						local suc, plr = pcall(function()
							return playersService:GetPlayerFromCharacter(attackTable.entityInstance)
						end)

						local validate = attackTable.validate
						local selfField = validate and validate.selfPosition
						local targetField = validate and validate.targetPosition
						if selfField and targetField and selfField.value and targetField.value then
							local selfpos, targetpos = selfField.value, targetField.value
							local dist = (selfpos - targetpos).Magnitude
							store.attackReach = (dist * 100) // 1 / 100
							store.attackReachUpdate = tick() + 1

							if (Reach.Enabled or HitBoxes.Enabled) and dist > 0 then
								validate.raycast = validate.raycast or {}
								selfField.value += CFrame.lookAt(selfpos, targetpos).LookVector * math.max(dist - 14.399, 0)
							end
						end

						if suc and plr then
							local ok, targetable = pcall(function()
								return (select(2, whitelist:get(plr)))
							end)
							if ok and not targetable then return end
						end

						return call:SendToServer(attackTable, ...)
					end
				}
			elseif store.trapReports and store.trapReports[remoteName] and TrapDisabler and TrapDisabler.Enabled and store.trapReports[remoteName].Enabled then
				return {SendToServer = function() end}
			end

			return call
		end
	end

	bedwars.BlockController.isBlockBreakable = function(self, breakTable, plr)
		local obj = bedwars.BlockController:getStore():getBlockAt(breakTable.blockPosition)

		if obj and obj.Name == 'bed' and whitelist and lplr then
			local team = lplr:GetAttribute('Team')
			if team and obj:GetAttribute('Team'..team..'NoBreak') then
				local ok, targetable = pcall(function()
					return (select(2, whitelist:get(lplr)))
				end)
				if ok and not targetable then
					return false
				end
			end
		end

		return OldBreak(self, breakTable, plr)
	end

	local cache, blockhealthbar = {}, {blockHealth = -1, breakingBlockPosition = Vector3.zero}
	store.blockPlacer = bedwars.BlockPlacer.new(bedwars.BlockEngine, 'wool_white')

	local function getBlockHealth(block, blockpos)
		local blockdata = bedwars.BlockController:getStore():getBlockData(blockpos)
		return (blockdata and (blockdata:GetAttribute('1') or blockdata:GetAttribute('Health')) or block:GetAttribute('Health'))
	end

	getBlockHits = function(block, blockpos, held)
		if not block then return 0 end
		local itemMeta = bedwars.ItemMeta[block.Name]
		local breaktype = itemMeta and itemMeta.block and itemMeta.block.breakType
		local tool = getBreakTool(breaktype)
		if held then
			local hand = store.hand and store.hand.tool
			tool = hand and {itemType = hand.Name}
		end
		local toolMeta = tool and bedwars.ItemMeta[tool.itemType]
		tool = toolMeta and toolMeta.breakBlock and toolMeta.breakBlock[breaktype] or 2
		return math.max(tonumber(getBlockHealth(block, bedwars.BlockController:getBlockPosition(blockpos))) or tonumber(block:GetAttribute('MaxHealth')) or 1, 1) / math.max(tonumber(tool) or 2, 0.01)
	end

	local function isMinable(pos)
		for _, side in {Vector3.new(0, 3, 0), Vector3.new(3, 0, 0), Vector3.new(0, 0, 3)} do
			side = pos + side
			local block = getPlacedBlock(side)
			if not block or (block:GetAttribute("PlacedByUserId") or 0) ~= 0 then
				return true
			end
		end
		return false
	end
	
	local function pathScore(node, cost, depth, prefs)
		local primary, secondary = cost, depth or 0
		if prefs and prefs.FewestBlocks then
			primary, secondary = depth or 0, cost
		end
		if prefs and prefs.Legit and entitylib.isAlive then
			local from = entitylib.character.RootPart.Position
			return (node - from).Magnitude + (depth or 0) * 3, cost
		end
		return primary, secondary
	end

	local function calculatePath(target, blockpos, method, angle, wallcheck, prefs)
		
		local legitCheck = type(wallcheck) == 'function' and wallcheck or nil
		local prefsKey = type(prefs) == 'table' and ((prefs.Legit and 'L' or '')..(prefs.FewestBlocks and 'F' or '')..tostring(prefs.Range or '')) or ''
		local cached = cache[blockpos]
		if cached and cached.Method == method and cached.Angle == angle and cached.Wallcheck == wallcheck and cached.Prefs == prefsKey and os.clock() < cached.Expires then
			if cached.Miss then return nil end
			return cached[1], cached[2], cached[3], cached[4]
		end
		local ttl = (angle or 360) >= 360 and not legitCheck and 1 or 0.25
		local visited, unvisited, distances, air, path = {}, {{0, blockpos, 0}}, {[blockpos] = 0}, {}, {}
		local depths, visibility = {[blockpos] = 0}, {}
		local function push(value)
			table.insert(unvisited, value)
			local index = #unvisited
			while index > 1 do
				local parent = math.floor(index / 2)
				if unvisited[parent][1] <= value[1] then break end
				unvisited[index], index = unvisited[parent], parent
			end
			unvisited[index] = value
		end
		local function pop()
			local root, tail = unvisited[1], table.remove(unvisited)
			if #unvisited > 0 then
				local index = 1
				while index * 2 <= #unvisited do
					local child = index * 2
					if child < #unvisited and unvisited[child + 1][1] < unvisited[child][1] then child += 1 end
					if unvisited[child][1] >= tail[1] then break end
					unvisited[index], index = unvisited[child], child
				end
				unvisited[index] = tail
			end
			return root
		end

		local function isNodeVisible(pos)
			if visibility[pos] == nil then
				visibility[pos] = not legitCheck or legitCheck(pos)
			end
			return visibility[pos]
		end

		for _ = 1, (legitCheck and 300 or 10000) do
			local node = pop()
			if not node then break end
			if node[1] ~= distances[node[2]] then continue end
			visited[node[2]] = true

			for _, side in sides do
				side = node[2] + side
				if visited[side] then continue end

				local block = getPlacedBlock(side)
				if not block or block:GetAttribute('NoBreak') or block == target then
					if not block and isNodeVisible(node[2]) then
						air[node[2]] = true
					end
					continue
				end

				local facing = entitylib.character.RootPart.CFrame.LookVector * Vector3.new(1, 0, 1)
				local direction = (block.Position - entitylib.character.RootPart.Position) * Vector3.new(1, 0, 1)
				if facing.Magnitude < 0.001 or direction.Magnitude < 0.001 or math.acos(math.clamp(facing.Unit:Dot(direction.Unit), -1, 1)) > (math.rad(angle) / 2) then
					continue
				end

				local curdist = (method and method(block, side) or getBlockHits(block, side)) + node[1]
				if curdist < (distances[side] or math.huge) then
					push({curdist, side, node[3] + 1})
					distances[side] = curdist
					depths[side] = node[3] + 1
					path[side] = node[2]
				end
			end
		end

		local pos, cost = nil, math.huge
		local bestPrimary, bestSecondary = math.huge, math.huge
		local reach = type(prefs) == 'table' and tonumber(prefs.Range) or nil
		local from = reach and entitylib.isAlive and entitylib.character.RootPart.Position
		local function consider(node)
			if from and (node - from).Magnitude > reach then return end
			local primary, secondary = pathScore(node, distances[node], depths[node], prefs)
			if primary < bestPrimary or (primary == bestPrimary and secondary < bestSecondary) then
				pos, cost = node, distances[node]
				bestPrimary, bestSecondary = primary, secondary
			end
		end
		for node in air do
			if legitCheck then
				consider(node)
			elseif not wallcheck or isMinable(node) then
				consider(node)
			end
		end

		if pos then
			cache[blockpos] = {
				pos,
				cost,
				path,
				depths[pos],
				Method = method, Angle = angle, Wallcheck = wallcheck, Prefs = prefsKey, Expires = os.clock() + ttl
			}
			return pos, cost, path, depths[pos]
		end
		cache[blockpos] = {blockpos, math.huge, {}, 0, Miss = true,
			Method = method, Angle = angle, Wallcheck = wallcheck, Prefs = prefsKey, Expires = os.clock() + ttl}
		return nil
	end
	bedwars.calculateBreakPath = calculatePath

	bedwars.placeBlock = function(pos, item)
		local function place()
			if not getItem(item) then return end
			store.blockPlacer.blockType = item
			return store.blockPlacer:placeBlock(bedwars.BlockController:getBlockPosition(pos))
		end
		
		if bedwars.MineThrough then
			return bedwars.MineThrough(place)
		end
		return place()
	end

	bedwars.breakBlock = function(block, effects, anim, customHealthbar, visualise, sort, angle, wallcheck, prefs)
		if lplr:GetAttribute('DenyBlockBreak') or not entitylib.isAlive then return end

		local handler = bedwars.BlockController:getHandlerRegistry():getHandler(block.Name)
		local cost, pos, target, path = math.huge, nil, nil, nil
		local bestPrimary, bestSecondary = math.huge, math.huge

		local direct = type(prefs) == 'table' and typeof(prefs.Direct) == 'Vector3' and prefs.Direct
		if direct then
			cost, pos, target, path = 0, direct, direct, {}
		end

		for _, v in (not direct and (handler and handler:getContainedPositions(block) or {block.Position / 3}) or {}) do
			local dpos, dcost, dpath, ddepth = calculatePath(block, v * 3, sort, angle or 360, wallcheck, prefs)
			if dpos then
				
				local primary, secondary = pathScore(dpos, dcost, ddepth, prefs)
				if primary < bestPrimary or (primary == bestPrimary and secondary < bestSecondary) then
					cost, pos, target, path = dcost, dpos, v * 3, dpath
					bestPrimary, bestSecondary = primary, secondary
				end
			end
		end

		if pos then
			if (entitylib.character.RootPart.Position - pos).Magnitude > (type(prefs) == 'table' and tonumber(prefs.Range) or 30) then return end
			local dblock, dpos = getPlacedBlock(pos)
			if not dblock then return end

			local dmeta = bedwars.ItemMeta[dblock.Name]
			local breaktype = dblock.Name == 'gumdrop_bounce_pad' and 'stone' or (dmeta and dmeta.block and dmeta.block.breakType)
			
			local tool = not (type(prefs) == 'table' and prefs.HeldOnly) and (getBreakTool(breaktype) or store.tools.stone)
			if tool then
				local now = workspace:GetServerTimeNow()
				local held = store.hand and store.hand.tool
				local holdingSword = held ~= nil and store.tools.sword ~= nil and held == store.tools.sword.tool
				local holdingProjectile = held ~= nil and store.hand.toolType == 'bow'
				
				local busyMelee = (now - bedwars.SwordController.lastAttack) <= 0.4 and holdingSword
				local busyProjectile = (now - (store.lastProjectileFire or 0)) <= 0.35 and holdingProjectile
				if not (busyMelee or busyProjectile) then
					if visualise then
						local hotbar = getHotbar(tool.tool)
						if hotbar then hotbarSwitch(hotbar) end
					end
					if not held or held ~= tool.tool then switchItem(tool.tool, 0) end
				end
			end

			if blockhealthbar.blockHealth == -1 or dpos ~= blockhealthbar.breakingBlockPosition then
				blockhealthbar.blockHealth = getBlockHealth(dblock, dpos)
				blockhealthbar.breakingBlockPosition = dpos
			end

			local request = bedwars.ClientDamageBlock:Get('DamageBlock'):CallServerAsync({
				blockRef = {blockPosition = dpos},
				hitPosition = pos,
				hitNormal = Vector3.FromNormalId(Enum.NormalId.Top)
			}):andThen(function(result)
				if result then
					if result == 'cancelled' then
						store.damageBlockFail = tick() + 0.25
						return result
					end

					local showEffects = type(effects) == 'function' and effects() or effects
					local showAnimation = type(anim) == 'function' and anim() or anim
					if showEffects then
						local blockdmg = (blockhealthbar.blockHealth - (result == 'destroyed' and 0 or getBlockHealth(dblock, dpos)))
						local drawHealthbar = customHealthbar or bedwars.BlockBreaker.updateHealthbar
						if drawHealthbar then
							pcall(drawHealthbar, bedwars.BlockBreaker, {blockPosition = dpos}, blockhealthbar.blockHealth, tonumber(dblock:GetAttribute('MaxHealth')) or blockhealthbar.blockHealth, blockdmg, dblock)
						end
						blockhealthbar.blockHealth = math.max(blockhealthbar.blockHealth - blockdmg, 0)

						if blockhealthbar.blockHealth <= 0 then
							pcall(function() bedwars.BlockBreaker.breakEffect:playBreak(dblock.Name, dpos, lplr) end)
							if bedwars.BlockBreaker.healthbarMaid then
								pcall(function() bedwars.BlockBreaker.healthbarMaid:DoCleaning() end)
							end
							blockhealthbar.breakingBlockPosition = Vector3.zero
						else
							pcall(function() bedwars.BlockBreaker.breakEffect:playHit(dblock.Name, dpos, lplr) end)
						end
					end

					if showAnimation then
						pcall(function()
							local animation = bedwars.AnimationUtil:playAnimation(lplr, bedwars.BlockController:getAnimationController():getAssetId(1))
							bedwars.ViewmodelController:playAnimation(15)
							task.wait(0.3)
							animation:Stop()
							animation:Destroy()
						end)
					end
				end
				return result
			end)

			return pos, path, target, request
		end
		return nil
	end

	for _, v in Enum.NormalId:GetEnumItems() do
		table.insert(sides, Vector3.FromNormalId(v) * 3)
	end

	local function updateStore(new, old)
		if new.Bedwars ~= old.Bedwars then
			local state = type(new.Bedwars) == 'table' and new.Bedwars or {}
			local previousKit = store.equippedKit
			local previousReady = store.kitReady
			store.kitReady = type(new.Bedwars) == 'table'
			store.equippedKit = state.kit and state.kit ~= 'none' and state.kit or ''
			if (previousKit ~= store.equippedKit or previousReady ~= store.kitReady) and type(vape.RefreshGameInfo) == 'function' then
				vape:RefreshGameInfo()
			end
		end

		if new.Game ~= old.Game then
			local state = type(new.Game) == 'table' and new.Game or {}
			store.matchState = state.matchState or 0
			store.queueType = state.queueType or 'bedwars_test'
		end

		if new.Inventory ~= old.Inventory then
			local function normalizeInventory(value)
				value = type(value) == 'table' and value or {}
				local inventory = type(value.inventory) == 'table' and value.inventory or {}
				if type(value.inventory) == 'table' and type(inventory.items) == 'table'
					and type(inventory.armor) == 'table' and type(value.hotbar) == 'table' then return value end
				local normalized = table.clone(value)
				normalized.inventory = table.clone(inventory)
				normalized.inventory.items = type(inventory.items) == 'table' and inventory.items or {}
				normalized.inventory.armor = type(inventory.armor) == 'table' and inventory.armor or {}
				normalized.hotbar = type(value.hotbar) == 'table' and value.hotbar or {}
				return normalized
			end
			local newinv = normalizeInventory(new.Inventory and new.Inventory.observedInventory)
			local oldinv = normalizeInventory(old.Inventory and old.Inventory.observedInventory)
			store.inventory = newinv

			if newinv ~= oldinv then
				vapeEvents.InventoryChanged:Fire()
			end

			if newinv.inventory.items ~= oldinv.inventory.items then
				vapeEvents.InventoryAmountChanged:Fire()
				
				store.tools = {sword = getSword()}
				for _, v in {'stone', 'wood', 'wool'} do
					store.tools[v] = getTool(v)
				end
			end

			if newinv.inventory.hand ~= oldinv.inventory.hand then
				local currentHand, toolType = newinv.inventory.hand, ''
				if currentHand then
					local handData = bedwars.ItemMeta[currentHand.itemType]
					if handData then
						toolType = handData.sword and 'sword' or handData.block and 'block' or currentHand.itemType:find('bow') and 'bow'
					end
				end

				store.hand = {
					tool = currentHand and currentHand.tool,
					itemType = currentHand and currentHand.itemType,
					amount = currentHand and currentHand.amount or 0,
					toolType = toolType
				}
			end
		end
	end

	local storeChanged = bedwars.Store.changed:connect(updateStore)
	updateStore(bedwars.Store:getState(), {})
	if type(vape.RefreshGameInfo) == 'function' then vape:RefreshGameInfo() end

	for _, event in {'MatchEndEvent', 'EntityDeathEvent', 'BedwarsBedBreak', 'BalloonPopped', 'AngelProgress', 'GrapplingHookFunctions'} do
		if not vape.Connections then return end
		bedwars.Client:WaitFor(event):andThen(function(connection)
			vape:Clean(connection:Connect(function(...)
				vapeEvents[event]:Fire(...)
			end))
		end)
	end

	vape:Clean(bedwars.ZapNetworking.EntityDamageEventZap.On(function(...)
		local a = {
			entityInstance = ...,
			damage = select(2, ...),
			damageType = select(3, ...),
			fromPosition = select(4, ...),
			fromEntity = select(5, ...),
			knockbackMultiplier = select(6, ...),
			knockbackId = select(7, ...),
			disableDamageHighlight = select(13, ...)
		}
		shared.bindable:Fire(a)
		vapeEvents.EntityDamageEvent:Fire(a)
		if targetinfo and targetinfo.Focus and a.fromEntity and a.fromEntity == lplr.Character and a.entityInstance ~= lplr.Character then
			local hurt = entitylib.getEntity(a.entityInstance)
			if hurt and not (store.KillauraTarget and store.KillauraTarget ~= hurt) then
				targetinfo.Focus[hurt] = tick() + 1
			end
		end
	end))

	vape:Clean(workspace.ChildAdded:Connect(function(projectile)
		task.delay(0, function()
			if projectile and projectile.Parent and entitylib.isAlive and projectile:GetAttribute('ProjectileShooter') == lplr.UserId then
				table.insert(store.selfProjectiles, projectile)
				projectile.Destroying:Once(function()
					local index = table.find(store.selfProjectiles, projectile)
					if index then
						table.remove(store.selfProjectiles, index)
					end
				end)
			end
		end)
	end))

	for _, event in {'BreakBlockEvent'} do
		vape:Clean(bedwars.ZapNetworking[event..'Zap'].On(function(...)
			local data = {
				blockRef = {
					blockPosition = ...,
				},
				player = select(5, ...)
			}
			for i, v in cache do
				if ((data.blockRef.blockPosition * 3) - v[1]).Magnitude <= 30 then
					table.clear(v[3])
					table.clear(v)
					cache[i] = nil
				end
			end
			vapeEvents[event]:Fire(data)
		end))
	end

	store.blocks = collection('block', vape)
	store.void = {Floor = nil}
	vape:Clean(collectionService:GetInstanceAddedSignal('block'):Connect(function(v)
		local floor = store.void.Floor
		if floor and v:IsA('BasePart') then
			local bottom = v.Position.Y - v.Size.Y / 2
			if bottom < floor then store.void.Floor = bottom end
		end
	end))
	task.spawn(function()
		local low, blocks, index, started = math.huge, store.blocks, 1, os.clock()
		while index <= #blocks do
			local v = blocks[index]
			index += 1
			if v and v:IsA('BasePart') then
				local bottom = v.Position.Y - v.Size.Y / 2
				if bottom < low then low = bottom end
			end
			if os.clock() - started > 0.002 then
				task.wait()
				started = os.clock()
			end
		end
		if low < math.huge then
			store.void.Floor = math.min(low, store.void.Floor or math.huge)
		end
	end)
	function store.inVoid(root, lead)
		local floor = store.void.Floor
		if not floor or not store.airRay then return false end
		root = root or (entitylib.isAlive and entitylib.character.RootPart)
		if not root then return false end
		local vy = root.AssemblyLinearVelocity.Y
		if vy > -1 then return false end
		lead = lead or 0.5
		local y = root.Position.Y
		if y + vy * lead - workspace.Gravity * 0.5 * lead * lead >= floor then return false end
		return workspace:Raycast(root.Position, Vector3.new(0, -math.max(y - floor, 0) - 60, 0), store.airRay) == nil
	end
	store.shop = collection({'BedwarsItemShop', 'TeamUpgradeShopkeeper'}, vape, function(tab, obj)
		table.insert(tab, {
			Id = obj.Name,
			RootPart = obj,
			Shop = obj:HasTag('BedwarsItemShop'),
			Upgrades = obj:HasTag('TeamUpgradeShopkeeper')
		})
	end)
	store.enchant = collection({'enchant-table', 'broken-enchant-table'}, vape, nil, function(tab, obj, tag)
		if obj:HasTag('enchant-table') and tag == 'broken-enchant-table' then return end
		obj = table.find(tab, obj)
		if obj then
			table.remove(tab, obj)
		end
	end)

	local kills = sessioninfo:AddItem('Kills')
	local beds = sessioninfo:AddItem('Beds')
	local wins = sessioninfo:AddItem('Wins')
	local games = sessioninfo:AddItem('Games')
	sessioninfo:AddItem('Cheater List', '', function()
		local text = ''
		for _, plr in playersService:GetPlayers() do
			if CheatersFlagged[plr] then
				text = text..'\n'..(plr.DisplayName ~= plr.Name and plr.DisplayName..' ('..plr.Name..')' or plr.Name)
			end
		end

		return text
	end, false)

	local mapname = 'Unknown'
	sessioninfo:AddItem('Map', 0, function()
		return mapname
	end, false)

	task.delay(1, function()
		games:Increment()
	end)

	task.spawn(function()
		pcall(function()
			repeat task.wait() until store.matchState ~= 0 or vape.Loaded == nil
			if vape.Loaded == nil then return end
			store.map = waitForChildYield(workspace, 9e9, 'Map', 'Worlds'):GetChildren()[1]
			mapname = store.map.Name
			mapname = string.gsub(string.split(mapname, '_')[2] or mapname, '-', '') or 'Blank'
			if store.map then
				
				local blockRay = RaycastParams.new()
				blockRay.FilterType = Enum.RaycastFilterType.Include
				blockRay.FilterDescendantsInstances = {store.map}
				blockRay.RespectCanCollide = true
				store.blockRaycast = blockRay
				vape:Clean(store.map.Blocks.ChildAdded:Connect(function(v) 
					task.delay(0, function()
						if v:GetAttribute('Block') and (v:GetAttribute('PlacedByUserId') or 0) ~= 0 then
							local data = {
								blockRef = {
									blockPosition = v.Position / 3,
								},
								player = playersService:GetPlayerByUserId(v:GetAttribute('PlacedByUserId')),
							}
							for i, v in cache do
								if ((data.blockRef.blockPosition * 3) - v[1]).Magnitude <= 30 then
									table.clear(v[3])
									table.clear(v)
									cache[i] = nil
								end
							end
							vapeEvents.PlaceBlockEvent:Fire(data)
						end
					end)
				end))
			end
		end)
	end)

	vape:Clean(vapeEvents.BedwarsBedBreak.Event:Connect(function(bedTable)
		if bedTable.player and bedTable.player.UserId == lplr.UserId then
			beds:Increment()
		end
	end))

	vape:Clean(vapeEvents.MatchEndEvent.Event:Connect(function(winTable)
		if (bedwars.Store:getState().Game.myTeam or {}).id == winTable.winningTeamId or lplr.Neutral then
			wins:Increment()
		end
	end))

	vape:Clean(vapeEvents.EntityDeathEvent.Event:Connect(function(deathTable)
		local killer = playersService:GetPlayerFromCharacter(deathTable.fromEntity)
		local killed = playersService:GetPlayerFromCharacter(deathTable.entityInstance)
		if not killed or not killer then return end

		if killed ~= lplr and killer == lplr then
			kills:Increment()
		end
	end))

	task.spawn(function()
		local rayParams = RaycastParams.new()
		rayParams.FilterType = Enum.RaycastFilterType.Include
		rayParams.FilterDescendantsInstances = {workspace:WaitForChild('Map', 9e9)}
		store.airRay = rayParams

		repeat
			if entitylib.isAlive then
				entitylib.character.AirTime = workspace:Raycast((store.rootpart or entitylib.character.RootPart).Position, Vector3.new(0, -4.5, 0), rayParams) and tick() or entitylib.character.AirTime
			end

			for _, v in entitylib.List do
				if v.Jumps ~= 0 then
					local now = tick()
					v.LandTick = math.abs(v.RootPart.AssemblyLinearVelocity.Y) < 0.1 and v.LandTick or now
					if now - v.LandTick > 0.2 then
						v.Jumps = 0
						v.Jumping = false
					end
				end
			end
			task.wait()
		until vape.Loaded == nil
	end)

	pcall(function()
		if getthreadidentity and setthreadidentity or not canDebug then
			local old = getthreadidentity()
			setthreadidentity(2)

			bedwars.Shop = require(replicatedStorage.TS.games.bedwars.shop['bedwars-shop']).BedwarsShop
			
			pcall(function()
				bedwars.ShopItems = safeUpvalue(safeUpvalue(bedwars.Shop.getShopItem, 1), 2)
			end)
			pcall(bedwars.Shop.getShopItem, 'iron_sword', lplr)

			setthreadidentity(old)
			store.shopLoaded = true
		else
			task.spawn(function()
				repeat
					task.wait(0.1)
				until vape.Loaded == nil or bedwars.AppController:isAppOpen('BedwarsItemShopApp')

				bedwars.Shop = require(replicatedStorage.TS.games.bedwars.shop['bedwars-shop']).BedwarsShop
				pcall(function()
					bedwars.ShopItems = safeUpvalue(safeUpvalue(bedwars.Shop.getShopItem, 1), 2)
				end)
				store.shopLoaded = true
			end)
		end
	end)

	vape:Clean(function()
		Client.Get = OldGet
		bedwars.BlockController.isBlockBreakable = OldBreak
		store.blockPlacer:disable()
		shared.bindable:Destroy()
		for _, v in vapeEvents do
			v:Destroy()
		end
		for _, v in cache do
			table.clear(v[3])
			table.clear(v)
		end
		table.clear(store.blockPlacer)
		table.clear(vapeEvents)
		table.clear(bedwars)
		table.clear(store)
		table.clear(cache)
		table.clear(sides)
		table.clear(remotes)
		storeChanged:disconnect()
		storeChanged = nil
	end)
end, 20)

for _, v in {'AutoObby', 'TriggerBot', 'SilentAim', 'Rejoin', 'Disabler', 'Timer', 'ServerHop', 'NoFallDamage', 'MurderMystery', 'Invisible',
	'Jesus', 'MultiAction', 'ArmorHighlight', 'LegacyAnimation', 'PlayerModel', 'Search', 'Theme', 'Waypoints', 'BackTrack', 'ClaimRewards', 'CustomCursor', 'LeaveParty', 'KillfeedSpoofer',
	'BlurryTextures',
	'AutoKit',
	'DeathSpawn',
	'PromptAura', 'SongBeats',
	'AnimationPlayer', 'AntiFling', 'AntiKillParts', 'ClickTP', 'ForceShiftLock', 'Glide', 'StateSpoofer', 'Wallhop'} do
	vape:Remove(v)
end

do
	local mouseTPBridge = vape.Libraries.MouseTPBridge
	if mouseTPBridge and type(mouseTPBridge.SetBedWars) == 'function' then
		mouseTPBridge:SetBedWars(function(position)
			if not entitylib.isAlive then return false, 'Character missing.' end
			local pearl = getItem('telepearl')
			local meta = bedwars.ProjectileMeta and bedwars.ProjectileMeta.telepearl
			if not pearl or not pearl.tool or not meta then return false, 'No Telepearl is available.' end

			local root = entitylib.character.RootPart
			local target = position
			local aim = prediction.SolveTrajectory(
				root.Position,
				meta.launchVelocity,
				meta.gravitationalAcceleration,
				target,
				Vector3.zero,
				workspace.Gravity,
				0,
				0,
				nil,
				false,
				target,
				nil,
				nil,
				true
			)
			if not aim then return false, 'The selected position is outside Telepearl range.' end

			local remote
			local remoteOK = pcall(function() remote = bedwars.Client:Get(remotes.FireProjectile).instance end)
			if not remoteOK or not remote or type(remote.InvokeServer) ~= 'function' then
				return false, 'The BedWars projectile remote is unavailable.'
			end

			local old = store.hand
			local slot = getHotbar(pearl.tool)
			switchItem(pearl.tool, 0.1)
			if slot then hotbarSwitch(slot) end
			task.wait(0.03)

			local direction = CFrame.lookAt(root.Position, aim).LookVector * meta.launchVelocity
			local id = httpService:GenerateGUID(true)
			local draw = {drawDurationSeconds = 1, shotId = httpService:GenerateGUID(false)}
			local success, result = pcall(function()
				bedwars.ProjectileController:createLocalProjectile(
					meta,
					'telepearl',
					'telepearl',
					root.Position,
					id,
					direction,
					draw
				)
				return remote:InvokeServer(
					pearl.tool,
					'telepearl',
					'telepearl',
					root.Position,
					root.Position,
					direction,
					id,
					draw,
					workspace:GetServerTimeNow() - 0.045
				)
			end)

			if old and old.tool then
				task.delay(0.12, function()
					if old.tool.Parent then
						switchItem(old.tool)
						local oldSlot = getHotbar(old.tool)
						if oldSlot then hotbarSwitch(oldSlot) end
					end
				end)
			end
			return success and result ~= false, success and 'Telepearl launch was rejected.' or tostring(result)
		end)
		vape:Clean(function()
			if vape.Libraries.MouseTPBridge == mouseTPBridge then mouseTPBridge:SetBedWars(nil) end
		end)
	end
end

local AntiFallDirection
local Fly
local LongJump

local longJumpActivation = Instance.new('BindableEvent')
vape:Clean(longJumpActivation)
local Attacking

local jadeHammerNames = {'jade_hammer_3', 'jade_hammer_2', 'jade_hammer_1', 'jade_hammer', 'jade_hammer_jump'}
local jadeJumpAbilities = {'jade_hammer_jump'}

local function normalizeJadeName(value)
	return type(value) == 'string' and value:lower():gsub('[%s%-]+', '_') or nil
end

local function isJadeHammerName(value)
	local normalized = normalizeJadeName(value)
	return normalized ~= nil and (normalized == 'jade_hammer_jump' or normalized == 'jade_hammer' or normalized:match('^jade_hammer_%d+$') ~= nil)
end

local function getJadeAbility(item)
	if not item then return end
	local itemType = normalizeJadeName(item.itemType or (item.tool and item.tool.Name))
	if not isJadeHammerName(itemType) then return end
	
	local abilities, seen = {}, {}
	local function add(ability)
		if ability and not seen[ability] then seen[ability] = true; table.insert(abilities, ability) end
	end
	add('jade_hammer_jump')
	for _, ability in jadeJumpAbilities do add(ability) end
	for _, ability in abilities do
		local ok, ready = pcall(bedwars.AbilityController.canUseAbility, bedwars.AbilityController, ability, {
			disableBlockedAbilityAlert = true
		})
		if ok and ready then return ability end
	end
	return abilities[1]
end

local function activateJadeTool(item)
	if not item or not item.tool then return false end
	switchItem(item.tool, 0.1)
	
	local equipDeadline = tick() + 0.6
	repeat
		task.wait()
	until (store.hand and store.hand.tool == item.tool) or tick() >= equipDeadline or not entitylib.isAlive
	local center = gameCamera.ViewportSize / 2
	local fired = pcall(function()
		local virtualInput = game:GetService('VirtualInputManager')
		if inputService.TouchEnabled then
			virtualInput:SendTouchEvent(0, Enum.UserInputState.Begin, center.X, center.Y)
			virtualInput:SendTouchEvent(0, Enum.UserInputState.End, center.X, center.Y)
		else
			virtualInput:SendMouseButtonEvent(center.X, center.Y, 0, true, game, 0)
			virtualInput:SendMouseButtonEvent(center.X, center.Y, 0, false, game, 0)
		end
	end)
	if not fired and mouse1click then fired = pcall(mouse1click) end
	return fired
end

local KIT_BEHAVIOURS = {
	AutoAbaddon = 'scarab', AutoAdetunde = 'frost_hammer_kit', AutoAgni = 'agni', AutoAngel = 'angel',
	AutoArachne = 'spider_queen', AutoBeekeeper = 'beekeeper',
	AutoBlackMarket = 'black_market_trader', AutoBountyHunter = 'bounty_hunter',
	AutoCaitlyn = 'blood_assassin', AutoCard = 'card', AutoCat = 'cat',
	AutoCogsworth = 'steam_engineer', AutoCrocowolf = 'beast', AutoCyber = 'cyber',
	AutoDinoTamer = 'dino_tamer', AutoDragonSword = 'dragon_sword', AutoDrill = 'drill',
	AutoElder = 'bigman', AutoEldric = 'warlock', AutoElektra = 'elektra', AutoEmber = 'ember',
	AutoEvelynn = 'spirit_assassin', AutoFlora = 'queen_bee', AutoFortify = 'builder',
	AutoFreiya = 'ice_queen', AutoGingerbreadMan = 'gingerbread_man', AutoGompy = 'ghost_catcher',
	AutoGrove = 'spirit_gardener', AutoGunBlade = 'gun_blade', AutoHannah = 'hannah',
	AutoHatter = 'hatter', AutoHephaestus = 'tinker', AutoKaida = 'summoner',
	AutoKaliyah = 'dragon_slayer', AutoLani = 'paladin', AutoLasso = 'cowgirl', AutoLumen = 'lumen',
	AutoMarcel = 'defender', AutoMarina = 'jellyfish', AutoMarrow = 'skeleton', AutoMartin = 'cactus',
	AutoMelody = 'melody', AutoMerchant = 'merchant', AutoMetal = 'metal_detector',
	AutoMiner = 'miner', AutoMushroom = 'alchemist', AutoNahila = 'oasis', AutoNazar = 'nazar',
	AutoNoelle = 'slime_tamer', AutoNyx = 'midnight', AutoPickpocket = 'mimic', AutoPyro = 'pyro',
	AutoRagnar = 'berserker', AutoRamil = 'airbender', AutoSheepHerder = 'sheep_herder',
	AutoShielderUlt = 'shielder', AutoSilas = 'rebellion_leader', AutoSmoke = 'smoke',
	AutoSophia = 'winter_lady', AutoStarCollector = 'star_collector', AutoStyx = 'styx',
	AutoTaliyah = 'taliyah', AutoTrap = 'trapper', AutoUma = 'spirit_summoner',
	AutoVanessa = 'triple_shot', AutoVoidHunter = 'void_hunter', AutoVoidKnight = 'void_knight',
	AutoWarden = 'jailor', AutoWarrior = 'warrior', AutoXurot = 'void_dragon', AutoYeti = 'yeti',
	AutoZeno = 'wizard', AutoZola = 'soul_broker', CannonAssist = 'davey', CatExtender = 'cat',
	CryptAura = 'necromancer', DaveyAim = 'davey', DeathAdderAimbot = 'sorcerer',
	FalconAura = 'falconer', FishermanSpy = 'fisherman', GrimReaperAssist = 'grim_reaper',
	HarvestAura = 'farmer_cletus', InfiniteKrystal = 'glacial_skater', KrystalDisabler = 'glacial_skater', InfiniteSigrid = 'elk_master',
	JadeExtender = 'jade', JadeInstantKill = 'jade', MelodyExploit = 'melody', OwlAura = 'owl', RavenAura = 'raven',
	TerraAimbot = 'block_kicker', TritonClutch = 'harpoon', TrixieDisabler = 'void_walker',
	VoidRegentAssist = 'regent', VoidRegentExtender = 'regent', VulcanAssist = 'vulcan',
	WhimAura = 'mage', XurotExtender = 'void_dragon', YaminiExtender = 'cat', YuziExtender = 'dasher', YuziCharge = 'dasher',
}

local kitModules = {}
local kitsWithBehaviour = {}

local function kitHasBehaviour(id)
    return kitsWithBehaviour[id] == true
end

local function kitHooksOf(module)
    local hooks = module.KitHooks
    if not hooks then
        hooks = {}
        module.KitHooks = hooks
    end
    return hooks
end

local createModule = kits.CreateModule
function kits:CreateModule(settings)
    if type(settings) == 'table' and type(settings.Name) == 'string' and KIT_BEHAVIOURS[settings.Name] then
        kitsWithBehaviour[KIT_BEHAVIOURS[settings.Name]] = true
    end
    return createModule(self, settings)
end
vape.Libraries.mergedModule = function(category, settings)
	local parts, main, restarting = {}, nil, false
	local own = settings.Function
	settings.Function = function(callback)
		if own then own(callback) end
		for _, part in parts do
			if callback and part.Switch.Enabled then
				part.Running = true
				local thread = task.spawn(part.Run, true)
				if coroutine.status(thread) ~= 'dead' then main:Clean(thread) end
			elseif part.Running then
				part.Running = false
				task.spawn(part.Run, false)
			end
		end
	end
	main = category:CreateModule(settings)
	function main:Part(partsettings)
		local part = {Run = partsettings.Function or function() end}
		part.Switch = main:CreateToggle({
			Name = partsettings.Label,
			Default = partsettings.Default ~= false,
			Tooltip = partsettings.Tooltip,
			Visible = partsettings.Visible,
			Function = function()
				if main.Enabled and not restarting then
					restarting = true
					task.defer(function()
						restarting = false
						if main.Enabled then
							main:Toggle()
							main:Toggle()
						end
					end)
				end
			end
		})
		setmetatable(part, {__index = function(_, key)
			if key == 'Enabled' then
				return main.Enabled and part.Switch.Enabled
			elseif key == 'Toggle' then
				return function()
					part.Switch:Toggle()
				end
			end
			local value = main[key]
			if type(value) == 'function' then
				return function(_, ...) return value(main, ...) end
			end
			return value
		end})
		table.insert(parts, part)
		return part
	end
	return main
end
store.antiHitHost = function()
	if store.antiHitMain then return store.antiHitMain end
	local main
	local modes = {}
	main = vape.Libraries.mergedModule(vape.Categories.Blatant, {
		Name = 'AntiHit',
		Tooltip = 'Keeps enemies from hitting you by moving your real hitbox away from them',
		Function = function(callback)
			if callback then
				for name, part in modes do
					part.Switch.Enabled = main.Mode.Value == name
				end
			end
		end
	})
	main.Modes = modes
	main.Mode = main:CreateDropdown({
		Name = 'Mode',
		List = {'Hover', 'Lift', 'GodMode'},
		Default = 'Hover',
		Tooltip = 'Hover - your hitbox waits just outside enemy reach\nLift - lifts you out of enemy reach\nGodMode - your hitbox only comes close for your own hits',
		Function = function()
			if main.Enabled then
				main:Toggle()
				main:Toggle()
			end
		end
	})
	main.Targets = main:CreateTargets({
		Players = true,
		Tooltip = 'Who you are protected from'
	})
	store.hitboxView.Add(main)
	store.antiHitMain = main
	return main
end
store.antiHitMode = function(name, settings)
	local main = store.antiHitHost()
	settings.Label = name
	settings.Visible = false
	local part = main:Part(settings)
	main.Modes[name] = part
	return part, main
end
local function getKitModule(id, create)
    local module = kitModules[id]
    if module or not create then return module end

    local meta = bedwars.BedwarsKitMeta and bedwars.BedwarsKitMeta[id]
    local display = tostring((meta and (meta.name or meta.displayName)) or id)
    local name = 'Auto' .. display:gsub('[^%w]', '')
    if vape.Kits and vape.Kits.Modules and vape.Kits.Modules[name] or vape.Modules[name] then
        name = name .. 'Ability'
    end
    local hooks = {}
    module = createModule(kits, {
        Name = name,
        Category = 'Auto',
        Tooltip = 'Uses the ' .. display .. ' kit ability for you',
        Function = function(enabled)
            for _, hook in hooks do
                pcall(hook, enabled)
            end
        end
    })
    module.KitHooks = hooks
    module.KitId = id
    kitModules[id] = module
    return module
end

local AetherRuntimeContext = {
    vape = vape,
    vapeEvents = vapeEvents,
    entitylib = entitylib,
    bedwars = bedwars,
    store = store,
    lplr = lplr,
    playersService = playersService,
    runService = runService,
    collectionService = collectionService,
    replicatedStorage = replicatedStorage,
    httpService = httpService,
    guiService = guiService,
    coreGui = coreGui,
    gameCamera = gameCamera,
    inputService = inputService,
    remotes = remotes,
    sortmethods = sortmethods,
    breakmethods = breakmethods,
    frictionTable = frictionTable,
    updateVelocity = updateVelocity,
    getItem = getItem,
    getWool = getWool,
    getBestArmor = getBestArmor,
    getPlacedBlock = getPlacedBlock,
    getWindStacks = getWindStacks,
    switchItem = switchItem,
    isnetworkowner = isnetworkowner,
    notif = notif,
    placeBlock = bedwars.placeBlock,
    breakBlock = bedwars.breakBlock,
    debug = debug,
    Knit = bedwars.Knit,
    kits = kits,
    canDebug = canDebug
}

local function registerAetherRuntimeBase(context)

local ctx = context
assert(type(ctx) == 'table', 'Aether BedWars runtime requires context')

local vape = assert(ctx.vape, 'missing vape')
local vapeEvents = ctx.vapeEvents
local entitylib = assert(ctx.entitylib, 'missing entitylib')
local bedwars = assert(ctx.bedwars, 'missing bedwars')
local store = assert(ctx.store, 'missing store')
local lplr = assert(ctx.lplr, 'missing local player')
local playersService = assert(ctx.playersService, 'missing Players')
local runService = assert(ctx.runService, 'missing RunService')
local collectionService = assert(ctx.collectionService, 'missing CollectionService')
local replicatedStorage = assert(ctx.replicatedStorage, 'missing ReplicatedStorage')
local httpService = assert(ctx.httpService, 'missing HttpService')
local guiService = ctx.guiService
local coreGui = ctx.coreGui
local gameCamera = ctx.gameCamera or workspace.CurrentCamera
local inputService = ctx.inputService
local remotes = ctx.remotes or {}
local sortmethods = ctx.sortmethods or {}
local breakmethods = ctx.breakmethods or {}
local frictionTable = ctx.frictionTable or {}
local updateVelocity = ctx.updateVelocity or function() end
local getItem = assert(ctx.getItem, 'missing getItem')
local getWool = ctx.getWool
local getBestArmor = ctx.getBestArmor
local getPlacedBlock = assert(ctx.getPlacedBlock, 'missing getPlacedBlock')
local switchItem = assert(ctx.switchItem, 'missing switchItem')
local isnetworkowner = ctx.isnetworkowner or function() return true end
local notif = ctx.notif or function() end
local safePlaceBlock = ctx.placeBlock or bedwars.placeBlock
local safeBreakBlock = ctx.breakBlock or bedwars.breakBlock

local Runtime = {Version = 7, Errors = {}, Context = ctx}

local function now()
    return tick()
end

local function safe(label, fn, ...)
    if type(fn) ~= 'function' then return false, 'missing function' end
    local ok, result = pcall(fn, ...)
    if not ok then
        Runtime.Errors[label] = {At = now(), Error = tostring(result)}
        return false, result
    end
    return true, result
end

local function ask(label, fn, ...)
    local ok, result = safe(label, fn, ...)
    return ok and result or nil
end

local function moduleByName(name)
    if vape.Modules and vape.Modules[name] then return vape.Modules[name] end
    for _, panel in {vape.Kits, vape.Legit} do
        if panel and panel.Modules and panel.Modules[name] then return panel.Modules[name] end
    end
end
getgenv().getAetherModule = moduleByName

local function rootOfLocal()
    local char = entitylib.character
    if entitylib.isAlive and char and char.RootPart and char.RootPart.Parent then
        return char.RootPart, char, char.Humanoid
    end
end

local function partOf(object)
    if not object then return nil end
    if object:IsA('BasePart') then return object end
    return object.PrimaryPart or object:FindFirstChildWhichIsA('BasePart')
end

local function itemCount(name)
    local item = ask('inventory.getItem.'..tostring(name), getItem, name)
    return item and item.amount or 0
end

local function copyTable(source)
    local out = {}
    for key, value in pairs(source or {}) do out[key] = value end
    return out
end

local Capabilities = {
    Match = {}, Metadata = {}, Inventory = {}, Blocks = {}, Abilities = {}, Kits = {}, Shop = {}, Queue = {}, Network = {},
    Status = {},
    Source = {LIVE = 'live', CONTROLLER = 'controller', REPLICATED = 'replicated', METADATA = 'metadata', FALLBACK = 'fallback', UNKNOWN = 'unknown'}
}
Runtime.BedWarsAPI = Capabilities

local referenceStates = {PRE = 0, RUNNING = 1, POST = 2}
Capabilities.Match.States = {
    PRE = (bedwars.MatchStates and bedwars.MatchStates.PRE) or referenceStates.PRE,
    RUNNING = (bedwars.MatchStates and bedwars.MatchStates.RUNNING) or referenceStates.RUNNING,
    POST = (bedwars.MatchStates and bedwars.MatchStates.POST) or referenceStates.POST
}

function Capabilities.Match:GetState()
    local state = store.matchState
    if type(state) == 'number' then return state, self.Source or Capabilities.Source.REPLICATED end
    local live = ask('match.store', function() return bedwars.Store:getState().Game.matchState end)
    if type(live) == 'number' then return live, Capabilities.Source.CONTROLLER end
    return Capabilities.Match.States.PRE, Capabilities.Source.FALLBACK
end

function Capabilities.Match:GetTeam()
    local team = lplr:GetAttribute('Team')
    if team ~= nil then return team, Capabilities.Source.REPLICATED end
    local value = ask('match.team', function() return bedwars.Store:getState().Game.myTeam end)
    if type(value) == 'table' then value = value.id end
    if value ~= nil then return value, Capabilities.Source.CONTROLLER end
    local char = lplr.Character
    value = char and char:GetAttribute('Team') or nil
    return value, value ~= nil and Capabilities.Source.REPLICATED or Capabilities.Source.UNKNOWN
end

function Capabilities.Metadata:GetItem(itemType)
    local meta = bedwars.ItemMeta and bedwars.ItemMeta[itemType]
    return meta, meta and Capabilities.Source.LIVE or Capabilities.Source.UNKNOWN
end

function Capabilities.Inventory:Get()
    local inv = store.inventory and store.inventory.inventory
    if type(inv) == 'table' then return inv, Capabilities.Source.REPLICATED end
    return {items = {}, armor = {}}, Capabilities.Source.UNKNOWN
end

function Capabilities.Inventory:GetHeld()
    return store.hand, store.hand and Capabilities.Source.REPLICATED or Capabilities.Source.UNKNOWN
end

function Capabilities.Shop:GetItem(itemType, shopId)
    if not bedwars.Shop or type(bedwars.Shop.getShopItem) ~= 'function' then return nil, Capabilities.Source.UNKNOWN end
    local item = ask('shop.item.'..tostring(itemType), function()
        return bedwars.Shop.getShopItem(itemType, lplr, shopId and {shopId = shopId} or nil)
    end)
    return item, item and Capabilities.Source.LIVE or Capabilities.Source.UNKNOWN
end

function Capabilities.Queue:GetMeta()
    return bedwars.QueueMeta or {}, bedwars.QueueMeta and Capabilities.Source.LIVE or Capabilities.Source.UNKNOWN
end

function Capabilities.Kits:GetEquipped()
    local kit = store.equippedKit
    if kit == nil or kit == '' then kit = lplr:GetAttribute('PlayingAsKit') or lplr:GetAttribute('PlayingAsKits') end
    return kit, kit and Capabilities.Source.REPLICATED or Capabilities.Source.UNKNOWN
end

function Capabilities.Blocks:Get(position)
    return ask('blocks.get', getPlacedBlock, position)
end

function Capabilities.Blocks:Place(position, itemType)
    return safe('blocks.place', safePlaceBlock, position, itemType, false)
end

function Capabilities.Blocks:Break(block)
    return safe('blocks.break', safeBreakBlock, block, true, true, nil, true, breakmethods.Distance, 360, false)
end

local Movement = {
    Current = nil,
    Serial = 0,
    ExternalNames = {'JadeInstaKill', 'LongJump', 'Fly', 'Speed', 'Scaffold', 'TPAura', 'RecoveryTP', 'AntiDeath'},
    Priorities = {Ordinary = 10, AutoWin = 40, Ability = 70, Emergency = 100}
}
Runtime.Movement = Movement

function Movement:_expired()
    return self.Current and self.Current.Expires and self.Current.Expires <= now()
end

function Movement:_clearExpired()
    if self:_expired() then self.Current = nil end
end

function Movement:GetOwner()
    self:_clearExpired()
    return self.Current and self.Current.Owner or nil
end

function Movement:GetExternalOwner(ignore)
    if store.rootpart and ignore ~= 'HitboxTransaction' then return 'HitboxTransaction' end
    for _, name in ipairs(self.ExternalNames) do
        if name ~= ignore then
            local module = moduleByName(name)
            if module and module.Enabled then return name end
        end
    end
end

function Movement:CanWrite(owner)
    self:_clearExpired()
    if not self.Current then return true end
    return self.Current.Owner == owner
end

function Movement:Acquire(owner, priority, ttl, onPreempt, allowExternal)
    self:_clearExpired()
    priority = priority or self.Priorities.Ordinary
	local external = if allowExternal then nil else self:GetExternalOwner(owner)
    if external and external ~= owner then return nil, 'external:'..external end
    local current = self.Current
    if current and current.Owner ~= owner and current.Priority > priority then return nil, 'owned:'..current.Owner end
    if current and current.Owner ~= owner and current.OnPreempt then safe('movement.preempt.'..current.Owner, current.OnPreempt, owner) end
    self.Serial += 1
    local serial = self.Serial
    local lease = {Owner = owner, Priority = priority, Expires = now() + (ttl or 0.5), Serial = serial, Released = false}
    function lease:Renew(seconds)
        if self.Released then return false end
        if Movement.Current ~= self then return false end
        self.Expires = now() + (seconds or ttl or 0.5)
        return true
    end
    function lease:Release()
        if self.Released then return end
        self.Released = true
        if Movement.Current == self then Movement.Current = nil end
    end
    lease.OnPreempt = onPreempt
    self.Current = lease
    return lease
end

local ModuleLeases = {Active = {}, Serial = 0}
Runtime.ModuleLeases = ModuleLeases

local function optionCurrent(option)
    if option.Enabled ~= nil then return option.Enabled, 'toggle' end
    return option.Value, 'value'
end

local function optionSet(option, value, kind)
    if kind == 'toggle' then
        if option.Enabled ~= value then safe('lease.option.toggle', function() option:Toggle() end) end
    elseif option.SetValue and option.Value ~= value then
        safe('lease.option.value', function() option:SetValue(value) end)
    end
end

function ModuleLeases:Acquire(owner, name, wantedOptions, wantEnabled)
    local key = owner..':'..name
    if self.Active[key] then return self.Active[key] end
    local module = moduleByName(name)
    if not module then return nil, 'missing module' end
    self.Serial += 1
    local lease = {Owner = owner, Name = name, Module = module, Options = {}, Released = false, Serial = self.Serial}
    lease.OldEnabled = module.Enabled and true or false
    lease.WroteEnabled = nil
    for optionName, wanted in pairs(wantedOptions or {}) do
        local option = module.Options and module.Options[optionName]
        if option then
            local old, kind = optionCurrent(option)
            if old ~= wanted then
                optionSet(option, wanted, kind)
                table.insert(lease.Options, {Option = option, Old = old, Written = wanted, Kind = kind})
            end
        end
    end
    if wantEnabled ~= false and not module.Enabled then
        safe('lease.module.enable.'..name, function() module:Toggle(true) end)
        if module.Enabled then lease.WroteEnabled = true end
    end
    function lease:Release()
        if self.Released then return end
        self.Released = true
        ModuleLeases.Active[key] = nil
        for index = #self.Options, 1, -1 do
            local entry = self.Options[index]
            local current = optionCurrent(entry.Option)
            if current == entry.Written then optionSet(entry.Option, entry.Old, entry.Kind) end
        end
        if self.WroteEnabled and self.Module.Enabled == true then
            safe('lease.module.restore.'..self.Name, function() self.Module:Toggle(true) end)
        end
    end
    self.Active[key] = lease
    return lease
end

function ModuleLeases:ReleaseOwner(owner)
    local list = {}
    for key, lease in pairs(self.Active) do if lease.Owner == owner then table.insert(list, lease) end end
    for _, lease in ipairs(list) do lease:Release() end
end

function ModuleLeases:Count(owner)
    local count = 0
    for _, lease in pairs(self.Active) do if not owner or lease.Owner == owner then count += 1 end end
    return count
end

local Jade = {
    Compatibility = {'jade_hammer_3', 'jade_hammer_2', 'jade_hammer_1', 'jade_hammer', 'jade_hammer_jump'},
    AbilityMap = {
        jade_hammer_3 = {'jade_hammer_jump'},
        jade_hammer_2 = {'jade_hammer_jump'},
        jade_hammer_1 = {'jade_hammer_jump'},
        jade_hammer = {'jade_hammer_jump'},
        jade_hammer_jump = {'jade_hammer_jump'}
    },
    Last = {}
}
Runtime.Jade = Jade

local function jadeTier(name)
    local normalized = tostring(name or ''):lower():gsub('[%s%-]+', '_')
    local tier = tonumber(normalized:match('jade_hammer_(%d+)'))
    return tier or (normalized:find('jade_hammer', 1, true) and 0 or -1)
end

local function normalizeItemType(value)
    if type(value) ~= 'string' then return nil end
    return value:lower():gsub('[%s%-]+', '_')
end

function Jade:IsHammerName(value)
    local normalized = normalizeItemType(value)
    return normalized == 'jade_hammer_jump' or normalized == 'jade_hammer' or (normalized ~= nil and normalized:match('^jade_hammer_%d+$') ~= nil)
end

function Jade:_candidateNames()
    local names, seen = {}, {}
    for _, name in ipairs(self.Compatibility) do seen[name] = true; table.insert(names, name) end
    if type(bedwars.ItemMeta) == 'table' then
        for name, meta in pairs(bedwars.ItemMeta) do
			if type(name) == 'string' and self:IsHammerName(name) and type(meta) == 'table' and not seen[name] then
                seen[name] = true
                table.insert(names, name)
            end
        end
    end
    table.sort(names, function(a, b) return jadeTier(a) > jadeTier(b) end)
    return names
end

function Jade:GetBestHammer()
    local found, seen = {}, {}
    local function add(item, source, fallbackType)
        if type(item) ~= 'table' then return end
        local tool = item.tool
        local itemType = normalizeItemType(item.itemType or fallbackType or (tool and tool.Name))
        if not self:IsHammerName(itemType) then return end
        if (not tool or typeof(tool) ~= 'Instance' or not tool.Parent) and lplr.Character then
            local handValue = lplr.Character:FindFirstChild('HandInvItem')
            handValue = handValue and handValue.Value
            if handValue and self:IsHammerName(handValue.Name) then tool = handValue end
        end
        if not tool or typeof(tool) ~= 'Instance' or not tool.Parent then return end
		if seen[tool] then return end
		seen[tool] = true
        table.insert(found, {
            Item = {itemType = itemType, tool = tool, amount = item.amount or 1},
            Source = source,
            Tier = jadeTier(itemType)
        })
    end

    for _, name in ipairs(self:_candidateNames()) do
        add(ask('jade.item.'..name, getItem, name), Capabilities.Source.REPLICATED, name)
    end

    local observed = store.inventory and store.inventory.inventory
    if observed then
        add(observed.hand, Capabilities.Source.REPLICATED)
        for _, item in pairs(observed.items or {}) do add(item, Capabilities.Source.REPLICATED) end
    end
    add(store.hand, Capabilities.Source.LIVE)

    local function addTools(container, source)
        if not container then return end
        for _, tool in ipairs(container:GetChildren()) do
            if tool:IsA('Tool') and self:IsHammerName(tool.Name) then
                add({itemType = tool.Name, tool = tool}, source)
            end
        end
    end
    addTools(lplr.Character, Capabilities.Source.LIVE)
    addTools(lplr:FindFirstChildOfClass('Backpack'), Capabilities.Source.LIVE)

    table.sort(found, function(a, b) return a.Tier > b.Tier end)
    if found[1] then
        return found[1].Item, {Source = found[1].Source, Tier = found[1].Tier}
    end
    return nil, {Source = Capabilities.Source.REPLICATED, Reason = 'not-in-inventory'}
end

local function liveAbilityController()
    local controller = bedwars.AbilityController
    if not controller then return nil, Capabilities.Source.UNKNOWN, false end
    local knit = bedwars.Knit and bedwars.Knit.Controllers
    if knit and controller == knit.JadeHammerController then
        return controller, Capabilities.Source.CONTROLLER, true
    end
    if type(controller.canUseAbility) == 'function' and type(controller.useAbility) == 'function' then
        return controller, Capabilities.Source.CONTROLLER, true
    end
    return controller, Capabilities.Source.FALLBACK, false
end

function Jade:ResolveAbility(hammer)
    local itemType = normalizeItemType(type(hammer) == 'table' and (hammer.itemType or (hammer.tool and hammer.tool.Name)) or tostring(hammer or ''))
    if not self:IsHammerName(itemType) then return nil, {Source = Capabilities.Source.UNKNOWN, Reason = 'not-a-jade-hammer'} end
    local candidates, seen = {}, {}
    local function add(value)
        if type(value) == 'string' and value ~= '' and not seen[value] then seen[value] = true; table.insert(candidates, value) end
    end
    for _, value in ipairs(self.AbilityMap[itemType] or {}) do add(value) end
    add('jade_hammer_jump')

    local meta = bedwars.ItemMeta and bedwars.ItemMeta[itemType]
    if type(meta) == 'table' then
        for key, value in pairs(meta) do
            local lowered = tostring(key):lower()
            if lowered:find('abil') and type(value) == 'string' then add(value) end
        end
    end

    local controller, source, authoritative = liveAbilityController()
    if controller then
        for _, candidate in ipairs(candidates) do
            local handler
            if type(controller.getAbilityHandler) == 'function' then
                handler = ask('jade.handler.'..candidate, controller.getAbilityHandler, controller, candidate)
            end
            if handler ~= nil then return candidate, {Source = source, Authoritative = authoritative, Handler = handler} end
            for _, field in ipairs({'abilities', 'Abilities', 'handlers', 'abilityHandlers'}) do
                if type(controller[field]) == 'table' and controller[field][candidate] ~= nil then
                    return candidate, {Source = source, Authoritative = authoritative, Handler = controller[field][candidate]}
                end
            end
        end
    end
    return candidates[1], {Source = Capabilities.Source.METADATA, Authoritative = false, Candidates = candidates}
end

function Jade:GetState(ability)
    local controller, source, authoritative = liveAbilityController()
    if controller and type(controller.canUseAbility) == 'function' then
        local ok, ready = pcall(controller.canUseAbility, controller, ability, {disableBlockedAbilityAlert = true})
        if ok and authoritative then
            return ready and 'READY' or 'BLOCKED', {Source = source, Authoritative = true}
        elseif ok then
            return 'UNKNOWN', {Source = source, Authoritative = false, Reported = ready}
        end
    end
    return 'UNKNOWN', {Source = Capabilities.Source.UNKNOWN, Authoritative = false}
end

function Jade:Equip(hammer, timeout, cancelled)
    if not hammer or not hammer.tool then return false, 'missing-hammer' end
    local function held()
        local handValue = lplr.Character and lplr.Character:FindFirstChild('HandInvItem')
        if handValue and handValue.Value == hammer.tool then return true end
        local current = store.hand
        return (current and (current.tool == hammer.tool or current.itemType == hammer.itemType)) and true or false
    end
    if held() then return true, 'already-held' end
    safe('jade.switch', switchItem, hammer.tool, 0.05)
    local deadline = now() + (timeout or 0.8)
    repeat
        if cancelled and cancelled() then return false, 'cancelled' end
        if held() then return true, 'replicated' end
        task.wait(0.03)
    until now() >= deadline
    return false, 'held-tool-not-acknowledged'
end

local function activationSignals(root, humanoid, ability)
    local state, source = Jade:GetState(ability)
    local attrs = {}
    local char = lplr.Character
    if char then
        for name, value in pairs(char:GetAttributes()) do
            local lower = tostring(name):lower()
            if lower:find('jade') or lower:find('hammer') or lower:find('ability') then attrs[name] = value end
        end
    end
    return {
        Position = root and root.Position,
        Velocity = root and root.AssemblyLinearVelocity or Vector3.zero,
        Floor = humanoid and humanoid.FloorMaterial,
        Readiness = state,
        ReadinessInfo = source,
        Attributes = attrs
    }
end

local function attributesChanged(before, after)
    for key, value in pairs(after or {}) do if before[key] ~= value then return true end end
    for key in pairs(before or {}) do if after[key] == nil then return true end end
    return false
end

function Jade:ObserveActivation(before, ability, timeout, cancelled)
    local deadline = now() + (timeout or 1.0)
    repeat
        if cancelled and cancelled() then return false, 'cancelled', nil end
        local root, _, humanoid = rootOfLocal()
        if not root then return false, 'character-lost', nil end
        local current = activationSignals(root, humanoid, ability)
        local moved = before.Position and (root.Position - before.Position).Magnitude > 1.25
        local velocityChanged = (root.AssemblyLinearVelocity - before.Velocity).Magnitude > 12
        local airborne = before.Floor ~= Enum.Material.Air and humanoid.FloorMaterial == Enum.Material.Air
        local cooldown = before.Readiness == 'READY' and current.Readiness == 'BLOCKED'
        local attribute = attributesChanged(before.Attributes, current.Attributes)
        if cooldown or airborne or moved or velocityChanged or attribute then
            return true, cooldown and 'cooldown-transition' or airborne and 'airborne-transition' or attribute and 'attribute-transition' or 'movement-transition', current
        end
        task.wait(0.03)
    until now() >= deadline
    return false, 'cast-not-confirmed', nil
end

function Jade:RequestActivation(hammer, ability, targetPosition, cancelled)
    local root, _, humanoid = rootOfLocal()
    if not root then return false, 'no-character' end
    local before = activationSignals(root, humanoid, ability)
    local request = {Sent = false, Paths = {}}

    local controllers = {bedwars.JadeHammerController, bedwars.HammerController, bedwars.ToolController, bedwars.ViewmodelController}
    for _, controller in ipairs(controllers) do
        if controller then
            for _, method in ipairs({'useTool', 'activateTool', 'activate', 'useItem'}) do
                if type(controller[method]) == 'function' then
                    local ok, result = pcall(controller[method], controller, hammer.tool, targetPosition)
                    table.insert(request.Paths, {Path = method, OK = ok, Result = result})
                    if ok and result ~= false then request.Sent = true; break end
                end
            end
        end
        if request.Sent then break end
    end

    if not request.Sent and hammer.tool and typeof(hammer.tool) == 'Instance' and hammer.tool:IsA('Tool') and type(hammer.tool.Activate) == 'function' then
        local ok = pcall(hammer.tool.Activate, hammer.tool)
        table.insert(request.Paths, {Path = 'Tool.Activate', OK = ok})
        request.Sent = ok
    end

    local controller, source, authoritative = liveAbilityController()
    if not request.Sent and controller and authoritative and type(controller.useAbility) == 'function' then
        local ready = true
        if type(controller.canUseAbility) == 'function' then
            local okReady, isReady = pcall(controller.canUseAbility, controller, ability, {disableBlockedAbilityAlert = true})
            ready = okReady and isReady ~= false
        end
        if ready then
            local ok, result = pcall(controller.useAbility, controller, ability)
            table.insert(request.Paths, {Path = 'AbilityController.useAbility', OK = ok, Result = result, Source = source})
            request.Sent = ok and result ~= false
        end
    end

    if not request.Sent and inputService then
        local ok = pcall(function()
            local vim = game:GetService('VirtualInputManager')
            local center = gameCamera.ViewportSize / 2
            vim:SendMouseButtonEvent(center.X, center.Y, 0, true, game, 0)
            vim:SendMouseButtonEvent(center.X, center.Y, 0, false, game, 0)
        end)
        table.insert(request.Paths, {Path = 'VirtualInput', OK = ok})
        request.Sent = ok
    end

    if not request.Sent and controller and type(controller.useAbility) == 'function' then
        local ok, result = pcall(controller.useAbility, controller, ability)
        table.insert(request.Paths, {Path = 'AbilityController.useAbility', OK = ok, Result = result, Source = source})
        request.Sent = ok and result ~= false
    end

    self.Last.Request = request
    if not request.Sent then return false, 'no-activation-path', request end
    local confirmed, reason, signal = self:ObserveActivation(before, ability, 1.1, cancelled)
    self.Last.Confirmation = {Confirmed = confirmed, Reason = reason, Signal = signal}
    return confirmed, reason, request
end

function Jade:GetCooldownState(ability)
    return self:GetState(ability)
end

function Jade:ActivateForTraversal(owner, direction, cancelled)
    local hammer = self:GetBestHammer()
    if not hammer then return {confirmed = false, reason = 'missing-hammer'} end
    local ability, abilityInfo = self:ResolveAbility(hammer)
    local ready, readyInfo = self:GetState(ability)
    if ready == 'BLOCKED' then return {confirmed = false, reason = 'cooldown', ability = ability, readiness = ready, readinessInfo = readyInfo} end
    local lease, leaseReason = Movement:Acquire(owner or 'LongJump', Movement.Priorities.Ability, 3, nil, true)
    if not lease then return {confirmed = false, reason = leaseReason} end
    local equipped, equipReason = self:Equip(hammer, 0.8, cancelled)
    if not equipped then lease:Release(); return {confirmed = false, reason = equipReason} end
    local root = rootOfLocal()
    local target = root and (root.Position + (direction or root.CFrame.LookVector) * 20) or nil
    local confirmed, reason = self:RequestActivation(hammer, ability, target, cancelled)
    task.delay(3, function() lease:Release() end)
    return {confirmed = confirmed, reason = reason, hammer = hammer, ability = ability, abilityInfo = abilityInfo, readiness = ready, readinessInfo = readyInfo, lease = lease}
end

local WorldSnapshot = {}
WorldSnapshot.__index = WorldSnapshot
Runtime.WorldSnapshot = WorldSnapshot

function WorldSnapshot.new(owner)
    local self = setmetatable({}, WorldSnapshot)
    self.Owner = owner
    self.Version = 0
    self.DynamicAt = 0
    self.WorldAt = 0
    self.WorldDirty = true
    self.Signature = ''
    self.Beds = {}
    self.Generators = {}
    self.Shops = {}
    self.Enemies = {}
    self.Connections = {}
    local function dirty() self.WorldDirty = true end
    safe('snapshot.bed.add', function() table.insert(self.Connections, collectionService:GetInstanceAddedSignal('bed'):Connect(dirty)) end)
    safe('snapshot.bed.remove', function() table.insert(self.Connections, collectionService:GetInstanceRemovedSignal('bed'):Connect(dirty)) end)
    safe('snapshot.gen.add', function() table.insert(self.Connections, collectionService:GetInstanceAddedSignal('Generator'):Connect(dirty)) end)
    safe('snapshot.gen.remove', function() table.insert(self.Connections, collectionService:GetInstanceRemovedSignal('Generator'):Connect(dirty)) end)
    return self
end

function WorldSnapshot:Destroy()
    for _, connection in ipairs(self.Connections) do safe('snapshot.disconnect', connection.Disconnect, connection) end
    table.clear(self.Connections)
end

function WorldSnapshot:_refreshWorld()
    table.clear(self.Beds)
    local team = self.Team
    for _, bed in ipairs(collectionService:GetTagged('bed')) do
        local part = bed.Parent and partOf(bed) or nil
        if part then
            local own = team ~= nil and bed:GetAttribute('Team'..team..'NoBreak') and true or false
            table.insert(self.Beds, {
                Object = bed, Part = part, Position = part.Position, Own = own,
                Shielded = (bed:GetAttribute('BedShieldEndTime') or 0) > workspace:GetServerTimeNow()
            })
        end
    end
    table.clear(self.Generators)
    for _, object in ipairs(collectionService:GetTagged('Generator')) do
        local part = object.Parent and partOf(object) or nil
        if part then
            local id = tostring(object:GetAttribute('Id') or ''):lower()
            table.insert(self.Generators, {Object = object, Part = part, Position = part.Position, Kind = id:find('emerald') and 'emerald' or id:find('diamond') and 'diamond' or 'iron'})
        end
    end
    table.clear(self.Shops)
    for _, entry in pairs(store.shop or {}) do
        local part = entry.RootPart and partOf(entry.RootPart) or nil
        if entry.Shop and part then table.insert(self.Shops, {Entry = entry, Position = part.Position, Id = entry.Id}) end
    end
    self.WorldDirty = false
    self.WorldAt = now()
end

local function armourTier()
    local ladder = {'leather_chestplate', 'iron_chestplate', 'diamond_chestplate', 'emerald_chestplate'}
    local best = 0
    local inv = store.inventory and store.inventory.inventory
    for _, entry in pairs((inv and inv.armor) or {}) do
        if entry and entry ~= 'empty' and entry.itemType then best = math.max(best, table.find(ladder, entry.itemType) or 0) end
    end
    if best == 0 and getBestArmor then
        local item = ask('snapshot.bestArmor', getBestArmor, 1)
        if item and item.itemType then best = table.find(ladder, item.itemType) or 0 end
    end
    return best
end

local function blockInventory()
    local inv = store.inventory and store.inventory.inventory
    local bestName, total = nil, 0
    for _, item in pairs((inv and inv.items) or {}) do
        local meta = bedwars.ItemMeta and bedwars.ItemMeta[item.itemType]
        if meta and meta.block and not tostring(item.itemType):find('tnt') and not tostring(item.itemType):find('cannon') and not tostring(item.itemType):find('bed') then
            total += item.amount or 0
            bestName = bestName or item.itemType
        end
    end
    return total, bestName
end

function WorldSnapshot:Refresh(force)
    local t = now()
    if not force and t - self.DynamicAt < 0.12 then return self end
    self.DynamicAt = t
    self.MatchState, self.MatchSource = Capabilities.Match:GetState()
    self.Team, self.TeamSource = Capabilities.Match:GetTeam()
    self.Map = store.map
    self.Queue = store.queueType
    self.Kit = Capabilities.Kits:GetEquipped()
    self.Root, self.Character, self.Humanoid = rootOfLocal()
    self.Alive = self.Root ~= nil
    self.Position = self.Root and self.Root.Position or nil
    local health = self.Character and self.Character.Health or 0
    local maxHealth = self.Character and self.Character.MaxHealth or 100
    self.Health = health
    self.HealthFraction = maxHealth > 0 and math.clamp(health / maxHealth, 0, 1) or 0
    self.Inventory = (store.inventory and store.inventory.inventory) or {items = {}, armor = {}}
    self.Hotbar = store.inventory and store.inventory.hotbar or {}
    self.Held = store.hand
    self.Iron = itemCount('iron')
    self.Diamond = itemCount('diamond')
    self.Emerald = itemCount('emerald')
    self.Blocks, self.BlockItem = blockInventory()
    self.ArmorTier = armourTier()

    if self.WorldDirty or t - self.WorldAt > 0.8 then self:_refreshWorld() end
    self.OwnBedAlive = false
    self.EnemyBeds = {}
    for _, bed in ipairs(self.Beds) do
        if bed.Own then self.OwnBedAlive = true else table.insert(self.EnemyBeds, bed) end
    end
    self.LastLife = self.Team ~= nil and not self.OwnBedAlive

    table.clear(self.Enemies)
    for _, ent in ipairs(entitylib.List or {}) do
        local root = ent.RootPart
        local sameTeam = ent.Player and self.Team ~= nil and ent.Player:GetAttribute('Team') == self.Team
        if ent.Targetable and root and root.Parent and not sameTeam and (not ent.Health or ent.Health > 0) then
            table.insert(self.Enemies, ent)
        end
    end
    table.sort(self.Enemies, function(a, b)
        if not self.Position then return false end
        return (a.RootPart.Position - self.Position).Magnitude < (b.RootPart.Position - self.Position).Magnitude
    end)
    self.NearbyThreat = self.Enemies[1]
    self.NearbyThreatDistance = self.NearbyThreat and self.Position and (self.NearbyThreat.RootPart.Position - self.Position).Magnitude or math.huge
    self.MovementOwner = Movement:GetOwner() or Movement:GetExternalOwner('AutoWin')

    local signature = table.concat({tostring(self.MatchState), tostring(self.Team), tostring(self.OwnBedAlive), tostring(#self.EnemyBeds), tostring(self.Alive), tostring(self.Blocks), tostring(self.ArmorTier), tostring(#self.Enemies)}, ':')
    if signature ~= self.Signature then self.Signature = signature; self.Version += 1 end
    return self
end

local FailureMemory = {}
FailureMemory.__index = FailureMemory
Runtime.FailureMemory = FailureMemory
function FailureMemory.new() return setmetatable({Entries = {}}, FailureMemory) end
function FailureMemory:_key(objective, action, route)
    return table.concat({objective or '?', action or '?', route or '?'}, '|')
end
function FailureMemory:Record(objective, action, route, reason, worldVersion)
    local key = self:_key(objective, action, route)
    local entry = self.Entries[key] or {Count = 0, First = now()}
    entry.Count += 1; entry.Last = now(); entry.Reason = reason; entry.WorldVersion = worldVersion
    entry.Cooldown = math.min(2 ^ math.min(entry.Count, 5), 30)
    self.Entries[key] = entry
    return entry
end
function FailureMemory:Penalty(objective, action, route, worldVersion)
    local entry = self.Entries[self:_key(objective, action, route)]
    if not entry then return 0 end
    if worldVersion and entry.WorldVersion and worldVersion - entry.WorldVersion >= 3 then return math.max(0, entry.Count - 2) * 4 end
    if now() - entry.Last > (entry.Cooldown or 0) then return math.max(0, entry.Count - 1) * 6 end
    return entry.Count * 18
end
function FailureMemory:ClearStale(worldVersion)
    for key, entry in pairs(self.Entries) do
        if now() - entry.Last > 120 or (worldVersion and entry.WorldVersion and worldVersion - entry.WorldVersion > 8) then self.Entries[key] = nil end
    end
end

local Navigation = {}
Navigation.__index = Navigation
Runtime.Navigation = Navigation
local CELL = 3
local STAND = 1.5
local HEAD = {Vector3.new(0, 1, 0), Vector3.new(0, 2, 0)}
local DIRS = {Vector3.new(1,0,0), Vector3.new(-1,0,0), Vector3.new(0,0,1), Vector3.new(0,0,-1)}
local DROPS = {0, -1, 1, -2, -3}

function Navigation.new(snapshot)
    return setmetatable({Snapshot = snapshot, Cache = {}, Recalculations = 0, Expansions = 0, Solid = {}, SolidStamp = 0}, Navigation)
end
function Navigation:Cell(pos) return bedwars.BlockController:getBlockPosition(pos) end
function Navigation:World(cell) return cell * CELL end
function Navigation:ClearLocalCache() table.clear(self.Solid); self.SolidStamp = now() end
function Navigation:SolidAt(cell)
    if now() - self.SolidStamp > 0.35 then self:ClearLocalCache() end
    local key = string.format('%d,%d,%d', cell.X, cell.Y, cell.Z)
    if self.Solid[key] ~= nil then return self.Solid[key] end
    local world = self:World(cell)
    local solid = getPlacedBlock(world) ~= nil
    if not solid then
        local params = RaycastParams.new(); params.FilterType = Enum.RaycastFilterType.Exclude; params.RespectCanCollide = true
        params.FilterDescendantsInstances = {lplr.Character, gameCamera}
        solid = workspace:Raycast(world + Vector3.new(0,1.4,0), Vector3.new(0,-2.8,0), params) ~= nil
    end
    self.Solid[key] = solid
    return solid
end

local function heapPush(heap, node, score)
    local i = #heap + 1; heap[i] = {Node = node, Score = score}
    while i > 1 do local p = math.floor(i/2); if heap[p].Score <= heap[i].Score then break end; heap[p], heap[i] = heap[i], heap[p]; i = p end
end
local function heapPop(heap)
    if #heap == 0 then return nil end
    local top = heap[1]; heap[1] = heap[#heap]; heap[#heap] = nil
    local i = 1
    while true do
        local l, r, s = i*2, i*2+1, i
        if l <= #heap and heap[l].Score < heap[s].Score then s = l end
        if r <= #heap and heap[r].Score < heap[s].Score then s = r end
        if s == i then break end
        heap[i], heap[s] = heap[s], heap[i]; i = s
    end
    return top.Node
end
local function cellKey(cell) return string.format('%d,%d,%d', cell.X, cell.Y, cell.Z) end
local function heuristic(a,b) return math.abs(a.X-b.X)+math.abs(a.Z-b.Z)+math.abs(a.Y-b.Y)*1.35 end

function Navigation:_localPlan(fromPos, toPos, allowPlace, allowBreak, cancelled)
    self:ClearLocalCache()
    local startCell = self:Cell(Vector3.new(fromPos.X, fromPos.Y - STAND, fromPos.Z))
    local goalCell = self:Cell(Vector3.new(toPos.X, toPos.Y - STAND, toPos.Z))
    local open, came, g, closed = {}, {}, {}, {}
    local startKey = cellKey(startCell); g[startKey] = 0; heapPush(open, startCell, heuristic(startCell, goalCell))
    local best, bestH = startCell, heuristic(startCell, goalCell)
    local budget = math.clamp(450 + bestH * 18, 700, 3500)
    local expansions = 0
    while true do
        local current = heapPop(open); if not current then break end
        local key = cellKey(current)
        if not closed[key] then
            closed[key] = true; expansions += 1
            local h = heuristic(current, goalCell)
            if h < bestH then best, bestH = current, h end
            if h <= 0.5 or expansions >= budget then break end
            if expansions % 250 == 0 then task.wait(); if cancelled and cancelled() then return nil, expansions end end
            local base = g[key] or 0
            for _, dir in ipairs(DIRS) do
                for _, dy in ipairs(DROPS) do
                    local n = current + dir + Vector3.new(0,dy,0); local nk = cellKey(n)
                    if not closed[nk] and heuristic(n, goalCell) < bestH + 80 then
                        local bridge = not self:SolidAt(n)
                        if not bridge or (allowPlace and dy == 0) then
                            local blocked, mine = false, 0
                            for _, off in ipairs(HEAD) do
                                local head = n + off
                                if self:SolidAt(head) then
                                    if allowBreak and getPlacedBlock(self:World(head)) then mine += 1 else blocked = true end
                                end
                            end
                            if not blocked then
                                local cost = base + 1 + (bridge and 2.0 or 0) + mine*2.4 + math.abs(dy)*0.5
                                if cost < (g[nk] or math.huge) then g[nk] = cost; came[nk] = current; heapPush(open,n,cost+heuristic(n,goalCell)) end
                            end
                        end
                    end
                end
            end
            if allowPlace then
                local n = current + Vector3.new(0,1,0); local nk = cellKey(n)
                if not closed[nk] then
                    local cost = base + 4
                    if cost < (g[nk] or math.huge) then g[nk] = cost; came[nk] = current; heapPush(open,n,cost+heuristic(n,goalCell)) end
                end
            end
        end
    end
    self.Expansions = expansions
    local cells, cursor, guard = {}, best, 0
    while cursor and cellKey(cursor) ~= startKey and guard < 512 do table.insert(cells,1,cursor); cursor = came[cellKey(cursor)]; guard += 1 end
    return cells, expansions
end

local function groundScore(a,b)
    local distance = ((b-a)*Vector3.new(1,0,1)).Magnitude
    return distance + math.abs(b.Y-a.Y)*0.7
end

function Navigation:_strategicAnchors(snapshot, goal)
    local nodes = {{Kind='Start', Position=snapshot.Position}, {Kind='Goal', Position=goal}}
    for _, gen in ipairs(snapshot.Generators) do if gen.Kind ~= 'iron' then table.insert(nodes,{Kind='Generator',Position=gen.Position,Object=gen.Object}) end end
    for _, shop in ipairs(snapshot.Shops) do table.insert(nodes,{Kind='Shop',Position=shop.Position,Object=shop.Entry}) end
    for _, bed in ipairs(snapshot.Beds) do table.insert(nodes,{Kind=bed.Own and 'HomeBase' or 'EnemyBase',Position=bed.Position,Object=bed.Object}) end
    return nodes
end

function Navigation:_strategicPath(snapshot, goal)
    local nodes = self:_strategicAnchors(snapshot, goal)
    if #nodes <= 2 then return {nodes[1], nodes[2]} end
    local dist, prev, unvisited = {[1]=0}, {}, {}
    for i=1,#nodes do unvisited[i]=true end
    while true do
        local best, bestD
        for i in pairs(unvisited) do local d=dist[i] or math.huge; if not bestD or d<bestD then best,bestD=i,d end end
        if not best or best==2 then break end
        unvisited[best]=nil
        for j in pairs(unvisited) do
            local direct=(nodes[j].Position-nodes[best].Position).Magnitude
            if direct <= 135 or j==2 then
                local cost=bestD+groundScore(nodes[best].Position,nodes[j].Position)+(direct>90 and 18 or 0)
                if cost<(dist[j] or math.huge) then dist[j]=cost; prev[j]=best end
            end
        end
    end
    local ids={2}; local cursor=2; local guard=0
    while cursor~=1 and prev[cursor] and guard<32 do cursor=prev[cursor]; table.insert(ids,1,cursor); guard+=1 end
    if ids[1]~=1 then return {nodes[1],nodes[2]} end
    local path={}; for _,id in ipairs(ids) do table.insert(path,nodes[id]) end; return path
end

local function segmentKind(nav, previous, cell, allowBreak)
    if not nav:SolidAt(cell) then return 'Bridge' end
    if previous and cell.Y > previous.Y then return 'Climb' end
    if allowBreak then
        for _, off in ipairs(HEAD) do if getPlacedBlock(nav:World(cell+off)) then return 'Mine' end end
    end
    return 'Walk'
end

function Navigation:Plan(snapshot, goal, objective, allowBreak, cancelled)
    if not snapshot.Position or not goal then return nil, 'missing-position' end
    self.Recalculations += 1
    local strategic = self:_strategicPath(snapshot, goal)
    local route = {Objective=objective, Target=goal, Strategic=strategic, Segments={}, RequiredBlocks=0, ExpectedMining=0, Distance=0, ExpectedTime=0, Risk=0, Cost=0, WorldVersion=snapshot.Version, Recalculation=self.Recalculations, Expansions=0}
    local from = snapshot.Position
    for index=2,#strategic do
        local to = strategic[index].Position
        local cells, expansions = self:_localPlan(from,to,true,allowBreak,cancelled)
        route.Expansions += expansions or 0
        if not cells or #cells==0 then
            table.insert(route.Segments,{Kind='Wait',From=from,To=to,Reason='partial-route'}); route.Risk += 20
        else
            local previous = self:Cell(Vector3.new(from.X,from.Y-STAND,from.Z))
            local currentSegment
            for _,cell in ipairs(cells) do
                local kind=segmentKind(self,previous,cell,allowBreak)
                if not currentSegment or currentSegment.Kind~=kind then currentSegment={Kind=kind,Cells={}}; table.insert(route.Segments,currentSegment) end
                table.insert(currentSegment.Cells,cell)
                if kind=='Bridge' then route.RequiredBlocks += 1; route.Risk += 0.6 elseif kind=='Mine' then route.ExpectedMining += 1 end
                route.Distance += CELL; previous=cell
            end
        end
        from=to
    end
    route.RequiredBlocks += route.RequiredBlocks > 0 and 8 or 0
    route.ExpectedTime = route.Distance/16 + route.RequiredBlocks*0.08 + route.ExpectedMining*0.35
    route.Cost = route.ExpectedTime + route.Risk
    return route
end

local LoadoutPlanner = {}
LoadoutPlanner.__index = LoadoutPlanner
Runtime.LoadoutPlanner = LoadoutPlanner
function LoadoutPlanner.new() return setmetatable({},LoadoutPlanner) end
function LoadoutPlanner:Evaluate(snapshot, route)
    local result={RequiredBlocks=route and route.RequiredBlocks or 8, Deficits={}, Purchases={}}
    result.RequiredBlocks=math.max(result.RequiredBlocks,8)
    if snapshot.Blocks<result.RequiredBlocks then result.Deficits.Blocks=result.RequiredBlocks-snapshot.Blocks end
    local desiredArmor=snapshot.LastLife and 2 or 1
    if snapshot.ArmorTier<desiredArmor then result.Deficits.Armor=desiredArmor-snapshot.ArmorTier end
    if result.Deficits.Blocks then table.insert(result.Purchases,{Kind='Blocks',Item='wool_white',Priority=100}) end
    local armour={'leather_chestplate','iron_chestplate','diamond_chestplate','emerald_chestplate'}
    if result.Deficits.Armor then table.insert(result.Purchases,{Kind='Armor',Item=armour[snapshot.ArmorTier+1],Priority=90}) end
    local tool=store.tools and store.tools.pickaxe
    if route and route.ExpectedMining>0 and not tool then table.insert(result.Purchases,{Kind='Tool',Item='wood_pickaxe',Priority=80}) end
    table.sort(result.Purchases,function(a,b)return a.Priority>b.Priority end)
    local ironNeed=0
    for _,purchase in ipairs(result.Purchases) do
        local item=Capabilities.Shop:GetItem(purchase.Item)
        if item and item.currency=='iron' then ironNeed+=item.price or 0 end
    end
    result.IronDeficit=math.max(ironNeed-snapshot.Iron,0)
    return result
end

local ActionState={RUNNING='RUNNING',SUCCESS='SUCCESS',FAILED='FAILED',CANCELLED='CANCELLED',BLOCKED='BLOCKED'}
Runtime.ActionState=ActionState
local ActionBase={}
function ActionBase:Cancel(reason) self.Cancelled=true; self.State=ActionState.CANCELLED; self.Reason=reason or 'cancelled' end
function ActionBase:Finish(state,reason) self.State=state; self.Reason=reason; return state,reason end
local function action(kind,data)
    return {Kind=kind,Data=data or {},State=ActionState.RUNNING,Started=now(),Reason=nil,Cancelled=false,ProgressAt=now()}
end
local Drive={Aim=nil,At=0,Moving=false}
Runtime.Drive=Drive

local TravelAction=setmetatable({},{__index=ActionBase})
function TravelAction.new(director,objective,route)
    local a=action('Travel',{Objective=objective,Route=route,Segment=1,Cell=1,Best=math.huge,StallAt=now(),Lease=nil})
    return setmetatable(a,{__index=TravelAction})
end
function TravelAction:Cleanup()
    if self.Data.Lease then self.Data.Lease:Release(); self.Data.Lease=nil end
    Drive.Aim=nil
end
function TravelAction:Cancel(reason) self.Cancelled=true; self.State=ActionState.CANCELLED; self.Reason=reason; self:Cleanup() end
function TravelAction:Tick(director,snapshot)
    if self.Cancelled then return self.State,self.Reason end
    local route=self.Data.Route
    local goal=self.Data.Objective.Position
    if not snapshot.Alive or not goal then self:Cleanup(); return self:Finish(ActionState.CANCELLED,'character-or-target-lost') end
    if (snapshot.Position-goal).Magnitude <= (self.Data.Objective.StopRange or 8) then self:Cleanup(); return self:Finish(ActionState.SUCCESS,'arrived') end
    if snapshot.Version-route.WorldVersion>=4 then self:Cleanup(); return self:Finish(ActionState.BLOCKED,'route-stale') end
    if self.Data.Lease and not self.Data.Lease:Renew(0.5) then self.Data.Lease=nil end
    if not self.Data.Lease then
        local lease,reason=Movement:Acquire('AutoWin',Movement.Priorities.AutoWin,0.5,function() self:Cancel('movement-preempted') end)
        if not lease then Drive.Aim=nil; return self:Finish(ActionState.BLOCKED,reason) end
        self.Data.Lease=lease
    end
    local root,char,humanoid=rootOfLocal(); if not root or not humanoid then self:Cleanup(); return self:Finish(ActionState.CANCELLED,'character-lost') end
    local nav=director.Navigation
    for _=1,4 do
        local segment=route.Segments[self.Data.Segment]
        if not segment then self:Cleanup(); return self:Finish(ActionState.BLOCKED,'route-exhausted') end
        if segment.Kind=='Wait' then self:Cleanup(); return self:Finish(ActionState.BLOCKED,segment.Reason or 'route-wait') end
        local cell=segment.Cells and segment.Cells[self.Data.Cell]
        if not cell then
            self.Data.Segment+=1; self.Data.Cell=1
        else
            if segment.Kind=='Bridge' and not nav:SolidAt(cell) then
                if snapshot.Blocks<=0 or not snapshot.BlockItem then self:Cleanup(); return self:Finish(ActionState.BLOCKED,'no-blocks') end
                Capabilities.Blocks:Place(nav:World(cell),snapshot.BlockItem); nav:ClearLocalCache(); return ActionState.RUNNING
            elseif segment.Kind=='Mine' then
                for _,off in ipairs(HEAD) do
                    local block=getPlacedBlock(nav:World(cell+off))
                    if block then Drive.Aim=nil; Capabilities.Blocks:Break(block); nav:ClearLocalCache(); return ActionState.RUNNING end
                end
            elseif segment.Kind=='Climb' and humanoid.FloorMaterial~=Enum.Material.Air then
                safe('travel.jump',humanoid.ChangeState,humanoid,Enum.HumanoidStateType.Jumping)
            end
            local aim=nav:World(cell)+Vector3.new(0,(char.HipHeight or 2)+STAND,0)
            if ((aim-root.Position)*Vector3.new(1,0,1)).Magnitude>=1.7 then
                Drive.Aim=aim; Drive.At=now()
                break
            end
            self.Data.Cell+=1; self.ProgressAt=now()
        end
    end
    local distance=(goal-root.Position).Magnitude
    if distance<self.Data.Best-1 then self.Data.Best=distance; self.Data.StallAt=now(); self.ProgressAt=now() elseif now()-self.Data.StallAt>5 then self:Cleanup(); return self:Finish(ActionState.FAILED,'segment-stalled') end
    return ActionState.RUNNING
end

local BreakBedAction=setmetatable({},{__index=ActionBase})
function BreakBedAction.new(objective) return setmetatable(action('BreakBed',{Objective=objective,LastHit=0}),{__index=BreakBedAction}) end
function BreakBedAction:Tick(director,snapshot)
    local bed=self.Data.Objective.Target
    if not bed or not bed.Parent or not partOf(bed) then return self:Finish(ActionState.SUCCESS,'bed-gone') end
    local part=partOf(bed); if not snapshot.Position or (part.Position-snapshot.Position).Magnitude>28 then return self:Finish(ActionState.BLOCKED,'bed-out-of-range') end
    if (bed:GetAttribute('BedShieldEndTime') or 0)>workspace:GetServerTimeNow() then return self:Finish(ActionState.BLOCKED,'bed-shield') end
    if now()-self.Data.LastHit>=0.22 then self.Data.LastHit=now(); safe('autowin.breakbed',safeBreakBlock,part,true,true,nil,true,breakmethods.Distance,360,false); self.ProgressAt=now() end
    return ActionState.RUNNING
end

local CombatAction=setmetatable({},{__index=ActionBase})
function CombatAction.new(objective) return setmetatable(action('Combat',{Objective=objective,Aura=nil,Travel=nil,LastSeen=now()}),{__index=CombatAction}) end
function CombatAction:Cleanup() if self.Data.Aura then self.Data.Aura:Release(); self.Data.Aura=nil end; if self.Data.Travel then self.Data.Travel:Cancel('combat-cleanup'); self.Data.Travel=nil end end
function CombatAction:Cancel(reason) self.Cancelled=true;self.State=ActionState.CANCELLED;self.Reason=reason;self:Cleanup() end
function CombatAction:Tick(director,snapshot)
    local ent=self.Data.Objective.Target
    if not ent or not ent.RootPart or not ent.RootPart.Parent or (ent.Health and ent.Health<=0) then self:Cleanup();return self:Finish(ActionState.SUCCESS,'target-gone') end
    if snapshot.LastLife and snapshot.HealthFraction<0.38 then self:Cleanup();return self:Finish(ActionState.BLOCKED,'low-health-last-life') end
    local distance=(ent.RootPart.Position-snapshot.Position).Magnitude
    if distance>(self.Data.Objective.StopRange or 8)+5 then
        if not self.Data.Travel or self.Data.Travel.State~=ActionState.RUNNING then
            local route=director.Navigation:Plan(snapshot,ent.RootPart.Position,'hunt',true,function()return not director.Running end)
            if not route then return self:Finish(ActionState.FAILED,'no-combat-route') end
            self.Data.Objective.Position=ent.RootPart.Position;self.Data.Travel=TravelAction.new(director,self.Data.Objective,route)
        else self.Data.Objective.Position=ent.RootPart.Position end
        local state,reason=self.Data.Travel:Tick(director,snapshot)
        if state~=ActionState.RUNNING and state~=ActionState.SUCCESS then self:Cleanup();return self:Finish(state,reason) end
        return ActionState.RUNNING
    end
    if not self.Data.Aura then self.Data.Aura=ModuleLeases:Acquire('AutoWin','Killaura',{['Require mouse down']=false,['GUI check']=false},true) end
    self.ProgressAt=now();return ActionState.RUNNING
end

local HealAction=setmetatable({},{__index=ActionBase})
function HealAction.new(objective) return setmetatable(action('Heal',{Objective=objective,Consume=nil,Travel=nil}),{__index=HealAction}) end
function HealAction:Cleanup() if self.Data.Consume then self.Data.Consume:Release();self.Data.Consume=nil end;if self.Data.Travel then self.Data.Travel:Cancel('heal-cleanup') end end
function HealAction:Cancel(reason) self.Cancelled=true;self.State=ActionState.CANCELLED;self.Reason=reason;self:Cleanup() end
function HealAction:Tick(director,snapshot)
    if snapshot.HealthFraction>=0.82 then self:Cleanup();return self:Finish(ActionState.SUCCESS,'healed') end
    if not self.Data.Consume then self.Data.Consume=ModuleLeases:Acquire('AutoWin','AutoConsume',{},true) end
    if snapshot.NearbyThreat and snapshot.NearbyThreatDistance<45 and snapshot.Position then
        local away=(snapshot.Position-snapshot.NearbyThreat.RootPart.Position)*Vector3.new(1,0,1)
        if away.Magnitude>0.1 then
            self.Data.Objective.Position=snapshot.Position+away.Unit*35;self.Data.Objective.StopRange=5
            if not self.Data.Travel or self.Data.Travel.State~=ActionState.RUNNING then
                local route=director.Navigation:Plan(snapshot,self.Data.Objective.Position,'heal',false,function()return not director.Running end)
                if route then self.Data.Travel=TravelAction.new(director,self.Data.Objective,route) end
            end
            if self.Data.Travel then self.Data.Travel:Tick(director,snapshot) end
        end
    end
    if now()-self.Started>10 then self:Cleanup();return self:Finish(ActionState.BLOCKED,'heal-timeout') end
    return ActionState.RUNNING
end

local CollectAction=setmetatable({},{__index=ActionBase})
function CollectAction.new(objective) return setmetatable(action('Collect',{Objective=objective,Travel=nil,LastIron=nil,LastGain=now()}),{__index=CollectAction}) end
function CollectAction:Cleanup() if self.Data.Travel then self.Data.Travel:Cancel('collect-cleanup') end end
function CollectAction:Cancel(reason) self.Cancelled=true;self.State=ActionState.CANCELLED;self.Reason=reason;self:Cleanup() end
function CollectAction:Tick(director,snapshot)
    local target=self.Data.Objective.TargetIron or snapshot.Iron
    if snapshot.Iron>=target then self:Cleanup();return self:Finish(ActionState.SUCCESS,'resources-ready') end
    if not self.Data.Objective.Position then return self:Finish(ActionState.FAILED,'generator-missing') end
    if (snapshot.Position-self.Data.Objective.Position).Magnitude>10 then
        if not self.Data.Travel or self.Data.Travel.State~=ActionState.RUNNING then
            local route=director.Navigation:Plan(snapshot,self.Data.Objective.Position,'collect',false,function()return not director.Running end)
            if not route then return self:Finish(ActionState.FAILED,'generator-route-missing') end
            self.Data.Travel=TravelAction.new(director,self.Data.Objective,route)
        end
        local state,reason=self.Data.Travel:Tick(director,snapshot);if state~=ActionState.RUNNING and state~=ActionState.SUCCESS then return self:Finish(state,reason) end
    else
        if self.Data.LastIron==nil or snapshot.Iron>self.Data.LastIron then self.Data.LastIron=snapshot.Iron;self.Data.LastGain=now();self.ProgressAt=now() elseif now()-self.Data.LastGain>12 then return self:Finish(ActionState.BLOCKED,'generator-not-producing') end
    end
    return ActionState.RUNNING
end

local PurchaseAction=setmetatable({},{__index=ActionBase})
function PurchaseAction.new(objective) return setmetatable(action('Purchase',{Objective=objective,Travel=nil,LastBuy=0}),{__index=PurchaseAction}) end
function PurchaseAction:Cleanup() if self.Data.Travel then self.Data.Travel:Cancel('purchase-cleanup') end end
function PurchaseAction:Cancel(reason) self.Cancelled=true;self.State=ActionState.CANCELLED;self.Reason=reason;self:Cleanup() end
function PurchaseAction:Tick(director,snapshot)
    local shop=self.Data.Objective.Target
    if not shop then return self:Finish(ActionState.FAILED,'shop-missing') end
    if (snapshot.Position-shop.Position).Magnitude>18 then
        self.Data.Objective.Position=shop.Position
        if not self.Data.Travel or self.Data.Travel.State~=ActionState.RUNNING then
            local route=director.Navigation:Plan(snapshot,shop.Position,'purchase',false,function()return not director.Running end)
            if not route then return self:Finish(ActionState.FAILED,'shop-route-missing') end
            self.Data.Travel=TravelAction.new(director,self.Data.Objective,route)
        end
        local state,reason=self.Data.Travel:Tick(director,snapshot);if state~=ActionState.RUNNING and state~=ActionState.SUCCESS then return self:Finish(state,reason) end
        return ActionState.RUNNING
    end
    local plan=director.Loadout:Evaluate(snapshot,director.RoutePlan)
    if #plan.Purchases==0 then return self:Finish(ActionState.SUCCESS,'loadout-ready') end
    if now()-self.Data.LastBuy<0.25 then return ActionState.RUNNING end
    local desired=plan.Purchases[1];local item=Capabilities.Shop:GetItem(desired.Item,shop.Id)
    if not item then return self:Finish(ActionState.BLOCKED,'shop-item-unavailable:'..desired.Item) end
    local currency=itemCount(item.currency)
    if currency<(item.price or math.huge) then return self:Finish(ActionState.BLOCKED,'insufficient-'..tostring(item.currency)) end
    self.Data.LastBuy=now();safe('autowin.purchase',function() bedwars.Client:Get('BedwarsPurchaseItem'):CallServerAsync({shopItem=item,shopId=shop.Id}) end);self.ProgressAt=now();return ActionState.RUNNING
end

local BankAction=setmetatable({},{__index=ActionBase})
function BankAction.new(objective) return setmetatable(action('Bank',{Objective=objective,Lease=nil}),{__index=BankAction}) end
function BankAction:Tick()
    if not self.Data.Lease then self.Data.Lease=ModuleLeases:Acquire('AutoWin','AutoBank',{},true) end
    if self.Data.Lease then task.delay(0.5,function() if self.Data.Lease then self.Data.Lease:Release();self.Data.Lease=nil end end);return self:Finish(ActionState.SUCCESS,'delegated') end
    return self:Finish(ActionState.BLOCKED,'autobank-unavailable')
end
function BankAction:Cancel(reason) if self.Data.Lease then self.Data.Lease:Release() end;self.State=ActionState.CANCELLED;self.Reason=reason end

local ActionScheduler={}
ActionScheduler.__index=ActionScheduler
Runtime.ActionScheduler=ActionScheduler
function ActionScheduler.new(director) return setmetatable({Director=director,Current=nil,LastResult=nil},ActionScheduler) end
function ActionScheduler:Cancel(reason) if self.Current then self.Current:Cancel(reason);self.LastResult={State=self.Current.State,Reason=self.Current.Reason,Kind=self.Current.Kind};self.Current=nil end end
function ActionScheduler:Start(actionObject) self:Cancel('superseded');self.Current=actionObject;return actionObject end
function ActionScheduler:Tick(snapshot)
    if not self.Current then return nil end
    local state,reason=self.Current:Tick(self.Director,snapshot)
    if state and state~=ActionState.RUNNING then self.LastResult={State=state,Reason=reason,Kind=self.Current.Kind};self.Current=nil end
    return state,reason
end

local ObjectivePlanner={}
ObjectivePlanner.__index=ObjectivePlanner
Runtime.ObjectivePlanner=ObjectivePlanner
function ObjectivePlanner.new(failures) return setmetatable({Failures=failures,Current=nil,CommittedAt=0,Scores={}},ObjectivePlanner) end
local function nearest(list,pos)
    local best,bestD
    for _,entry in ipairs(list or {}) do local p=entry.Position or (entry.RootPart and entry.RootPart.Position);if p then local d=(p-pos).Magnitude;if not bestD or d<bestD then best,bestD=entry,d end end end
    return best,bestD or math.huge
end
function ObjectivePlanner:Score(snapshot,navigation,loadout)
    local candidates={};local function add(kind,score,data) data=data or {};data.Kind=kind;data.Score=score;table.insert(candidates,data) end
    if snapshot.MatchState==Capabilities.Match.States.PRE then add('WAIT',1000,{Reason='prematch'}) return candidates end
    if snapshot.MatchState==Capabilities.Match.States.POST then add('MATCH_DONE',1000) return candidates end
    if not snapshot.Alive then add('WAIT_RESPAWN',950) return candidates end
    if snapshot.LastLife and snapshot.HealthFraction<0.46 then add('HEAL',920+(0.46-snapshot.HealthFraction)*200) end
    if snapshot.NearbyThreat and snapshot.NearbyThreatDistance<16 then add('IMMEDIATE_THREAT',880-snapshot.NearbyThreatDistance,{Target=snapshot.NearbyThreat,Position=snapshot.NearbyThreat.RootPart.Position,StopRange=8}) end
    for _,bed in ipairs(snapshot.EnemyBeds) do
        local d=(bed.Position-snapshot.Position).Magnitude
        local penalty=self.Failures:Penalty('ATTACK_BED','Travel',tostring(bed.Object),snapshot.Version)
        local score=760-d*0.8-(bed.Shielded and 180 or 0)-penalty
        if snapshot.LastLife then score-=50 end
        add('ATTACK_BED',score,{Target=bed.Object,Position=bed.Position,Bed=bed,StopRange=8,Key=tostring(bed.Object)})
    end
    if #snapshot.EnemyBeds==0 and #snapshot.Enemies>0 then
        local ent=snapshot.Enemies[1];local d=(ent.RootPart.Position-snapshot.Position).Magnitude
        local health=ent.Health or 100
        add('HUNT_FINAL',700-d*0.6+(100-health)*0.2-self.Failures:Penalty('HUNT_FINAL','Combat',tostring(ent.Character),snapshot.Version),{Target=ent,Position=ent.RootPart.Position,StopRange=8,Key=tostring(ent.Character)})
    end
    local shop,shopDist=nearest(snapshot.Shops,snapshot.Position)
    if shop and snapshot.ArmorTier==0 then add('PURCHASE_LOADOUT',650-shopDist*0.5,{Target=shop,Position=shop.Position,StopRange=16}) end
    if snapshot.Blocks<8 and shop then add('PURCHASE_LOADOUT',675-shopDist*0.4,{Target=shop,Position=shop.Position,StopRange=16}) end
    local gen,genDist=nearest(snapshot.Generators,snapshot.Position)
    if gen and snapshot.Iron<16 then add('COLLECT_RESOURCES',520-genDist*0.3,{Target=gen,Position=gen.Position,TargetIron=16,StopRange=8}) end
    table.sort(candidates,function(a,b)return a.Score>b.Score end)
    return candidates
end
function ObjectivePlanner:Choose(snapshot,navigation,loadout)
    local list=self:Score(snapshot,navigation,loadout);table.clear(self.Scores);for _,obj in ipairs(list) do self.Scores[obj.Kind..':'..tostring(obj.Key or obj.Target or '')]=obj.Score end
    local best=list[1]
    if not best then return nil end
    if self.Current and now()-self.CommittedAt<2.0 then
        local currentScore=self.Current.Score or -math.huge
        if self.Current.Kind==best.Kind and (self.Current.Target==best.Target or not self.Current.Target) then self.Current.Score=best.Score;return self.Current end
        if best.Score<currentScore+35 then return self.Current end
    end
    self.Current=best;self.CommittedAt=now();return best
end

local SessionSupervisor={}
SessionSupervisor.__index=SessionSupervisor
Runtime.SessionSupervisor=SessionSupervisor
function SessionSupervisor.new(module,options)
    return setmetatable({Module=module,Options=options,Queued=false,Rejoining=false,Connections={}},SessionSupervisor)
end
function SessionSupervisor:WriteState()
    safe('session.state',function()
        writefile('aetherv2/profiles/autowin.json',httpService:JSONEncode({enabled=self.Module.Enabled,resume=self.Options.ResumeInLobby.Enabled,queue=self.Options.Gamemode.Value,fallback=store.queueType,stamp=os.time()}))
    end)
end
function SessionSupervisor:ResolveQueue()
    local wanted=self.Options.Gamemode.Value
    if wanted=='Current' or not wanted then return store.queueType end
    if wanted=='Random' then
        local ids={};for id,meta in pairs(bedwars.QueueMeta or {}) do if not meta.disabled and not meta.voiceChatOnly and not meta.rankCategory then table.insert(ids,id) end end
        return #ids>0 and ids[math.random(1,#ids)] or store.queueType
    end
    return wanted
end
function SessionSupervisor:Queue()
    if self.Queued or not self.Options.Requeue.Enabled then return end
    local allowed=ask('session.queue-state',function() local s=bedwars.Store:getState();return not s.Game.customMatch and s.Party.leader.userId==lplr.UserId and s.Party.queueState==0 end)
    if not allowed then return end
    self.Queued=true;self:WriteState();safe('session.queue',bedwars.QueueController.joinQueue,bedwars.QueueController,self:ResolveQueue())
end
function SessionSupervisor:Rejoin()
    if self.Rejoining or not self.Options.AutoRejoin.Enabled then return end
    self.Rejoining=true;self:WriteState();safe('session.rejoin',function() game:GetService('TeleportService'):Teleport(6872265039,lplr) end)
    task.delay(8,function() if self.Module.Enabled then self.Rejoining=false end end)
end
function SessionSupervisor:Start()
    self:WriteState()
    if guiService then table.insert(self.Connections,guiService.ErrorMessageChanged:Connect(function(message) if self.Module.Enabled and type(message)=='string' and message~='' then task.delay(2,function() if self.Module.Enabled then self:Rejoin() end end) end end)) end
    if vapeEvents and vapeEvents.MatchEndEvent then table.insert(self.Connections,vapeEvents.MatchEndEvent.Event:Connect(function() if self.Module.Enabled then task.delay(1,function() if self.Module.Enabled then self:Queue() end end) end end)) end
end
function SessionSupervisor:Stop()
    for _,connection in ipairs(self.Connections) do safe('session.disconnect',connection.Disconnect,connection) end;table.clear(self.Connections);self.Rejoining=false;self:WriteState()
end

local MatchDirector={}
MatchDirector.__index=MatchDirector
Runtime.MatchDirector=MatchDirector

function MatchDirector.new(module,options,hud)
    local self=setmetatable({},MatchDirector)
    self.Module=module;self.Options=options;self.HUD=hud;self.Running=true;self.Generation=0
    self.Snapshot=WorldSnapshot.new('AutoWin');self.Failures=FailureMemory.new();self.Navigation=Navigation.new(self.Snapshot);self.Loadout=LoadoutPlanner.new();self.Planner=ObjectivePlanner.new(self.Failures);self.Scheduler=ActionScheduler.new(self)
    self.Session=SessionSupervisor.new(module,options);self.RoutePlan=nil;self.Objective=nil;self.RecoveryLevel=0;self.LastProgress=now();self.LastFailure=nil;self.LastFailureReason=nil;self.LastWorldVersion=0
    return self
end

function MatchDirector:Cancel(reason)
    if not self.Running then return end
    self.Running=false;self.Generation+=1;self.Scheduler:Cancel(reason or 'director-stop');ModuleLeases:ReleaseOwner('AutoWin');local current=Movement.Current;if current and current.Owner=='AutoWin' then current:Release() end;self.Snapshot:Destroy();self.Session:Stop()
    Drive.Aim=nil
    safe('director.unbind',function() runService:UnbindFromRenderStep('AetherAutoWinDrive') end)
    local _,_,humanoid=rootOfLocal()
    if humanoid and Drive.Moving then Drive.Moving=false; safe('director.stop',humanoid.Move,humanoid,Vector3.zero,false) end
end

function MatchDirector:_drive()
    local root,_,humanoid=rootOfLocal()
    if not root or not humanoid then return end
    local aim=Drive.Aim
    if not aim or now()-Drive.At>0.35 then
        if Drive.Moving then Drive.Moving=false; humanoid:Move(Vector3.zero,false) end
        return
    end
    local delta=(aim-root.Position)*Vector3.new(1,0,1)
    Drive.Moving=true
    humanoid:Move(delta.Magnitude>0.6 and delta.Unit or Vector3.zero,false)
end

function MatchDirector:_routeFor(objective,snapshot)
    if not objective or not objective.Position then return nil end
    if self.RoutePlan and self.RoutePlan.Target and (self.RoutePlan.Target-objective.Position).Magnitude<6 and snapshot.Version-self.RoutePlan.WorldVersion<3 then return self.RoutePlan end
    self.RoutePlan=self.Navigation:Plan(snapshot,objective.Position,objective.Kind,true,function() return not self.Running end)
    return self.RoutePlan
end

function MatchDirector:_nearestShop(snapshot) return nearest(snapshot.Shops,snapshot.Position) end
function MatchDirector:_nearestGenerator(snapshot) return nearest(snapshot.Generators,snapshot.Position) end

function MatchDirector:_makeAction(objective,snapshot)
    if objective.Kind=='WAIT' or objective.Kind=='WAIT_RESPAWN' or objective.Kind=='MATCH_DONE' then return nil end
    if objective.Kind=='HEAL' then return HealAction.new(objective) end
    if objective.Kind=='IMMEDIATE_THREAT' or objective.Kind=='HUNT_FINAL' then return CombatAction.new(objective) end
    if objective.Kind=='COLLECT_RESOURCES' then return CollectAction.new(objective) end
    if objective.Kind=='PURCHASE_LOADOUT' then return PurchaseAction.new(objective) end
    if objective.Kind=='ATTACK_BED' then
        local distance=(snapshot.Position-objective.Position).Magnitude
        if distance<=26 then return BreakBedAction.new(objective) end
        local route=self:_routeFor(objective,snapshot);if not route then return nil,'route-unavailable' end
        local loadout=self.Loadout:Evaluate(snapshot,route)
        if snapshot.Blocks<loadout.RequiredBlocks then
            local shop=self:_nearestShop(snapshot)
            if shop then return PurchaseAction.new({Kind='PURCHASE_LOADOUT',Target=shop,Position=shop.Position,StopRange=16,Score=objective.Score+1}) end
            local gen=self:_nearestGenerator(snapshot)
            if gen then return CollectAction.new({Kind='COLLECT_RESOURCES',Target=gen,Position=gen.Position,TargetIron=math.max(16,loadout.IronDeficit+snapshot.Iron),StopRange=8}) end
        end
        return TravelAction.new(self,objective,route)
    end
    return nil,'unsupported-objective'
end

function MatchDirector:_interruptReason(snapshot)
    if snapshot.MatchState==Capabilities.Match.States.POST then return 'match-ended' end
    if not snapshot.Alive and self.Scheduler.Current then return 'local-death' end
    if self.Scheduler.Current and self.Objective then
        if self.Objective.Kind=='ATTACK_BED' and (not self.Objective.Target or not self.Objective.Target.Parent) then return 'bed-gone' end
        if (self.Objective.Kind=='HUNT_FINAL' or self.Objective.Kind=='IMMEDIATE_THREAT') and (not self.Objective.Target or not self.Objective.Target.RootPart or not self.Objective.Target.RootPart.Parent) then return 'target-gone' end
        if snapshot.LastLife and snapshot.HealthFraction<0.38 and self.Scheduler.Current.Kind~='Heal' then return 'last-life-low-health' end
        if snapshot.NearbyThreatDistance<10 and self.Objective.Kind~='IMMEDIATE_THREAT' and self.Scheduler.Current.Kind~='Combat' then return 'immediate-threat' end
    end
end

function MatchDirector:_recover(result,snapshot)
    if not result or result.State==ActionState.SUCCESS or result.State==ActionState.CANCELLED then self.RecoveryLevel=0;return end
    self.LastFailure=result.Kind;self.LastFailureReason=result.Reason
    local objective=self.Objective and self.Objective.Kind or '?';local routeKey=self.Objective and self.Objective.Key or '?'
    local entry=self.Failures:Record(objective,result.Kind,routeKey,result.Reason,snapshot.Version)
    self.RecoveryLevel=math.min(entry.Count,6)
    if self.RecoveryLevel<=1 then self.RoutePlan=nil
    elseif self.RecoveryLevel==2 then self.RoutePlan=nil;self.Navigation:ClearLocalCache()
    elseif self.RecoveryLevel==3 then self.Planner.Current=nil
    elseif self.RecoveryLevel==4 then
        local own;for _,bed in ipairs(snapshot.Beds) do if bed.Own then own=bed break end end
        if own and snapshot.OwnBedAlive then self.Planner.Current={Kind='RETURN_SAFE',Position=own.Position,StopRange=12,Score=1000};self.Planner.CommittedAt=now() end
    elseif self.RecoveryLevel==5 then self.Scheduler:Cancel('subsystem-restart');self.RoutePlan=nil
    else self.Planner.Current=nil;self.RoutePlan=nil;self.Failures:ClearStale(snapshot.Version) end
end

function MatchDirector:UpdateHUD(snapshot)
    if not self.HUD then return end
    local current=self.Scheduler.Current
    local route=self.RoutePlan
    self.HUD:Set({
        Objective=self.Objective and self.Objective.Kind or 'Waiting',Action=current and current.Kind or 'Idle',Target=self.Objective and ((self.Objective.Target and self.Objective.Target.Player and self.Objective.Target.Player.Name) or (self.Objective.Bed and 'Bed') or '') or '',
        Route=route and string.format('%d seg / %d exp',#route.Segments,route.Expansions) or 'none',Blocks=string.format('%d / %d',snapshot.Blocks,route and route.RequiredBlocks or 0),Health=string.format('%d%%',math.floor(snapshot.HealthFraction*100)),Risk=route and string.format('%.1f',route.Risk) or '0',Movement=snapshot.MovementOwner or 'none',Recovery=tostring(self.RecoveryLevel),World=tostring(snapshot.Version),Failure=self.LastFailureReason or '',Scores=self.Planner.Scores,Leases=ModuleLeases:Count('AutoWin'),Replans=self.Navigation.Recalculations
    })
end

function MatchDirector:Tick()
    local snapshot=self.Snapshot:Refresh()
    self.Failures:ClearStale(snapshot.Version)
    if snapshot.MatchState==Capabilities.Match.States.POST then self.Session:Queue() end
    if snapshot.MatchState==Capabilities.Match.States.PRE then self.Session.Queued=false end
    local interrupt=self:_interruptReason(snapshot);if interrupt then self.Scheduler:Cancel(interrupt);self.Planner.Current=nil;self.RoutePlan=nil end

    local previous=self.Scheduler.LastResult
    if previous then self:_recover(previous,snapshot);self.Scheduler.LastResult=nil end
    local objective=self.Planner:Choose(snapshot,self.Navigation,self.Loadout)
    if objective and (not self.Objective or self.Objective.Kind~=objective.Kind or self.Objective.Target~=objective.Target) then
        self.Scheduler:Cancel('objective-changed');self.RoutePlan=nil
    end
    self.Objective=objective

    if not self.Scheduler.Current and objective then
        local nextAction,reason=self:_makeAction(objective,snapshot)
        if nextAction then self.Scheduler:Start(nextAction) elseif reason then self.LastFailure='Planner';self.LastFailureReason=reason end
    end
    local state=self.Scheduler:Tick(snapshot)
    if state==ActionState.RUNNING and self.Scheduler.Current and now()-self.Scheduler.Current.ProgressAt<1 then self.LastProgress=now() end
    self:UpdateHUD(snapshot)
end

function MatchDirector:Start()
    self.Session:Start();ModuleLeases:Acquire('AutoWin','AutoTool',{},true);ModuleLeases:Acquire('AutoWin','NoFallDamage',{},true);ModuleLeases:Acquire('AutoWin','AntiVoid',{},true)
    if self.Options.KeepAwake.Enabled then ModuleLeases:Acquire('AutoWin','Anti-AFK',{},true) end
    local gen=self.Generation
    safe('director.unbind',function() runService:UnbindFromRenderStep('AetherAutoWinDrive') end)
    runService:BindToRenderStep('AetherAutoWinDrive',Enum.RenderPriority.Camera.Value,function()
        if self.Running and gen==self.Generation then self:_drive() end
    end)
    task.spawn(function()
        while self.Running and gen==self.Generation do
            local ok,err=xpcall(function() self:Tick() end,debug and debug.traceback or tostring)
            if not ok then Runtime.Errors.AutoWinDirector={At=now(),Error=tostring(err)};self.LastFailure='Director';self.LastFailureReason=tostring(err);self.RecoveryLevel=math.min(self.RecoveryLevel+1,6) end
            task.wait(0.1)
        end
    end)
    task.spawn(function()
        while self.Running and gen==self.Generation do
            task.wait(2)
            local limit=(self.Options.StuckLimit.Value or 0)*60
            if limit>0 and now()-self.LastProgress>limit then
                local snapshot=self.Snapshot:Refresh(true);self.RecoveryLevel=math.min(self.RecoveryLevel+1,6);self.Scheduler:Cancel('watchdog-stall');self.RoutePlan=nil;self.Planner.Current=nil;self.LastFailure='Watchdog';self.LastFailureReason='no subsystem progress';self.LastProgress=now();self.Failures:Record('WATCHDOG','Director','global','stalled',snapshot.Version)
            end
        end
    end)
end

Runtime.MatchDirector = MatchDirector
Runtime.Safe = safe
Runtime.Now = now
Runtime.RootOfLocal = rootOfLocal
Runtime.ModuleByName = moduleByName
Runtime.CopyTable = copyTable
Runtime.Context = ctx
shared.AetherBedWarsRuntime = Runtime
return Runtime
end
local runtimeLoaded, runtimeResult = xpcall(function()
    return registerAetherRuntimeBase(AetherRuntimeContext)
end, debug and debug.traceback or tostring)
if not runtimeLoaded or type(runtimeResult) ~= 'table' then
    error('[AetherV2] AutoWin/Jade runtime failed: '..tostring(runtimeResult))
end
AetherMatchRuntime = runtimeResult

local AetherPortContext = {Version = 2, Runtime = AetherMatchRuntime, Context = AetherRuntimeContext, Modules = {}, Diagnostics = {}}
AetherMatchRuntime.AlSploitPorts = AetherPortContext
AetherMatchRuntime.AlSploitPortsV2 = AetherPortContext

local function aetherPortSafe(label, fn, ...)
    if type(fn) ~= 'function' then return false, 'missing function' end
    local ok, result = pcall(fn, ...)
    if not ok then
        AetherPortContext.Diagnostics[label] = {At = tick(), Error = tostring(result)}
        return false, result
    end
    return true, result
end
local function aetherPortNotify(text, duration, kind)
    aetherPortSafe('notify', notif, 'AetherV2', text, duration or 3, kind)
end
local function aetherPortRoot()
    local char = entitylib.character
    if entitylib.isAlive and char and char.RootPart and char.RootPart.Parent then return char.RootPart, char, char.Humanoid end
    local character = lplr.Character
    local root = character and (character.PrimaryPart or character:FindFirstChild('HumanoidRootPart'))
    local humanoid = character and character:FindFirstChildOfClass('Humanoid')
    if root and humanoid and humanoid.Health > 0 then return root, character, humanoid end
end
local function aetherPortMatchRunning()
    local match = AetherMatchRuntime.BedWarsAPI and AetherMatchRuntime.BedWarsAPI.Match
    if not match then return store.matchState ~= 0 end
    return match:GetState() == match.States.RUNNING
end
local function aetherPortEquippedKit()
    local api = AetherMatchRuntime.BedWarsAPI and AetherMatchRuntime.BedWarsAPI.Kits
    if api then return select(1, api:GetEquipped()) end
    return store.equippedKit or lplr:GetAttribute('PlayingAsKit')
end
local function aetherPortHorizontalUnit(vector)
    if not vector then return nil end
    local flat = Vector3.new(vector.X, 0, vector.Z)
    return flat.Magnitude > 0.01 and flat.Unit or nil
end
local function aetherPortModule(name) return vape.Modules and vape.Modules[name] or nil end
local function aetherPortRegister(categoryName, name, definition)
    local existing = aetherPortModule(name)
    if existing then AetherPortContext.Modules[name] = existing; return existing, false end
    local category = vape.Categories and vape.Categories[categoryName]
    assert(category and type(category.CreateModule) == 'function', 'missing Aether category '..categoryName)
    definition.Name = name
    local module = category:CreateModule(definition)
    AetherPortContext.Modules[name] = module
    return module, true
end
local function aetherPortAbilityController()
    return bedwars.AbilityController or (bedwars.Knit and bedwars.Knit.Controllers and bedwars.Knit.Controllers.AbilityController)
end
local function aetherPortCanUseAbility(name)
    local controller = aetherPortAbilityController()
    if not controller then return false end
    if type(controller.canUseAbility) == 'function' then
        local ok, result = pcall(controller.canUseAbility, controller, name, {disableBlockedAbilityAlert = true})
        if ok then return result ~= false end
    end
    return true
end
local function aetherPortUseAbility(name)
    local controller = aetherPortAbilityController()
    if not controller or type(controller.useAbility) ~= 'function' then return false, 'missing AbilityController' end
    local ok, result = pcall(controller.useAbility, controller, name)
    return ok and result ~= false, result
end
local function aetherPortNearestTarget(range, targets)
    local root = aetherPortRoot(); if not root then return nil end
    local settings = {Origin = root.Position, Range = range, Part = 'RootPart', Players = true, NPCs = false}
    if type(targets) == 'table' then
        settings.Players = targets.Players and targets.Players.Enabled ~= false
        settings.NPCs = targets.NPCs and targets.NPCs.Enabled or false
        settings.Priority = targets.Priority and targets.Priority.Value or nil
        settings.Wallcheck = targets.Walls and targets.Walls.Enabled or nil
    elseif type(targets) == 'boolean' then
        settings.NPCs = targets
    end
    local ok, target = pcall(entitylib.EntityPosition, settings)
    if not ok or not target then return nil end
    if type(targets) == 'table' and targets.Invisible and targets.Invisible.Enabled then
        local part = target.RootPart
        if part and (part.Transparency >= 0.95 or part.LocalTransparencyModifier >= 0.95) then return nil end
    end
    return target
end
local function aetherPortWait(seconds, cancelled, step)
    local deadline = tick() + seconds
    repeat if cancelled and cancelled() then return false end; task.wait(step or 0.03) until tick() >= deadline
    return true
end
local function aetherPortAddMovementOwner(name)
    local movement = AetherMatchRuntime.Movement
    if movement and movement.ExternalNames and not table.find(movement.ExternalNames, name) then table.insert(movement.ExternalNames, name) end
end
local function aetherPortCreateDecoy(followHorizontal)
    local root, character, humanoid = aetherPortRoot(); if not root or not character or not humanoid then return nil end
    local oldArchivable = character.Archivable; character.Archivable = true
    local ok, clone = pcall(character.Clone, character); character.Archivable = oldArchivable
    if not ok or not clone then return nil end
    for _, object in clone:GetDescendants() do
        if object:IsA('Script') or object:IsA('LocalScript') then object:Destroy()
        elseif object:IsA('BasePart') then object.CanCollide = false; if object.Name == 'Cape' then object:Destroy() end end
    end
    clone.Name = 'AetherMovementDecoy'; clone.Parent = workspace
    local cloneRoot = clone.PrimaryPart or clone:FindFirstChild('HumanoidRootPart')
    local cloneHumanoid = clone:FindFirstChildOfClass('Humanoid')
    if not cloneRoot or not cloneHumanoid then clone:Destroy(); return nil end
    clone.PrimaryPart = cloneRoot; cloneRoot.Anchored = true; clone:PivotTo(character:GetPivot())
    local originalSubject = gameCamera.CameraSubject; gameCamera.CameraSubject = cloneHumanoid
    local decoy = {Model = clone, Root = cloneRoot, Humanoid = cloneHumanoid, OriginalSubject = originalSubject}
    if followHorizontal then
        decoy.Connection = runService.RenderStepped:Connect(function()
            local liveRoot = aetherPortRoot()
            if clone.Parent and liveRoot then cloneRoot.CFrame = CFrame.new(liveRoot.Position.X, cloneRoot.Position.Y, liveRoot.Position.Z) * liveRoot.CFrame.Rotation end
        end)
    end
    function decoy:Destroy()
        if self.Connection then self.Connection:Disconnect(); self.Connection = nil end
        if gameCamera.CameraSubject == self.Humanoid then local _, _, liveHumanoid = aetherPortRoot(); gameCamera.CameraSubject = (self.OriginalSubject and self.OriginalSubject.Parent and self.OriginalSubject) or liveHumanoid end
        if self.Model and self.Model.Parent then self.Model:Destroy() end
    end
    return decoy
end
