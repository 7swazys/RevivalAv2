run(function()
    local Killaura
    local Targets
    local CPS
    local SwingRange
    local AttackRange
    local AngleSlider
    local Max
    local Mouse
    local Lunge
    local BoxSwingColor
    local BoxAttackColor
    local ParticleTexture
    local ParticleColor1
    local ParticleColor2
    local ParticleSize
    local Face
    local Overlay = OverlapParams.new()
    Overlay.FilterType = Enum.RaycastFilterType.Include
    local Particles, Boxes, AttackDelay = {}, {}, tick()
	local customSwing = game.PlaceId == 132768098780837
	local function getCustomSwingEvent()
		local events = customSwing and replicatedStorage:FindFirstChild('GameEvents')
		local combat = events and events:FindFirstChild('CombatRemotes')
		return combat and combat:FindFirstChild('Combat_SwingStarted')
	end
	local function customAttack(target, tool)
		local events = replicatedStorage:FindFirstChild('GameEvents')
		local combat = events and events:FindFirstChild('CombatRemotes')
		local remote = combat and (combat:FindFirstChild('Combat_AttemptHit') or combat:FindFirstChild('Combat_Hit'))
		if remote then
			remote:FireServer({
				target = target.Character,
				targetCharacter = target.Character,
				weapon = tool,
				hitPosition = target.RootPart.Position
			})
		end
	end

    local function getAttackData()
	if Mouse.Enabled then
		if not inputService:IsMouseButtonPressed(0) then
			return false
		end
	end

	if customSwing then
		local customSwingEvent = getCustomSwingEvent()
		local equipped = getTool()
		return customSwingEvent, {GripUp = Vector3.yAxis, Tool = equipped, Activate = function()
			if customSwingEvent and equipped then customSwingEvent:FireServer(equipped.Name) end
		end}
	end
	local tool = getTool()
	return tool and tool:FindFirstChildWhichIsA('TouchTransmitter', true) or nil, tool
    end

    Killaura = vape.Categories.Blatant:CreateModule({
	Name = 'Killaura',
	ExtraText = function() return tostring(AttackRange.Value) end,
	Function = function(callback)
		if callback then
			repeat
				local interest, tool = getAttackData()
				local attacked = {}
				if interest then
					local plrs = entitylib.AllPosition({
						Range = SwingRange.Value,
						Wallcheck = Targets.Walls.Enabled or nil,
						Part = 'RootPart',
						Players = Targets.Players.Enabled,
						Priority = Targets.Priority and Targets.Priority.Value,
						NPCs = Targets.NPCs.Enabled,
						Limit = Max.Value,
					})

					if #plrs > 0 then
						local selfpos = entitylib.character.RootPart.Position
						local localfacing = entitylib.character.RootPart.CFrame.LookVector * Vector3.new(1, 0, 1)

						for _, v in plrs do
							local delta = (v.RootPart.Position - selfpos)
							local angle = math.acos(localfacing:Dot((delta * Vector3.new(1, 0, 1)).Unit))
							if angle > (math.rad(AngleSlider.Value) / 2) then
								continue
							end

							table.insert(attacked, {
								Entity = v,
								Check = delta.Magnitude > AttackRange.Value and BoxSwingColor or BoxAttackColor,
							})
							targetinfo.Targets[v] = tick() + 1
							if #attacked == 1 and targetinfo.Focus then
								targetinfo.Focus[v] = tick() + 1
							end

							if AttackDelay < tick() then
								AttackDelay = tick() + (1 / CPS.GetRandomValue())
								tool:Activate()
							end

							if Lunge.Enabled and tool.GripUp.X == 0 then
								break
							end
							if delta.Magnitude > AttackRange.Value then
								continue
							end

							if customSwing then
								customAttack(v, tool.Tool)
								continue
							end
							Overlay.FilterDescendantsInstances = { v.Character }
							for _, part in
								workspace:GetPartBoundsInBox(v.RootPart.CFrame, Vector3.new(4, 4, 4), Overlay)
							do
								firetouchinterest(interest.Parent, part, 1)
								firetouchinterest(interest.Parent, part, 0)
							end
						end
					end
				end

				for i, v in Boxes do
					v.Adornee = attacked[i] and attacked[i].Entity.RootPart or nil
					if v.Adornee then
						v.Color3 = Color3.fromHSV(attacked[i].Check.Hue, attacked[i].Check.Sat, attacked[i].Check.Value)
						v.Transparency = 1 - attacked[i].Check.Opacity
					end
				end

				for i, v in Particles do
					v.Position = attacked[i] and attacked[i].Entity.RootPart.Position or Vector3.new(9e9, 9e9, 9e9)
					v.Parent = attacked[i] and gameCamera or nil
				end

				if Face.Enabled and attacked[1] then
					local vec = attacked[1].Entity.RootPart.Position * Vector3.new(1, 0, 1)
					entitylib.character.RootPart.CFrame = CFrame.lookAt(
						entitylib.character.RootPart.Position,
						Vector3.new(vec.X, entitylib.character.RootPart.Position.Y + 0.01, vec.Z)
					)
				end

				task.wait()
			until not Killaura.Enabled
		else
			for _, v in Boxes do
				v.Adornee = nil
			end
			for _, v in Particles do
				v.Parent = nil
			end
		end
	end,
	Tooltip = 'Attacks players around you without aiming',
    })
    Targets = Killaura:CreateTargets({ Players = true })
    CPS = Killaura:CreateTwoSlider({
	Name = 'Attacks per Second',
	Min = 1,
	Max = 20,
	DefaultMin = 12,
	DefaultMax = 12,
    })
    SwingRange = Killaura:CreateSlider({
	Name = 'Swing range',
	Min = 1,
	Max = 30,
	Default = 18,
	Suffix = function(val)
		return val == 1 and 'stud' or 'studs'
	end,
    })
    AttackRange = Killaura:CreateSlider({
	Name = 'Attack range',
	Min = 1,
	Max = 30,
	Default = 18,
	Suffix = function(val)
		return val == 1 and 'stud' or 'studs'
	end,
    })
    AngleSlider = Killaura:CreateSlider({
	Name = 'Max angle',
	Min = 1,
	Max = 360,
	Default = 90,
    })
    Max = Killaura:CreateSlider({
	Name = 'Max targets',
	Min = 1,
	Max = 10,
	Default = 10,
    })
    Mouse = Killaura:CreateToggle({ Name = 'Require mouse down' })
    Lunge = Killaura:CreateToggle({ Name = 'Sword lunge only' })
    local ShowTargetGroup = Killaura:CreateGroup({
	Name = 'Show target',
	Function = function(callback)
		if callback then
			for i = 1, 10 do
				local box = Instance.new('BoxHandleAdornment')
				box.Adornee = nil
				box.AlwaysOnTop = true
				box.Size = Vector3.new(3, 5, 3)
				box.CFrame = CFrame.new(0, -0.5, 0)
				box.ZIndex = 0
				box.Parent = vape.gui
				Boxes[i] = box
			end
		else
			for _, v in Boxes do
				v:Destroy()
			end
			table.clear(Boxes)
		end
	end,
    })
    BoxSwingColor = ShowTargetGroup:CreateColorSlider({
	Name = 'Target Colour',
	Darker = true,
	DefaultOpacity = 0.5,
    })
    BoxAttackColor = ShowTargetGroup:CreateColorSlider({
	Name = 'Attack Colour',
	Darker = true,
	DefaultOpacity = 0.5,
    })
    local TargetParticlesGroup = Killaura:CreateGroup({
	Name = 'Target particles',
	Function = function(callback)
		if callback then
			for i = 1, 10 do
				local part = Instance.new('Part')
				part.Size = Vector3.new(2, 4, 2)
				part.Anchored = true
				part.CanCollide = false
				part.Transparency = 1
				part.CanQuery = false
				part.Parent = Killaura.Enabled and gameCamera or nil
				local particles = Instance.new('ParticleEmitter')
				particles.Brightness = 1.5
				particles.Size = NumberSequence.new(ParticleSize.Value)
				particles.Shape = Enum.ParticleEmitterShape.Sphere
				particles.Texture = ParticleTexture.Value
				particles.Transparency = NumberSequence.new(0)
				particles.Lifetime = NumberRange.new(0.4)
				particles.Speed = NumberRange.new(16)
				particles.Rate = 128
				particles.Drag = 16
				particles.ShapePartial = 1
				particles.Color = ColorSequence.new({
					ColorSequenceKeypoint.new(
						0,
						Color3.fromHSV(ParticleColor1.Hue, ParticleColor1.Sat, ParticleColor1.Value)
					),
					ColorSequenceKeypoint.new(
						1,
						Color3.fromHSV(ParticleColor2.Hue, ParticleColor2.Sat, ParticleColor2.Value)
					),
				})
				particles.Parent = part
				Particles[i] = part
			end
		else
			for _, v in Particles do
				v:Destroy()
			end
			table.clear(Particles)
		end
	end,
    })
    ParticleTexture = TargetParticlesGroup:CreateTextBox({
	Name = 'Texture',
	Default = 'rbxassetid://14736249347',
	Function = function()
		for _, v in Particles do
			v.ParticleEmitter.Texture = ParticleTexture.Value
		end
	end,
	Darker = true,
    })
    ParticleColor1 = TargetParticlesGroup:CreateColorSlider({
	Name = 'Colour Begin',
	Function = function(hue, sat, val)
		for _, v in Particles do
			v.ParticleEmitter.Color = ColorSequence.new({
				ColorSequenceKeypoint.new(0, Color3.fromHSV(hue, sat, val)),
				ColorSequenceKeypoint.new(
					1,
					Color3.fromHSV(ParticleColor2.Hue, ParticleColor2.Sat, ParticleColor2.Value)
				),
			})
		end
	end,
	Darker = true,
    })
    ParticleColor2 = TargetParticlesGroup:CreateColorSlider({
	Name = 'Colour End',
	Function = function(hue, sat, val)
		for _, v in Particles do
			v.ParticleEmitter.Color = ColorSequence.new({
				ColorSequenceKeypoint.new(
					0,
					Color3.fromHSV(ParticleColor1.Hue, ParticleColor1.Sat, ParticleColor1.Value)
				),
				ColorSequenceKeypoint.new(1, Color3.fromHSV(hue, sat, val)),
			})
		end
	end,
	Darker = true,
    })
    ParticleSize = TargetParticlesGroup:CreateSlider({
	Name = 'Size',
	Min = 0,
	Max = 1,
	Default = 0.2,
	Decimal = 100,
	Function = function(val)
		for _, v in Particles do
			v.ParticleEmitter.Size = NumberSequence.new(val)
		end
	end,
	Darker = true,
    })
    Face = Killaura:CreateToggle({ Name = 'Face target' })
end)
