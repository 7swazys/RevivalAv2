run(function()
    local SafeWalk
    local rayCheck = RaycastParams.new()
    local rayCheckF1, rayCheckF2 = false, false
    rayCheck.RespectCanCollide = true
    local module, old, hook

    SafeWalk = vape.Categories.World:CreateModule({
	Name = 'SafeWalk',
	Function = function(callback)
		if callback then
			if not module then
				local suc = pcall(function()
					module = require(lplr.PlayerScripts.PlayerModule).controls
				end)
				if not suc then
					module = {}
				end
			end

			if hook then return end
			old = module.moveFunction
			hook = function(self, vec, face)
				if SafeWalk.Enabled and entitylib.isAlive then
					if rayCheckF1 ~= lplr.Character or rayCheckF2 ~= gameCamera then
						rayCheckF1, rayCheckF2 = lplr.Character, gameCamera
						rayCheck.FilterDescendantsInstances = {lplr.Character, gameCamera}
					end
					local root = entitylib.character.RootPart
					local movedir = root.Position + vec
					local ray = workspace:Raycast(movedir, Vector3.new(0, -15, 0), rayCheck)
					if not ray then
						local check = workspace:Blockcast(
							root.CFrame,
							Vector3.new(3, 1, 3),
							Vector3.new(0, -(entitylib.character.HipHeight + 1), 0),
							rayCheck
						)
						if check then
							vec = (check.Instance:GetClosestPointOnSurface(movedir) - root.Position)
								* Vector3.new(1, 0, 1)
						end
					end
				end

				return old(self, vec, face)
			end
			module.moveFunction = hook
		else
			if module and hook and module.moveFunction == hook then
				module.moveFunction = old
				hook, old = nil, nil
			end
		end
	end,
	Tooltip = 'Prevents you from walking off the edge of parts',
    })
end)
