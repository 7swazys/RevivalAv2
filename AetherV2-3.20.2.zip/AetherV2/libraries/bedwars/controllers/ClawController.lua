
return {
    lastAttackTime = workspace:GetServerTimeNow()
}