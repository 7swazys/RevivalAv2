local entitylib = {
	isAlive = false,
	character = {},
	List = {},
	Connections = {},
	PlayerConnections = {},
	EntityThreads = {},
	Running = false,
	Events = setmetatable({}, {
		__index = function(self, ind)
			self[ind] = {
				Connections = {},
				Connect = function(rself, func)
					table.insert(rself.Connections, func)
					return {
						Disconnect = function()
							local rind = table.find(rself.Connections, func)
							if rind then
								table.remove(rself.Connections, rind)
							end
						end
					}
				end,
				Fire = function(rself, ...)
					for _, v in rself.Connections do
						task.spawn(v, ...)
					end
				end,
				Destroy = function(rself)
					table.clear(rself.Connections)
					table.clear(rself)
				end
			}

			return self[ind]
		end
	})
}

local cloneref = cloneref or function(obj)
	return obj
end
local playersService = cloneref(game:GetService('Players'))
local inputService = cloneref(game:GetService('UserInputService'))
local lplr = playersService.LocalPlayer
local gameCamera = workspace.CurrentCamera

local function getMousePosition()
	if inputService.TouchEnabled then
		return gameCamera.ViewportSize / 2
	end
	return inputService.GetMouseLocation(inputService)
end

local function sortDistance(a, b)
	return a.Magnitude < b.Magnitude
end

entitylib.Priorities = {
	Players = function(v)
		return v.Entity.Player and 0 or 1
	end,
	NPCs = function(v)
		return v.Entity.Player and 1 or 0
	end,
	Closest = function(v)
		return v.Magnitude
	end,
	Farthest = function(v)
		return -v.Magnitude
	end,
	['Lowest health'] = function(v)
		return v.Entity.Health
	end,
	['Highest health'] = function(v)
		return -v.Entity.Health
	end,
	Crosshair = function(v)
		local pos, vis = gameCamera:WorldToViewportPoint(v.Entity.RootPart.Position)
		return vis and (Vector2.new(pos.X, pos.Y) - (gameCamera.ViewportSize / 2)).Magnitude or math.huge
	end
}

local rankedSort, rankedRank
local function rankedCompare(a, b)
	local ranka, rankb = rankedRank(a), rankedRank(b)
	if ranka ~= rankb then
		return ranka < rankb
	end
	return rankedSort(a, b)
end

entitylib.getSort = function(entitysettings)
	local sort = entitysettings.Sort or sortDistance
	local rank = entitylib.Priorities[entitysettings.Priority]
	if not rank then
		return sort
	end

	rankedSort, rankedRank = sort, rank
	return rankedCompare
end

local scratch, scratchDepth = {}, 0

local function openScratch()
	scratchDepth += 1
	local slot = scratch[scratchDepth]
	if not slot then
		slot = {List = {}, Pool = {}}
		scratch[scratchDepth] = slot
	end
	table.clear(slot.List)
	return slot
end

local function closeScratch(slot)
	table.clear(slot.List)
	scratchDepth -= 1
end

local function addCandidate(slot, ent, mag)
	local count = #slot.List + 1
	local entry = slot.Pool[count]
	if not entry then
		entry = {}
		slot.Pool[count] = entry
	end
	entry.Entity = ent
	entry.Magnitude = mag
	slot.List[count] = entry
end

local function loopClean(tbl)
	for i, v in tbl do
		if type(v) == 'table' then
			loopClean(v)
		end
		tbl[i] = nil
	end
end

local function waitForChildOfType(obj, name, timeout, prop)
	local checktick = tick() + timeout
	local returned
	repeat
		returned = prop and obj[name] or obj:FindFirstChildOfClass(name)
		if returned or checktick < tick() then break end
		task.wait()
	until false
	return returned
end

entitylib.targetCheck = function(ent)
	if ent.TeamCheck then
		return ent:TeamCheck()
	end
	if ent.NPC then return true end
	if not lplr.Team then return true end
	if not ent.Player.Team then return true end
	if ent.Player.Team ~= lplr.Team then return true end
	return #ent.Player.Team:GetPlayers() == #playersService:GetPlayers()
end

entitylib.getUpdateConnections = function(ent)
	local hum = ent.Humanoid
	return {
		hum:GetPropertyChangedSignal('Health'),
		hum:GetPropertyChangedSignal('MaxHealth')
	}
end

local forceFields = setmetatable({}, {__mode = 'k'})
entitylib.isVulnerable = function(ent)
	if ent.Health <= 0 then return false end
	local char = ent.Character
	local entry = forceFields[char]
	if not entry then
		entry = {Clock = 0, Value = false}
		forceFields[char] = entry
	end
	local now = os.clock()
	if now - entry.Clock >= 0.05 then
		entry.Clock = now
		entry.Value = char.FindFirstChildWhichIsA(char, 'ForceField') ~= nil
	end
	return not entry.Value
end

entitylib.getEntityColor = function(ent)
	ent = ent.Player
	return ent and tostring(ent.TeamColor) ~= 'White' and ent.TeamColor.Color or nil
end

local wallIgnore = {gameCamera}
local wallIgnoreExtra = {gameCamera}
local wallIgnoreVersion = -1
local rosterVersion = 0

local function fillWallIgnore(list, extra)
	local size = 0
	if gameCamera then
		size += 1
		list[size] = gameCamera
	end
	local character = lplr.Character
	if character then
		size += 1
		list[size] = character
	end
	for _, v in entitylib.List do
		if v.Targetable and v.Character then
			size += 1
			list[size] = v.Character
		end
	end
	if extra then
		for _, v in extra do
			if v then
				size += 1
				list[size] = v
			end
		end
	end
	for index = size + 1, #list do
		list[index] = nil
	end
	return list
end

entitylib.IgnoreObject = RaycastParams.new()
entitylib.IgnoreObject.RespectCanCollide = true
entitylib.Wallcheck = function(origin, position, ignoreobject)
	if typeof(ignoreobject) ~= 'Instance' then
		local extra = typeof(ignoreobject) == 'table' and ignoreobject or nil
		if extra then
			entitylib.IgnoreObject.FilterDescendantsInstances = fillWallIgnore(wallIgnoreExtra, extra)
		elseif rosterVersion ~= wallIgnoreVersion then
			entitylib.IgnoreObject.FilterDescendantsInstances = fillWallIgnore(wallIgnore, nil)
			wallIgnoreVersion = rosterVersion
		end
		ignoreobject = entitylib.IgnoreObject
	end
	return workspace.Raycast(workspace, origin, (position - origin), ignoreobject)
end
entitylib.Events.EntityAdded:Connect(function()
	rosterVersion += 1
end)
entitylib.Events.EntityRemoved:Connect(function()
	rosterVersion += 1
end)
entitylib.Events.LocalAdded:Connect(function()
	rosterVersion += 1
end)
entitylib.Events.LocalRemoved:Connect(function()
	rosterVersion += 1
end)

entitylib.EntityMouse = function(entitysettings)
	if entitylib.isAlive then
		local slot = openScratch()
		local mouseLocation, sortingTable = entitysettings.MouseOrigin or getMousePosition(), slot.List
		for _, v in entitylib.List do
			if not entitysettings.Players and v.Player then continue end
			if not entitysettings.NPCs and v.NPC then continue end
			if not v.Targetable then continue end
			local position, vis = gameCamera.WorldToViewportPoint(gameCamera, v[entitysettings.Part].Position)
			if not vis then continue end
			local mag = (mouseLocation - Vector2.new(position.x, position.y)).Magnitude
			if mag > entitysettings.Range then continue end
			if entitysettings.MaxDistance and entitysettings.Origin and (v[entitysettings.Part].Position - entitysettings.Origin).Magnitude > entitysettings.MaxDistance then continue end
			if entitylib.isVulnerable(v) then
				addCandidate(slot, v, v.Target and -1 or mag)
			end
		end

		if #sortingTable > 1 then
			table.sort(sortingTable, entitylib.getSort(entitysettings))
		end

		for _, v in sortingTable do
			if entitysettings.Wallcheck then
				if entitylib.Wallcheck(entitysettings.Origin, v.Entity[entitysettings.Part].Position, entitysettings.Wallcheck) then continue end
			end
			if entitysettings.Check and not entitysettings.Check(v.Entity) then continue end
			local found = v.Entity
			table.clear(entitysettings)
			closeScratch(slot)
			return found
		end
		closeScratch(slot)
	end
	table.clear(entitysettings)
end

entitylib.EntityPosition = function(entitysettings)
	if entitylib.isAlive then
		local slot = openScratch()
		local localPosition, sortingTable = entitysettings.Origin or entitylib.character.HumanoidRootPart.Position, slot.List
		local range, customSort = entitysettings.Range, entitysettings.Sort or entitysettings.Priority
		local screenSort = shared.AetherScreenSorts and shared.AetherScreenSorts[entitysettings.Sort]
		local rangeSquared = range * range
		for _, v in entitylib.List do
			if not entitysettings.Players and v.Player then continue end
			if not entitysettings.NPCs and v.NPC then continue end
			if not v.Targetable then continue end
			if screenSort then
				local _, visible = gameCamera:WorldToViewportPoint(v[entitysettings.Part].Position)
				if not visible then continue end
			end
			local delta = v[entitysettings.Part].Position - localPosition
			local mag = delta:Dot(delta)
			if mag > rangeSquared then continue end
			if entitylib.isVulnerable(v) then
				addCandidate(slot, v, v.Target and -1 or (customSort and math.sqrt(mag) or mag))
			end
		end

		if #sortingTable > 1 then
			table.sort(sortingTable, entitylib.getSort(entitysettings))
		end

		for _, v in sortingTable do
			if entitysettings.Wallcheck then
				if entitylib.Wallcheck(localPosition, v.Entity[entitysettings.Part].Position, entitysettings.Wallcheck) then continue end
			end
			local found = v.Entity
			table.clear(entitysettings)
			closeScratch(slot)
			return found
		end
		closeScratch(slot)
	end
	table.clear(entitysettings)
end

entitylib.AllPosition = function(entitysettings)
	local returned = {}
	if entitylib.isAlive then
		local slot = openScratch()
		local localPosition, sortingTable = entitysettings.Origin or entitylib.character.HumanoidRootPart.Position, slot.List
		local range, customSort = entitysettings.Range, entitysettings.Sort
		local rangeSquared = range * range
		for _, v in entitylib.List do
			if not entitysettings.Players and v.Player then continue end
			if not entitysettings.NPCs and v.NPC then continue end
			if not v.Targetable then continue end
			local delta = v[entitysettings.Part].Position - localPosition
			local mag = delta:Dot(delta)
			if mag > rangeSquared then continue end
			if entitylib.isVulnerable(v) then
				addCandidate(slot, v, v.Target and -1 or (customSort and math.sqrt(mag) or mag))
			end
		end

		if #sortingTable > 1 then
			table.sort(sortingTable, entitylib.getSort(entitysettings))
		end

		for _, v in sortingTable do
			if entitysettings.Wallcheck then
				if entitylib.Wallcheck(localPosition, v.Entity[entitysettings.Part].Position, entitysettings.Wallcheck) then continue end
			end
			table.insert(returned, v.Entity)
			if #returned >= (entitysettings.Limit or math.huge) then break end
		end
		closeScratch(slot)
	end
	table.clear(entitysettings)
	return returned
end

entitylib.getEntity = function(char)
	for i, v in entitylib.List do
		if v.Player == char or v.Character == char then
			return v, i
		end
	end
end

entitylib.addEntity = function(char, plr, teamfunc)
	if not char then return end
	entitylib.EntityThreads[char] = task.spawn(function()
		local hum = waitForChildOfType(char, 'Humanoid', 10)
		local humrootpart = hum and waitForChildOfType(hum, 'RootPart', workspace.StreamingEnabled and 9e9 or 10, true)
		local head = char:WaitForChild('Head', 10) or humrootpart

		if hum and humrootpart then
			local entity = {
				Connections = {},
				Character = char,
				Health = hum.Health,
				Head = head,
				Humanoid = hum,
				HumanoidRootPart = humrootpart,
				HipHeight = hum.HipHeight + (humrootpart.Size.Y / 2) + (hum.RigType == Enum.HumanoidRigType.R6 and 2 or 0),
				MaxHealth = hum.MaxHealth,
				NPC = plr == nil,
				Player = plr,
				RootPart = humrootpart,
				TeamCheck = teamfunc
			}

			if plr == lplr then
				entitylib.character = entity
				entitylib.isAlive = true
				entitylib.Events.LocalAdded:Fire(entity)
			else
				entity.Targetable = entitylib.targetCheck(entity)
				table.insert(entity.Connections, hum.AnimationPlayed:Connect(function(track)
					entitylib.Events.AnimationPlayed:Fire(plr, track)
				end))

				for _, v in entitylib.getUpdateConnections(entity) do
					table.insert(entity.Connections, v:Connect(function()
						entity.Health = hum.Health
						entity.MaxHealth = hum.MaxHealth
						entitylib.Events.EntityUpdated:Fire(entity)
					end))
				end

			table.insert(entitylib.List, entity)
			rosterVersion += 1
			entitylib.Events.EntityAdded:Fire(entity)
			end
		end
		entitylib.EntityThreads[char] = nil
	end)
end

entitylib.removeEntity = function(char, localcheck)
	if localcheck then
		if entitylib.isAlive then
			entitylib.isAlive = false
			rosterVersion += 1
			for _, v in entitylib.character.Connections do
				v:Disconnect()
			end
			table.clear(entitylib.character.Connections)
			entitylib.Events.LocalRemoved:Fire(entitylib.character)
		end
		return
	end

	if char then
		if entitylib.EntityThreads[char] then
			task.cancel(entitylib.EntityThreads[char])
			entitylib.EntityThreads[char] = nil
		end

		local entity, ind = entitylib.getEntity(char)
		if ind then
			for _, v in entity.Connections do
				v:Disconnect()
			end
			table.clear(entity.Connections)
			table.remove(entitylib.List, ind)
			rosterVersion += 1
			entitylib.Events.EntityRemoved:Fire(entity)
		end
	end
end

entitylib.refreshEntity = function(char, plr)
	entitylib.removeEntity(char)
	entitylib.addEntity(char, plr)
end

entitylib.addPlayer = function(plr)
	if plr.Character then
		entitylib.refreshEntity(plr.Character, plr)
	end
	entitylib.PlayerConnections[plr] = {
		plr.CharacterAdded:Connect(function(char)
			entitylib.refreshEntity(char, plr)
		end),
		plr.CharacterRemoving:Connect(function(char)
			entitylib.removeEntity(char, plr == lplr)
		end),
		plr:GetPropertyChangedSignal('Team'):Connect(function()
			for _, v in entitylib.List do
				if v.Targetable ~= entitylib.targetCheck(v) then
					entitylib.refreshEntity(v.Character, v.Player)
				end
			end

			if plr == lplr then
				entitylib.start()
			else
				entitylib.refreshEntity(plr.Character, plr)
			end
		end)
	}
end

entitylib.removePlayer = function(plr)
	if entitylib.PlayerConnections[plr] then
		for _, v in entitylib.PlayerConnections[plr] do
			v:Disconnect()
		end
		table.clear(entitylib.PlayerConnections[plr])
		entitylib.PlayerConnections[plr] = nil
	end
	entitylib.removeEntity(plr)
end

entitylib.start = function()
	if entitylib.Running then
		entitylib.stop()
	end
	table.insert(entitylib.Connections, playersService.PlayerAdded:Connect(function(v)
		entitylib.addPlayer(v)
	end))
	table.insert(entitylib.Connections, playersService.PlayerRemoving:Connect(function(v)
		entitylib.removePlayer(v)
	end))
	for _, v in playersService:GetPlayers() do
		entitylib.addPlayer(v)
	end
	table.insert(entitylib.Connections, workspace:GetPropertyChangedSignal('CurrentCamera'):Connect(function()
		gameCamera = workspace.CurrentCamera or workspace:FindFirstChildWhichIsA('Camera')
		rosterVersion += 1
	end))
	entitylib.Running = true
end

entitylib.stop = function()
	for _, v in entitylib.Connections do
		v:Disconnect()
	end
	for _, v in entitylib.PlayerConnections do
		for _, v2 in v do
			v2:Disconnect()
		end
		table.clear(v)
	end
	entitylib.removeEntity(nil, true)
	local cloned = table.clone(entitylib.List)
	for _, v in cloned do
		entitylib.removeEntity(v.Character)
	end
	for _, v in entitylib.EntityThreads do
		task.cancel(v)
	end
	table.clear(entitylib.PlayerConnections)
	table.clear(entitylib.EntityThreads)
	table.clear(entitylib.Connections)
	table.clear(cloned)
	entitylib.Running = false
end

entitylib.kill = function()
	if entitylib.Running then
		entitylib.stop()
	end
	for _, v in entitylib.Events do
		v:Destroy()
	end
	entitylib.IgnoreObject:Destroy()
	loopClean(entitylib)
end

entitylib.refresh = function()
	local cloned = table.clone(entitylib.List)
	for _, v in cloned do
		entitylib.refreshEntity(v.Character, v.Player)
	end
	table.clear(cloned)
end

entitylib.start()

return entitylib
